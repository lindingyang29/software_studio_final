
require('./assets/scripts/CameraFollow');
require('./assets/scripts/GameData');
require('./assets/scripts/GameMgr');
require('./assets/scripts/LevelBuilder');
require('./assets/scripts/MenuCtrl');
require('./assets/scripts/Player');
require('./assets/scripts/Sfx');
