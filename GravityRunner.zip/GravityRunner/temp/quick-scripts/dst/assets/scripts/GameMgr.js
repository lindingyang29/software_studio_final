
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/GameMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2f636z6hMFHmItBVlgUXfxC', 'GameMgr');
// scripts/GameMgr.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GameData_1 = require("./GameData");
var LevelBuilder_1 = require("./LevelBuilder");
var Player_1 = require("./Player");
var CameraFollow_1 = require("./CameraFollow");
var Sfx_1 = require("./Sfx");
var ccclass = cc._decorator.ccclass;
// Owns the Game scene: loads assets + level JSON, builds the world through
// LevelBuilder, spawns 1-2 Players, and runs the ready/run/dead/win state machine.
// Everything (world, HUD) is created in code — the .fire scene stays minimal.
//
// Co-op rules (GameData.players === 2): P1 = W key, P2 = UP/SPACE.
// If one player dies while the partner survives, they revive next to the
// partner after 3s. If everyone is dead, the level restarts.
var GameMgr = /** @class */ (function (_super) {
    __extends(GameMgr, _super);
    function GameMgr() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // global slow-motion factor (slow power-up); Player multiplies dt by this
        _this.timeScale = 1;
        _this.cameraNode = null;
        _this.world = null;
        _this.hud = null;
        _this.players = [];
        _this.level = null;
        _this.frames = {};
        _this.state = "loading";
        _this.time = 0;
        _this.deaths = 0;
        _this.crystalsTaken = 0;
        _this.slowT = 0;
        _this.enemyT = 0;
        _this.rotCurrent = 0;
        _this.rotTarget = 0;
        _this.nameLabel = null;
        _this.crystalLabel = null;
        _this.deathLabel = null;
        _this.timeLabel = null;
        _this.msgLabel = null;
        _this.subLabel = null;
        _this.slowOverlay = null;
        return _this;
    }
    GameMgr.prototype.isRunning = function () {
        return this.state === "run";
    };
    GameMgr.prototype.onLoad = function () {
        var _this = this;
        Sfx_1.default.preload();
        Sfx_1.default.playBgm();
        this.cameraNode = this.node.getChildByName("Main Camera");
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouch, this);
        cc.resources.loadDir("textures", cc.SpriteFrame, function (err, assets) {
            if (err) {
                cc.error("texture load failed", err);
                return;
            }
            for (var _i = 0, assets_1 = assets; _i < assets_1.length; _i++) {
                var a = assets_1[_i];
                _this.frames[a.name] = a;
            }
            _this.onTexturesReady();
        });
    };
    GameMgr.prototype.onDestroy = function () {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    };
    GameMgr.prototype.onTexturesReady = function () {
        var _this = this;
        // background rides along as a child of the camera (auto screen-aligned,
        // even when the camera rotates in rotation zones)
        var bg = new cc.Node("BG");
        var bgSp = bg.addComponent(cc.Sprite);
        bgSp.spriteFrame = this.frames["bg"];
        bgSp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        bg.setContentSize(1400, 1400); // oversized: stays covering while rotated
        var b = GameData_1.default.settings.brightness;
        var tint = LevelBuilder_1.default.scheme().bgTint;
        bg.color = cc.color(Math.round(tint.r * b), Math.round(tint.g * b), Math.round(tint.b * b));
        this.cameraNode.addChild(bg, -10);
        this.world = new cc.Node("World");
        this.node.addChild(this.world);
        this.buildHud();
        cc.resources.load("levels/level" + GameData_1.default.currentLevel, cc.JsonAsset, function (err, asset) {
            if (err) {
                _this.setMsg("LEVEL " + GameData_1.default.currentLevel + " LOAD ERROR", "");
                cc.error(err);
                return;
            }
            _this.startLevel(asset.json);
        });
    };
    GameMgr.prototype.startLevel = function (data) {
        this.level = LevelBuilder_1.default.build(this.world, data, this.frames);
        var count = GameData_1.default.players === 2 ? 2 : 1;
        this.players = [];
        for (var i = 0; i < count; i++) {
            var pNode = new cc.Node("Player" + (i + 1));
            var sp = pNode.addComponent(cc.Sprite);
            sp.spriteFrame = this.frames[i === 0 ? "player" : "player2"];
            sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            pNode.setContentSize(36, 36);
            this.world.addChild(pNode, 5);
            var p = pNode.addComponent(Player_1.default);
            p.init(this, this.level, i, this.frames);
            this.players.push(p);
        }
        var follow = this.cameraNode.addComponent(CameraFollow_1.default);
        follow.init(this.players[0].node, 0, this.level.length - 480);
        follow.snap();
        this.time = 0;
        this.deaths = 0;
        this.crystalsTaken = 0;
        this.timeScale = 1;
        this.enemyT = 0;
        this.applyRotationForX(this.level.start.x, true);
        this.nameLabel.string = "LEVEL " + GameData_1.default.currentLevel + " — " + this.level.name
            + (count === 2 ? "   [2P]" : "");
        this.refreshHud();
        this.state = "ready";
        this.setMsg("PRESS SPACE TO RUN", count === 2
            ? "P1: W = FLIP      P2: UP / SPACE = FLIP      R = RESTART"
            : "SPACE / W / UP = FLIP GRAVITY    R = RESTART    ESC = PAUSE");
    };
    // ---------- HUD ----------
    GameMgr.prototype.makeLabel = function (parent, x, y, size, color, anchorX) {
        if (anchorX === void 0) { anchorX = 0.5; }
        var n = new cc.Node("label");
        n.setPosition(x, y);
        n.anchorX = anchorX;
        n.color = color;
        var lb = n.addComponent(cc.Label);
        lb.fontSize = size;
        lb.lineHeight = size + 6;
        lb.string = "";
        parent.addChild(n);
        return lb;
    };
    GameMgr.prototype.buildHud = function () {
        // HUD is a sibling of the world; update() keeps it glued to the camera
        // (position AND angle, so it stays upright in rotation zones).
        this.hud = new cc.Node("HUD");
        this.node.addChild(this.hud, 100);
        var cyan = cc.color(127, 247, 255);
        var pink = cc.color(255, 122, 200);
        var orange = cc.color(255, 181, 74);
        var white = cc.color(235, 240, 255);
        this.slowOverlay = new cc.Node("slowFx");
        var so = this.slowOverlay.addComponent(cc.Sprite);
        so.spriteFrame = this.frames["white"];
        so.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.slowOverlay.setContentSize(1400, 1400);
        this.slowOverlay.color = cc.color(120, 150, 255);
        this.slowOverlay.opacity = 0;
        this.hud.addChild(this.slowOverlay, -1);
        this.nameLabel = this.makeLabel(this.hud, -450, 296, 20, cyan, 0);
        this.crystalLabel = this.makeLabel(this.hud, -450, 268, 20, white, 0);
        this.deathLabel = this.makeLabel(this.hud, -450, 240, 20, pink, 0);
        this.timeLabel = this.makeLabel(this.hud, 450, 296, 20, orange, 1);
        this.msgLabel = this.makeLabel(this.hud, 0, 40, 44, white);
        this.subLabel = this.makeLabel(this.hud, 0, -10, 18, cyan);
    };
    GameMgr.prototype.refreshHud = function () {
        this.crystalLabel.string = "CRYSTALS  " + this.crystalsTaken + " / " + this.level.totalCrystals;
        this.deathLabel.string = "DEATHS  " + this.deaths;
        this.timeLabel.string = this.formatTime(this.time);
    };
    GameMgr.prototype.formatTime = function (t) {
        var m = Math.floor(t / 60);
        var s = t - m * 60;
        return (m < 10 ? "0" + m : "" + m) + ":" + (s < 10 ? "0" + s.toFixed(1) : s.toFixed(1));
    };
    GameMgr.prototype.setMsg = function (main, sub) {
        this.msgLabel.string = main;
        this.subLabel.string = sub;
    };
    // ---------- input ----------
    GameMgr.prototype.onKeyDown = function (e) {
        switch (e.keyCode) {
            case cc.macro.KEY.space:
            case cc.macro.KEY.up:
                this.onAction(1);
                break;
            case cc.macro.KEY.w:
                this.onAction(0);
                break;
            case cc.macro.KEY.r:
                this.fullRestart();
                break;
            case cc.macro.KEY.escape:
                this.togglePause();
                break;
        }
    };
    GameMgr.prototype.onTouch = function (e) {
        // 2P touch: left half of the screen = P1, right half = P2
        var half = cc.winSize.width / 2;
        this.onAction(e.getLocationX() < half ? 0 : 1);
    };
    // who: 0 = P1 input, 1 = P2 input (in solo mode every input drives P1)
    GameMgr.prototype.onAction = function (who) {
        switch (this.state) {
            case "ready":
                this.state = "run";
                this.setMsg("", "");
                break;
            case "run": {
                var idx = GameData_1.default.players === 2 ? who : 0;
                var p = this.players[idx];
                if (p && p.alive)
                    p.flip();
                break;
            }
            case "paused":
                this.togglePause();
                break;
            case "win":
                this.proceedAfterWin();
                break;
        }
    };
    GameMgr.prototype.togglePause = function () {
        if (this.state === "run") {
            this.state = "paused";
            this.setMsg("PAUSED", "SPACE = RESUME    R = RESTART");
        }
        else if (this.state === "paused") {
            this.state = "run";
            this.setMsg("", "");
        }
        else if (this.state === "win") {
            cc.director.loadScene("Menu");
        }
    };
    GameMgr.prototype.fullRestart = function () {
        if (this.state === "loading" || this.players.length === 0)
            return;
        this.unscheduleAllCallbacks();
        this.respawnAll();
        this.state = "ready";
        this.setMsg("PRESS SPACE TO RUN", "");
    };
    GameMgr.prototype.respawnAll = function () {
        for (var _i = 0, _a = this.players; _i < _a.length; _i++) {
            var p = _a[_i];
            p.reset();
        }
        for (var _b = 0, _c = this.level.crystals; _b < _c.length; _b++) {
            var c = _c[_b];
            c.taken = false;
            c.node.active = true;
            c.node.setPosition(c.x, c.y); // magnet may have dragged it around
        }
        for (var _d = 0, _e = this.level.powerups; _d < _e.length; _d++) {
            var pu = _e[_d];
            pu.taken = false;
            pu.node.active = true;
        }
        this.crystalsTaken = 0;
        this.time = 0;
        this.timeScale = 1;
        this.slowT = 0;
        this.slowOverlay.opacity = 0;
        this.enemyT = 0;
        var follow = this.cameraNode.getComponent(CameraFollow_1.default);
        if (follow) {
            follow.setTarget(this.players[0].node);
            follow.snap();
        }
        this.applyRotationForX(this.level.start.x, true);
        this.refreshHud();
    };
    // ---------- rotation zones ----------
    GameMgr.prototype.applyRotationForX = function (x, instant) {
        var target = 0;
        for (var _i = 0, _a = this.level.rotations; _i < _a.length; _i++) {
            var r = _a[_i];
            if (x >= r.x)
                target = r.angle;
        }
        if (target !== this.rotTarget) {
            this.rotTarget = target;
            if (!instant)
                Sfx_1.default.play("teleport", 0.4);
        }
        if (instant) {
            this.rotCurrent = target;
            this.applyWorldRotation();
        }
    };
    // Rotate the WORLD node (not the camera — cc.Camera in 2.4 ignores its
    // node's rotation) around the camera's focus point. Obstacles, players and
    // apparent gravity all rotate on screen, while physics stay 1D because
    // Player works in the world node's local coordinates.
    GameMgr.prototype.applyWorldRotation = function () {
        var th = this.rotCurrent * Math.PI / 180;
        var px = this.cameraNode.x; // camera y is always 0
        this.world.angle = this.rotCurrent;
        this.world.x = px - px * Math.cos(th);
        this.world.y = -px * Math.sin(th);
    };
    // ---------- power-up support ----------
    GameMgr.prototype.applySlow = function (seconds, scale) {
        this.slowT = seconds;
        this.timeScale = scale;
        this.slowOverlay.opacity = 50;
    };
    // ---------- callbacks from Player ----------
    GameMgr.prototype.onCrystal = function () {
        this.crystalsTaken++;
        Sfx_1.default.play("crystal", 0.7);
        this.refreshHud();
    };
    GameMgr.prototype.onDeath = function (dead) {
        var _this = this;
        if (this.state !== "run")
            return;
        this.deaths++;
        Sfx_1.default.play("death", 0.8);
        this.refreshHud();
        var survivor = this.anyAlive();
        if (survivor) {
            // partner carries on; camera follows them, dead player revives in 3s
            var follow = this.cameraNode.getComponent(CameraFollow_1.default);
            if (follow)
                follow.setTarget(survivor.node);
            this.scheduleOnce(function () {
                var s = _this.anyAlive();
                if (_this.state === "run" && s) {
                    dead.respawnAt(s.node.x - 50, s.node.y, s.getGravityDir());
                }
            }, 3);
            return;
        }
        // everyone is down — quick auto-retry keeps the rhythm going
        this.state = "dead";
        this.unscheduleAllCallbacks();
        this.scheduleOnce(function () {
            _this.respawnAll();
            _this.state = "run";
        }, 0.8);
    };
    GameMgr.prototype.anyAlive = function () {
        for (var _i = 0, _a = this.players; _i < _a.length; _i++) {
            var p = _a[_i];
            if (p.alive)
                return p;
        }
        return null;
    };
    GameMgr.prototype.onWin = function () {
        if (this.state !== "run")
            return;
        this.state = "win";
        this.unscheduleAllCallbacks();
        Sfx_1.default.play("win", 0.9);
        GameData_1.default.unlockNext(GameData_1.default.currentLevel);
        var last = GameData_1.default.currentLevel >= GameData_1.default.MAX_LEVEL;
        this.setMsg(last ? "YOU ESCAPED ASTRA-9!" : "LEVEL CLEAR!", "CRYSTALS " + this.crystalsTaken + "/" + this.level.totalCrystals
            + "    TIME " + this.formatTime(this.time)
            + "    DEATHS " + this.deaths
            + (last ? "    SPACE = MENU" : "    SPACE = NEXT    ESC = MENU"));
    };
    GameMgr.prototype.proceedAfterWin = function () {
        if (GameData_1.default.currentLevel < GameData_1.default.MAX_LEVEL) {
            GameData_1.default.currentLevel++;
            cc.director.loadScene("Game");
        }
        else {
            cc.director.loadScene("Menu");
        }
    };
    // ---------- per-frame ----------
    GameMgr.prototype.update = function (dt) {
        // keep HUD glued to the camera viewport
        if (this.hud && this.cameraNode) {
            this.hud.x = this.cameraNode.x;
            this.hud.y = this.cameraNode.y;
        }
        // animate field rotation at a constant rate, and re-anchor every frame
        // because the pivot (camera focus) keeps moving
        if (this.rotCurrent !== this.rotTarget) {
            var step = 110 * dt;
            var diff = this.rotTarget - this.rotCurrent;
            if (Math.abs(diff) <= step)
                this.rotCurrent = this.rotTarget;
            else
                this.rotCurrent += diff > 0 ? step : -step;
        }
        if (this.world)
            this.applyWorldRotation();
        if (this.state !== "run")
            return;
        this.time += dt;
        this.timeLabel.string = this.formatTime(this.time);
        // slow-motion timer
        if (this.slowT > 0) {
            this.slowT -= dt;
            if (this.slowT <= 0) {
                this.timeScale = 1;
                this.slowOverlay.opacity = 0;
            }
        }
        // patrol drones oscillate on a fixed deterministic clock
        this.enemyT += dt * this.timeScale;
        for (var _i = 0, _a = this.level.enemies; _i < _a.length; _i++) {
            var e = _a[_i];
            var off = Math.sin((this.enemyT + e.phase) * Math.PI * 2 / e.period) * e.range;
            if (e.axis === "x")
                e.node.x = e.x0 + off;
            else
                e.node.y = e.y0 + off;
        }
        // rotation zones track the leading living player
        var lead = this.anyAlive();
        if (lead)
            this.applyRotationForX(lead.node.x, false);
    };
    GameMgr = __decorate([
        ccclass
    ], GameMgr);
    return GameMgr;
}(cc.Component));
exports.default = GameMgr;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZU1nci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSx1Q0FBa0M7QUFDbEMsK0NBQXlEO0FBQ3pELG1DQUE4QjtBQUM5QiwrQ0FBMEM7QUFDMUMsNkJBQXdCO0FBRWhCLElBQUEsT0FBTyxHQUFLLEVBQUUsQ0FBQyxVQUFVLFFBQWxCLENBQW1CO0FBSWxDLDJFQUEyRTtBQUMzRSxtRkFBbUY7QUFDbkYsOEVBQThFO0FBQzlFLEVBQUU7QUFDRixtRUFBbUU7QUFDbkUseUVBQXlFO0FBQ3pFLDZEQUE2RDtBQUU3RDtJQUFxQywyQkFBWTtJQUFqRDtRQUFBLHFFQXVhQztRQXJhRywwRUFBMEU7UUFDMUUsZUFBUyxHQUFHLENBQUMsQ0FBQztRQUVOLGdCQUFVLEdBQVksSUFBSSxDQUFDO1FBQzNCLFdBQUssR0FBWSxJQUFJLENBQUM7UUFDdEIsU0FBRyxHQUFZLElBQUksQ0FBQztRQUNwQixhQUFPLEdBQWEsRUFBRSxDQUFDO1FBQ3ZCLFdBQUssR0FBYyxJQUFJLENBQUM7UUFDeEIsWUFBTSxHQUFvQyxFQUFFLENBQUM7UUFFN0MsV0FBSyxHQUFjLFNBQVMsQ0FBQztRQUM3QixVQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ1QsWUFBTSxHQUFHLENBQUMsQ0FBQztRQUNYLG1CQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQ2xCLFdBQUssR0FBRyxDQUFDLENBQUM7UUFDVixZQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ1gsZ0JBQVUsR0FBRyxDQUFDLENBQUM7UUFDZixlQUFTLEdBQUcsQ0FBQyxDQUFDO1FBRWQsZUFBUyxHQUFhLElBQUksQ0FBQztRQUMzQixrQkFBWSxHQUFhLElBQUksQ0FBQztRQUM5QixnQkFBVSxHQUFhLElBQUksQ0FBQztRQUM1QixlQUFTLEdBQWEsSUFBSSxDQUFDO1FBQzNCLGNBQVEsR0FBYSxJQUFJLENBQUM7UUFDMUIsY0FBUSxHQUFhLElBQUksQ0FBQztRQUMxQixpQkFBVyxHQUFZLElBQUksQ0FBQzs7SUE0WXhDLENBQUM7SUExWUcsMkJBQVMsR0FBVDtRQUNJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLENBQUM7SUFDaEMsQ0FBQztJQUVELHdCQUFNLEdBQU47UUFBQSxpQkFnQkM7UUFmRyxhQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDZCxhQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDZCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRTFELEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRWhFLEVBQUUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsV0FBVyxFQUFFLFVBQUMsR0FBRyxFQUFFLE1BQXdCO1lBQzNFLElBQUksR0FBRyxFQUFFO2dCQUNMLEVBQUUsQ0FBQyxLQUFLLENBQUMscUJBQXFCLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ3JDLE9BQU87YUFDVjtZQUNELEtBQWdCLFVBQU0sRUFBTixpQkFBTSxFQUFOLG9CQUFNLEVBQU4sSUFBTTtnQkFBakIsSUFBTSxDQUFDLGVBQUE7Z0JBQVksS0FBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQUE7WUFDaEQsS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDJCQUFTLEdBQVQ7UUFDSSxFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNoRixDQUFDO0lBRU8saUNBQWUsR0FBdkI7UUFBQSxpQkEwQkM7UUF6Qkcsd0VBQXdFO1FBQ3hFLGtEQUFrRDtRQUNsRCxJQUFNLEVBQUUsR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0IsSUFBTSxJQUFJLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1FBQzFDLEVBQUUsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsMENBQTBDO1FBQ3pFLElBQU0sQ0FBQyxHQUFHLGtCQUFRLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQztRQUN2QyxJQUFNLElBQUksR0FBRyxzQkFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUMxQyxFQUFFLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1RixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFL0IsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRWhCLEVBQUUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxrQkFBUSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsU0FBUyxFQUFFLFVBQUMsR0FBRyxFQUFFLEtBQW1CO1lBQzdGLElBQUksR0FBRyxFQUFFO2dCQUNMLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLGtCQUFRLENBQUMsWUFBWSxHQUFHLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDbEUsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDZCxPQUFPO2FBQ1Y7WUFDRCxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNoQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyw0QkFBVSxHQUFsQixVQUFtQixJQUFTO1FBQ3hCLElBQUksQ0FBQyxLQUFLLEdBQUcsc0JBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRS9ELElBQU0sS0FBSyxHQUFHLGtCQUFRLENBQUMsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDbEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM1QixJQUFNLEtBQUssR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDOUMsSUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDekMsRUFBRSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDN0QsRUFBRSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7WUFDeEMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzlCLElBQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsZ0JBQU0sQ0FBQyxDQUFDO1lBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4QjtRQUVELElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLHNCQUFZLENBQUMsQ0FBQztRQUMxRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztRQUM5RCxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7UUFFZCxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUNkLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsUUFBUSxHQUFHLGtCQUFRLENBQUMsWUFBWSxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUk7Y0FDNUUsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUM1QixLQUFLLEtBQUssQ0FBQztZQUNQLENBQUMsQ0FBQywwREFBMEQ7WUFDNUQsQ0FBQyxDQUFDLDZEQUE2RCxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVELDRCQUE0QjtJQUVwQiwyQkFBUyxHQUFqQixVQUFrQixNQUFlLEVBQUUsQ0FBUyxFQUFFLENBQVMsRUFBRSxJQUFZLEVBQUUsS0FBZSxFQUFFLE9BQXFCO1FBQXJCLHdCQUFBLEVBQUEsYUFBcUI7UUFDekcsSUFBTSxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ2hCLElBQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ25CLEVBQUUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUN6QixFQUFFLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkIsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRU8sMEJBQVEsR0FBaEI7UUFDSSx1RUFBdUU7UUFDdkUsK0RBQStEO1FBQy9ELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFbEMsSUFBTSxJQUFJLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3JDLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyQyxJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdEMsSUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRXRDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwRCxFQUFFLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsRUFBRSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7UUFDeEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXhDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ25FLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNuRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFFTyw0QkFBVSxHQUFsQjtRQUNJLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQztRQUNoRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNsRCxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRU8sNEJBQVUsR0FBbEIsVUFBbUIsQ0FBUztRQUN4QixJQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUM3QixJQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNyQixPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDNUYsQ0FBQztJQUVPLHdCQUFNLEdBQWQsVUFBZSxJQUFZLEVBQUUsR0FBVztRQUNwQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO0lBQy9CLENBQUM7SUFFRCw4QkFBOEI7SUFFdEIsMkJBQVMsR0FBakIsVUFBa0IsQ0FBeUI7UUFDdkMsUUFBUSxDQUFDLENBQUMsT0FBTyxFQUFFO1lBQ2YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7WUFDeEIsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNoQixJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLE1BQU07WUFDVixLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNO2dCQUNwQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25CLE1BQU07U0FDYjtJQUNMLENBQUM7SUFFTyx5QkFBTyxHQUFmLFVBQWdCLENBQXNCO1FBQ2xDLDBEQUEwRDtRQUMxRCxJQUFNLElBQUksR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCx1RUFBdUU7SUFDL0QsMEJBQVEsR0FBaEIsVUFBaUIsR0FBVztRQUN4QixRQUFRLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDaEIsS0FBSyxPQUFPO2dCQUNSLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUNuQixJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDcEIsTUFBTTtZQUNWLEtBQUssS0FBSyxDQUFDLENBQUM7Z0JBQ1IsSUFBTSxHQUFHLEdBQUcsa0JBQVEsQ0FBQyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0MsSUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUs7b0JBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUMzQixNQUFNO2FBQ1Q7WUFDRCxLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixNQUFNO1lBQ1YsS0FBSyxLQUFLO2dCQUNOLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFDdkIsTUFBTTtTQUNiO0lBQ0wsQ0FBQztJQUVPLDZCQUFXLEdBQW5CO1FBQ0ksSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLEtBQUssRUFBRTtZQUN0QixJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztZQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDO1NBQzFEO2FBQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLFFBQVEsRUFBRTtZQUNoQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNuQixJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN2QjthQUFNLElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLEVBQUU7WUFDN0IsRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRU8sNkJBQVcsR0FBbkI7UUFDSSxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUM7WUFBRSxPQUFPO1FBQ2xFLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFTyw0QkFBVSxHQUFsQjtRQUNJLEtBQWdCLFVBQVksRUFBWixLQUFBLElBQUksQ0FBQyxPQUFPLEVBQVosY0FBWSxFQUFaLElBQVk7WUFBdkIsSUFBTSxDQUFDLFNBQUE7WUFBa0IsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQUE7UUFDeEMsS0FBZ0IsVUFBbUIsRUFBbkIsS0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBbkIsY0FBbUIsRUFBbkIsSUFBbUIsRUFBRTtZQUFoQyxJQUFNLENBQUMsU0FBQTtZQUNSLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1lBQ2hCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUNyQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9DQUFvQztTQUNyRTtRQUNELEtBQWlCLFVBQW1CLEVBQW5CLEtBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQW5CLGNBQW1CLEVBQW5CLElBQW1CLEVBQUU7WUFBakMsSUFBTSxFQUFFLFNBQUE7WUFDVCxFQUFFLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNqQixFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7U0FDekI7UUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztRQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUNkLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2hCLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLHNCQUFZLENBQUMsQ0FBQztRQUMxRCxJQUFJLE1BQU0sRUFBRTtZQUNSLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN2QyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDakI7UUFDRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsdUNBQXVDO0lBRS9CLG1DQUFpQixHQUF6QixVQUEwQixDQUFTLEVBQUUsT0FBZ0I7UUFDakQsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2YsS0FBZ0IsVUFBb0IsRUFBcEIsS0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBcEIsY0FBb0IsRUFBcEIsSUFBb0IsRUFBRTtZQUFqQyxJQUFNLENBQUMsU0FBQTtZQUNSLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO1NBQ2xDO1FBQ0QsSUFBSSxNQUFNLEtBQUssSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQztZQUN4QixJQUFJLENBQUMsT0FBTztnQkFBRSxhQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUMzQztRQUNELElBQUksT0FBTyxFQUFFO1lBQ1QsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7WUFDekIsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBRUQsdUVBQXVFO0lBQ3ZFLDJFQUEyRTtJQUMzRSx1RUFBdUU7SUFDdkUsc0RBQXNEO0lBQzlDLG9DQUFrQixHQUExQjtRQUNJLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUM7UUFDM0MsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7UUFDckQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQseUNBQXlDO0lBRXpDLDJCQUFTLEdBQVQsVUFBVSxPQUFlLEVBQUUsS0FBYTtRQUNwQyxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUNyQixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN2QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELDhDQUE4QztJQUU5QywyQkFBUyxHQUFUO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLGFBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQseUJBQU8sR0FBUCxVQUFRLElBQVk7UUFBcEIsaUJBMkJDO1FBMUJHLElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLO1lBQUUsT0FBTztRQUNqQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZCxhQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN2QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFFbEIsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pDLElBQUksUUFBUSxFQUFFO1lBQ1YscUVBQXFFO1lBQ3JFLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLHNCQUFZLENBQUMsQ0FBQztZQUMxRCxJQUFJLE1BQU07Z0JBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDZCxJQUFNLENBQUMsR0FBRyxLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQzFCLElBQUksS0FBSSxDQUFDLEtBQUssS0FBSyxLQUFLLElBQUksQ0FBQyxFQUFFO29CQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQztpQkFDOUQ7WUFDTCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDTixPQUFPO1NBQ1Y7UUFFRCw2REFBNkQ7UUFDN0QsSUFBSSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7UUFDcEIsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDOUIsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUNkLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNsQixLQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUN2QixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDWixDQUFDO0lBRU8sMEJBQVEsR0FBaEI7UUFDSSxLQUFnQixVQUFZLEVBQVosS0FBQSxJQUFJLENBQUMsT0FBTyxFQUFaLGNBQVksRUFBWixJQUFZLEVBQUU7WUFBekIsSUFBTSxDQUFDLFNBQUE7WUFDUixJQUFJLENBQUMsQ0FBQyxLQUFLO2dCQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ3pCO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELHVCQUFLLEdBQUw7UUFDSSxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssS0FBSztZQUFFLE9BQU87UUFDakMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDOUIsYUFBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDckIsa0JBQVEsQ0FBQyxVQUFVLENBQUMsa0JBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMzQyxJQUFNLElBQUksR0FBRyxrQkFBUSxDQUFDLFlBQVksSUFBSSxrQkFBUSxDQUFDLFNBQVMsQ0FBQztRQUN6RCxJQUFJLENBQUMsTUFBTSxDQUNQLElBQUksQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLGNBQWMsRUFDOUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYTtjQUMvRCxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2NBQ3hDLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTTtjQUMzQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLENBQ25FLENBQUM7SUFDTixDQUFDO0lBRU8saUNBQWUsR0FBdkI7UUFDSSxJQUFJLGtCQUFRLENBQUMsWUFBWSxHQUFHLGtCQUFRLENBQUMsU0FBUyxFQUFFO1lBQzVDLGtCQUFRLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDeEIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDakM7YUFBTTtZQUNILEVBQUUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQztJQUVELGtDQUFrQztJQUVsQyx3QkFBTSxHQUFOLFVBQU8sRUFBVTtRQUNiLHdDQUF3QztRQUN4QyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUM3QixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztZQUMvQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztTQUNsQztRQUNELHVFQUF1RTtRQUN2RSxnREFBZ0Q7UUFDaEQsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDcEMsSUFBTSxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUN0QixJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7WUFDOUMsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUk7Z0JBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDOztnQkFDeEQsSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1NBQ25EO1FBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzFDLElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLO1lBQUUsT0FBTztRQUVqQyxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVuRCxvQkFBb0I7UUFDcEIsSUFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTtZQUNoQixJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQztZQUNqQixJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxFQUFFO2dCQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO2FBQ2hDO1NBQ0o7UUFFRCx5REFBeUQ7UUFDekQsSUFBSSxDQUFDLE1BQU0sSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxLQUFnQixVQUFrQixFQUFsQixLQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFsQixjQUFrQixFQUFsQixJQUFrQixFQUFFO1lBQS9CLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQ2pGLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHO2dCQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDOztnQkFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUM7U0FDOUI7UUFFRCxpREFBaUQ7UUFDakQsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzdCLElBQUksSUFBSTtZQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBdGFnQixPQUFPO1FBRDNCLE9BQU87T0FDYSxPQUFPLENBdWEzQjtJQUFELGNBQUM7Q0F2YUQsQUF1YUMsQ0F2YW9DLEVBQUUsQ0FBQyxTQUFTLEdBdWFoRDtrQkF2YW9CLE9BQU8iLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgR2FtZURhdGEgZnJvbSBcIi4vR2FtZURhdGFcIjtcbmltcG9ydCBMZXZlbEJ1aWxkZXIsIHsgTGV2ZWxEYXRhIH0gZnJvbSBcIi4vTGV2ZWxCdWlsZGVyXCI7XG5pbXBvcnQgUGxheWVyIGZyb20gXCIuL1BsYXllclwiO1xuaW1wb3J0IENhbWVyYUZvbGxvdyBmcm9tIFwiLi9DYW1lcmFGb2xsb3dcIjtcbmltcG9ydCBTZnggZnJvbSBcIi4vU2Z4XCI7XG5cbmNvbnN0IHsgY2NjbGFzcyB9ID0gY2MuX2RlY29yYXRvcjtcblxudHlwZSBHYW1lU3RhdGUgPSBcImxvYWRpbmdcIiB8IFwicmVhZHlcIiB8IFwicnVuXCIgfCBcImRlYWRcIiB8IFwid2luXCIgfCBcInBhdXNlZFwiO1xuXG4vLyBPd25zIHRoZSBHYW1lIHNjZW5lOiBsb2FkcyBhc3NldHMgKyBsZXZlbCBKU09OLCBidWlsZHMgdGhlIHdvcmxkIHRocm91Z2hcbi8vIExldmVsQnVpbGRlciwgc3Bhd25zIDEtMiBQbGF5ZXJzLCBhbmQgcnVucyB0aGUgcmVhZHkvcnVuL2RlYWQvd2luIHN0YXRlIG1hY2hpbmUuXG4vLyBFdmVyeXRoaW5nICh3b3JsZCwgSFVEKSBpcyBjcmVhdGVkIGluIGNvZGUg4oCUIHRoZSAuZmlyZSBzY2VuZSBzdGF5cyBtaW5pbWFsLlxuLy9cbi8vIENvLW9wIHJ1bGVzIChHYW1lRGF0YS5wbGF5ZXJzID09PSAyKTogUDEgPSBXIGtleSwgUDIgPSBVUC9TUEFDRS5cbi8vIElmIG9uZSBwbGF5ZXIgZGllcyB3aGlsZSB0aGUgcGFydG5lciBzdXJ2aXZlcywgdGhleSByZXZpdmUgbmV4dCB0byB0aGVcbi8vIHBhcnRuZXIgYWZ0ZXIgM3MuIElmIGV2ZXJ5b25lIGlzIGRlYWQsIHRoZSBsZXZlbCByZXN0YXJ0cy5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHYW1lTWdyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcblxuICAgIC8vIGdsb2JhbCBzbG93LW1vdGlvbiBmYWN0b3IgKHNsb3cgcG93ZXItdXApOyBQbGF5ZXIgbXVsdGlwbGllcyBkdCBieSB0aGlzXG4gICAgdGltZVNjYWxlID0gMTtcblxuICAgIHByaXZhdGUgY2FtZXJhTm9kZTogY2MuTm9kZSA9IG51bGw7XG4gICAgcHJpdmF0ZSB3b3JsZDogY2MuTm9kZSA9IG51bGw7XG4gICAgcHJpdmF0ZSBodWQ6IGNjLk5vZGUgPSBudWxsO1xuICAgIHByaXZhdGUgcGxheWVyczogUGxheWVyW10gPSBbXTtcbiAgICBwcml2YXRlIGxldmVsOiBMZXZlbERhdGEgPSBudWxsO1xuICAgIHByaXZhdGUgZnJhbWVzOiB7IFtrOiBzdHJpbmddOiBjYy5TcHJpdGVGcmFtZSB9ID0ge307XG5cbiAgICBwcml2YXRlIHN0YXRlOiBHYW1lU3RhdGUgPSBcImxvYWRpbmdcIjtcbiAgICBwcml2YXRlIHRpbWUgPSAwO1xuICAgIHByaXZhdGUgZGVhdGhzID0gMDtcbiAgICBwcml2YXRlIGNyeXN0YWxzVGFrZW4gPSAwO1xuICAgIHByaXZhdGUgc2xvd1QgPSAwO1xuICAgIHByaXZhdGUgZW5lbXlUID0gMDtcbiAgICBwcml2YXRlIHJvdEN1cnJlbnQgPSAwO1xuICAgIHByaXZhdGUgcm90VGFyZ2V0ID0gMDtcblxuICAgIHByaXZhdGUgbmFtZUxhYmVsOiBjYy5MYWJlbCA9IG51bGw7XG4gICAgcHJpdmF0ZSBjcnlzdGFsTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcbiAgICBwcml2YXRlIGRlYXRoTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcbiAgICBwcml2YXRlIHRpbWVMYWJlbDogY2MuTGFiZWwgPSBudWxsO1xuICAgIHByaXZhdGUgbXNnTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcbiAgICBwcml2YXRlIHN1YkxhYmVsOiBjYy5MYWJlbCA9IG51bGw7XG4gICAgcHJpdmF0ZSBzbG93T3ZlcmxheTogY2MuTm9kZSA9IG51bGw7XG5cbiAgICBpc1J1bm5pbmcoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLnN0YXRlID09PSBcInJ1blwiO1xuICAgIH1cblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgU2Z4LnByZWxvYWQoKTtcbiAgICAgICAgU2Z4LnBsYXlCZ20oKTtcbiAgICAgICAgdGhpcy5jYW1lcmFOb2RlID0gdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiTWFpbiBDYW1lcmFcIik7XG5cbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub24oY2MuU3lzdGVtRXZlbnQuRXZlbnRUeXBlLktFWV9ET1dOLCB0aGlzLm9uS2V5RG93biwgdGhpcyk7XG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoLCB0aGlzKTtcblxuICAgICAgICBjYy5yZXNvdXJjZXMubG9hZERpcihcInRleHR1cmVzXCIsIGNjLlNwcml0ZUZyYW1lLCAoZXJyLCBhc3NldHM6IGNjLlNwcml0ZUZyYW1lW10pID0+IHtcbiAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICBjYy5lcnJvcihcInRleHR1cmUgbG9hZCBmYWlsZWRcIiwgZXJyKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGEgb2YgYXNzZXRzKSB0aGlzLmZyYW1lc1thLm5hbWVdID0gYTtcbiAgICAgICAgICAgIHRoaXMub25UZXh0dXJlc1JlYWR5KCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG9uRGVzdHJveSgpIHtcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub2ZmKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfRE9XTiwgdGhpcy5vbktleURvd24sIHRoaXMpO1xuICAgIH1cblxuICAgIHByaXZhdGUgb25UZXh0dXJlc1JlYWR5KCkge1xuICAgICAgICAvLyBiYWNrZ3JvdW5kIHJpZGVzIGFsb25nIGFzIGEgY2hpbGQgb2YgdGhlIGNhbWVyYSAoYXV0byBzY3JlZW4tYWxpZ25lZCxcbiAgICAgICAgLy8gZXZlbiB3aGVuIHRoZSBjYW1lcmEgcm90YXRlcyBpbiByb3RhdGlvbiB6b25lcylcbiAgICAgICAgY29uc3QgYmcgPSBuZXcgY2MuTm9kZShcIkJHXCIpO1xuICAgICAgICBjb25zdCBiZ1NwID0gYmcuYWRkQ29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgIGJnU3Auc3ByaXRlRnJhbWUgPSB0aGlzLmZyYW1lc1tcImJnXCJdO1xuICAgICAgICBiZ1NwLnNpemVNb2RlID0gY2MuU3ByaXRlLlNpemVNb2RlLkNVU1RPTTtcbiAgICAgICAgYmcuc2V0Q29udGVudFNpemUoMTQwMCwgMTQwMCk7IC8vIG92ZXJzaXplZDogc3RheXMgY292ZXJpbmcgd2hpbGUgcm90YXRlZFxuICAgICAgICBjb25zdCBiID0gR2FtZURhdGEuc2V0dGluZ3MuYnJpZ2h0bmVzcztcbiAgICAgICAgY29uc3QgdGludCA9IExldmVsQnVpbGRlci5zY2hlbWUoKS5iZ1RpbnQ7XG4gICAgICAgIGJnLmNvbG9yID0gY2MuY29sb3IoTWF0aC5yb3VuZCh0aW50LnIgKiBiKSwgTWF0aC5yb3VuZCh0aW50LmcgKiBiKSwgTWF0aC5yb3VuZCh0aW50LmIgKiBiKSk7XG4gICAgICAgIHRoaXMuY2FtZXJhTm9kZS5hZGRDaGlsZChiZywgLTEwKTtcblxuICAgICAgICB0aGlzLndvcmxkID0gbmV3IGNjLk5vZGUoXCJXb3JsZFwiKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHRoaXMud29ybGQpO1xuXG4gICAgICAgIHRoaXMuYnVpbGRIdWQoKTtcblxuICAgICAgICBjYy5yZXNvdXJjZXMubG9hZChcImxldmVscy9sZXZlbFwiICsgR2FtZURhdGEuY3VycmVudExldmVsLCBjYy5Kc29uQXNzZXQsIChlcnIsIGFzc2V0OiBjYy5Kc29uQXNzZXQpID0+IHtcbiAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldE1zZyhcIkxFVkVMIFwiICsgR2FtZURhdGEuY3VycmVudExldmVsICsgXCIgTE9BRCBFUlJPUlwiLCBcIlwiKTtcbiAgICAgICAgICAgICAgICBjYy5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuc3RhcnRMZXZlbChhc3NldC5qc29uKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGFydExldmVsKGRhdGE6IGFueSkge1xuICAgICAgICB0aGlzLmxldmVsID0gTGV2ZWxCdWlsZGVyLmJ1aWxkKHRoaXMud29ybGQsIGRhdGEsIHRoaXMuZnJhbWVzKTtcblxuICAgICAgICBjb25zdCBjb3VudCA9IEdhbWVEYXRhLnBsYXllcnMgPT09IDIgPyAyIDogMTtcbiAgICAgICAgdGhpcy5wbGF5ZXJzID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQ7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcE5vZGUgPSBuZXcgY2MuTm9kZShcIlBsYXllclwiICsgKGkgKyAxKSk7XG4gICAgICAgICAgICBjb25zdCBzcCA9IHBOb2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICAgICAgc3Auc3ByaXRlRnJhbWUgPSB0aGlzLmZyYW1lc1tpID09PSAwID8gXCJwbGF5ZXJcIiA6IFwicGxheWVyMlwiXTtcbiAgICAgICAgICAgIHNwLnNpemVNb2RlID0gY2MuU3ByaXRlLlNpemVNb2RlLkNVU1RPTTtcbiAgICAgICAgICAgIHBOb2RlLnNldENvbnRlbnRTaXplKDM2LCAzNik7XG4gICAgICAgICAgICB0aGlzLndvcmxkLmFkZENoaWxkKHBOb2RlLCA1KTtcbiAgICAgICAgICAgIGNvbnN0IHAgPSBwTm9kZS5hZGRDb21wb25lbnQoUGxheWVyKTtcbiAgICAgICAgICAgIHAuaW5pdCh0aGlzLCB0aGlzLmxldmVsLCBpLCB0aGlzLmZyYW1lcyk7XG4gICAgICAgICAgICB0aGlzLnBsYXllcnMucHVzaChwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGZvbGxvdyA9IHRoaXMuY2FtZXJhTm9kZS5hZGRDb21wb25lbnQoQ2FtZXJhRm9sbG93KTtcbiAgICAgICAgZm9sbG93LmluaXQodGhpcy5wbGF5ZXJzWzBdLm5vZGUsIDAsIHRoaXMubGV2ZWwubGVuZ3RoIC0gNDgwKTtcbiAgICAgICAgZm9sbG93LnNuYXAoKTtcblxuICAgICAgICB0aGlzLnRpbWUgPSAwO1xuICAgICAgICB0aGlzLmRlYXRocyA9IDA7XG4gICAgICAgIHRoaXMuY3J5c3RhbHNUYWtlbiA9IDA7XG4gICAgICAgIHRoaXMudGltZVNjYWxlID0gMTtcbiAgICAgICAgdGhpcy5lbmVteVQgPSAwO1xuICAgICAgICB0aGlzLmFwcGx5Um90YXRpb25Gb3JYKHRoaXMubGV2ZWwuc3RhcnQueCwgdHJ1ZSk7XG4gICAgICAgIHRoaXMubmFtZUxhYmVsLnN0cmluZyA9IFwiTEVWRUwgXCIgKyBHYW1lRGF0YS5jdXJyZW50TGV2ZWwgKyBcIiDigJQgXCIgKyB0aGlzLmxldmVsLm5hbWVcbiAgICAgICAgICAgICsgKGNvdW50ID09PSAyID8gXCIgICBbMlBdXCIgOiBcIlwiKTtcbiAgICAgICAgdGhpcy5yZWZyZXNoSHVkKCk7XG4gICAgICAgIHRoaXMuc3RhdGUgPSBcInJlYWR5XCI7XG4gICAgICAgIHRoaXMuc2V0TXNnKFwiUFJFU1MgU1BBQ0UgVE8gUlVOXCIsXG4gICAgICAgICAgICBjb3VudCA9PT0gMlxuICAgICAgICAgICAgICAgID8gXCJQMTogVyA9IEZMSVAgICAgICBQMjogVVAgLyBTUEFDRSA9IEZMSVAgICAgICBSID0gUkVTVEFSVFwiXG4gICAgICAgICAgICAgICAgOiBcIlNQQUNFIC8gVyAvIFVQID0gRkxJUCBHUkFWSVRZICAgIFIgPSBSRVNUQVJUICAgIEVTQyA9IFBBVVNFXCIpO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0gSFVEIC0tLS0tLS0tLS1cblxuICAgIHByaXZhdGUgbWFrZUxhYmVsKHBhcmVudDogY2MuTm9kZSwgeDogbnVtYmVyLCB5OiBudW1iZXIsIHNpemU6IG51bWJlciwgY29sb3I6IGNjLkNvbG9yLCBhbmNob3JYOiBudW1iZXIgPSAwLjUpOiBjYy5MYWJlbCB7XG4gICAgICAgIGNvbnN0IG4gPSBuZXcgY2MuTm9kZShcImxhYmVsXCIpO1xuICAgICAgICBuLnNldFBvc2l0aW9uKHgsIHkpO1xuICAgICAgICBuLmFuY2hvclggPSBhbmNob3JYO1xuICAgICAgICBuLmNvbG9yID0gY29sb3I7XG4gICAgICAgIGNvbnN0IGxiID0gbi5hZGRDb21wb25lbnQoY2MuTGFiZWwpO1xuICAgICAgICBsYi5mb250U2l6ZSA9IHNpemU7XG4gICAgICAgIGxiLmxpbmVIZWlnaHQgPSBzaXplICsgNjtcbiAgICAgICAgbGIuc3RyaW5nID0gXCJcIjtcbiAgICAgICAgcGFyZW50LmFkZENoaWxkKG4pO1xuICAgICAgICByZXR1cm4gbGI7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBidWlsZEh1ZCgpIHtcbiAgICAgICAgLy8gSFVEIGlzIGEgc2libGluZyBvZiB0aGUgd29ybGQ7IHVwZGF0ZSgpIGtlZXBzIGl0IGdsdWVkIHRvIHRoZSBjYW1lcmFcbiAgICAgICAgLy8gKHBvc2l0aW9uIEFORCBhbmdsZSwgc28gaXQgc3RheXMgdXByaWdodCBpbiByb3RhdGlvbiB6b25lcykuXG4gICAgICAgIHRoaXMuaHVkID0gbmV3IGNjLk5vZGUoXCJIVURcIik7XG4gICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZCh0aGlzLmh1ZCwgMTAwKTtcblxuICAgICAgICBjb25zdCBjeWFuID0gY2MuY29sb3IoMTI3LCAyNDcsIDI1NSk7XG4gICAgICAgIGNvbnN0IHBpbmsgPSBjYy5jb2xvcigyNTUsIDEyMiwgMjAwKTtcbiAgICAgICAgY29uc3Qgb3JhbmdlID0gY2MuY29sb3IoMjU1LCAxODEsIDc0KTtcbiAgICAgICAgY29uc3Qgd2hpdGUgPSBjYy5jb2xvcigyMzUsIDI0MCwgMjU1KTtcblxuICAgICAgICB0aGlzLnNsb3dPdmVybGF5ID0gbmV3IGNjLk5vZGUoXCJzbG93RnhcIik7XG4gICAgICAgIGNvbnN0IHNvID0gdGhpcy5zbG93T3ZlcmxheS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgc28uc3ByaXRlRnJhbWUgPSB0aGlzLmZyYW1lc1tcIndoaXRlXCJdO1xuICAgICAgICBzby5zaXplTW9kZSA9IGNjLlNwcml0ZS5TaXplTW9kZS5DVVNUT007XG4gICAgICAgIHRoaXMuc2xvd092ZXJsYXkuc2V0Q29udGVudFNpemUoMTQwMCwgMTQwMCk7XG4gICAgICAgIHRoaXMuc2xvd092ZXJsYXkuY29sb3IgPSBjYy5jb2xvcigxMjAsIDE1MCwgMjU1KTtcbiAgICAgICAgdGhpcy5zbG93T3ZlcmxheS5vcGFjaXR5ID0gMDtcbiAgICAgICAgdGhpcy5odWQuYWRkQ2hpbGQodGhpcy5zbG93T3ZlcmxheSwgLTEpO1xuXG4gICAgICAgIHRoaXMubmFtZUxhYmVsID0gdGhpcy5tYWtlTGFiZWwodGhpcy5odWQsIC00NTAsIDI5NiwgMjAsIGN5YW4sIDApO1xuICAgICAgICB0aGlzLmNyeXN0YWxMYWJlbCA9IHRoaXMubWFrZUxhYmVsKHRoaXMuaHVkLCAtNDUwLCAyNjgsIDIwLCB3aGl0ZSwgMCk7XG4gICAgICAgIHRoaXMuZGVhdGhMYWJlbCA9IHRoaXMubWFrZUxhYmVsKHRoaXMuaHVkLCAtNDUwLCAyNDAsIDIwLCBwaW5rLCAwKTtcbiAgICAgICAgdGhpcy50aW1lTGFiZWwgPSB0aGlzLm1ha2VMYWJlbCh0aGlzLmh1ZCwgNDUwLCAyOTYsIDIwLCBvcmFuZ2UsIDEpO1xuICAgICAgICB0aGlzLm1zZ0xhYmVsID0gdGhpcy5tYWtlTGFiZWwodGhpcy5odWQsIDAsIDQwLCA0NCwgd2hpdGUpO1xuICAgICAgICB0aGlzLnN1YkxhYmVsID0gdGhpcy5tYWtlTGFiZWwodGhpcy5odWQsIDAsIC0xMCwgMTgsIGN5YW4pO1xuICAgIH1cblxuICAgIHByaXZhdGUgcmVmcmVzaEh1ZCgpIHtcbiAgICAgICAgdGhpcy5jcnlzdGFsTGFiZWwuc3RyaW5nID0gXCJDUllTVEFMUyAgXCIgKyB0aGlzLmNyeXN0YWxzVGFrZW4gKyBcIiAvIFwiICsgdGhpcy5sZXZlbC50b3RhbENyeXN0YWxzO1xuICAgICAgICB0aGlzLmRlYXRoTGFiZWwuc3RyaW5nID0gXCJERUFUSFMgIFwiICsgdGhpcy5kZWF0aHM7XG4gICAgICAgIHRoaXMudGltZUxhYmVsLnN0cmluZyA9IHRoaXMuZm9ybWF0VGltZSh0aGlzLnRpbWUpO1xuICAgIH1cblxuICAgIHByaXZhdGUgZm9ybWF0VGltZSh0OiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCBtID0gTWF0aC5mbG9vcih0IC8gNjApO1xuICAgICAgICBjb25zdCBzID0gdCAtIG0gKiA2MDtcbiAgICAgICAgcmV0dXJuIChtIDwgMTAgPyBcIjBcIiArIG0gOiBcIlwiICsgbSkgKyBcIjpcIiArIChzIDwgMTAgPyBcIjBcIiArIHMudG9GaXhlZCgxKSA6IHMudG9GaXhlZCgxKSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzZXRNc2cobWFpbjogc3RyaW5nLCBzdWI6IHN0cmluZykge1xuICAgICAgICB0aGlzLm1zZ0xhYmVsLnN0cmluZyA9IG1haW47XG4gICAgICAgIHRoaXMuc3ViTGFiZWwuc3RyaW5nID0gc3ViO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0gaW5wdXQgLS0tLS0tLS0tLVxuXG4gICAgcHJpdmF0ZSBvbktleURvd24oZTogY2MuRXZlbnQuRXZlbnRLZXlib2FyZCkge1xuICAgICAgICBzd2l0Y2ggKGUua2V5Q29kZSkge1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuc3BhY2U6XG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS51cDpcbiAgICAgICAgICAgICAgICB0aGlzLm9uQWN0aW9uKDEpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkudzpcbiAgICAgICAgICAgICAgICB0aGlzLm9uQWN0aW9uKDApO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkucjpcbiAgICAgICAgICAgICAgICB0aGlzLmZ1bGxSZXN0YXJ0KCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5lc2NhcGU6XG4gICAgICAgICAgICAgICAgdGhpcy50b2dnbGVQYXVzZSgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBvblRvdWNoKGU6IGNjLkV2ZW50LkV2ZW50VG91Y2gpIHtcbiAgICAgICAgLy8gMlAgdG91Y2g6IGxlZnQgaGFsZiBvZiB0aGUgc2NyZWVuID0gUDEsIHJpZ2h0IGhhbGYgPSBQMlxuICAgICAgICBjb25zdCBoYWxmID0gY2Mud2luU2l6ZS53aWR0aCAvIDI7XG4gICAgICAgIHRoaXMub25BY3Rpb24oZS5nZXRMb2NhdGlvblgoKSA8IGhhbGYgPyAwIDogMSk7XG4gICAgfVxuXG4gICAgLy8gd2hvOiAwID0gUDEgaW5wdXQsIDEgPSBQMiBpbnB1dCAoaW4gc29sbyBtb2RlIGV2ZXJ5IGlucHV0IGRyaXZlcyBQMSlcbiAgICBwcml2YXRlIG9uQWN0aW9uKHdobzogbnVtYmVyKSB7XG4gICAgICAgIHN3aXRjaCAodGhpcy5zdGF0ZSkge1xuICAgICAgICAgICAgY2FzZSBcInJlYWR5XCI6XG4gICAgICAgICAgICAgICAgdGhpcy5zdGF0ZSA9IFwicnVuXCI7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRNc2coXCJcIiwgXCJcIik7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwicnVuXCI6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZHggPSBHYW1lRGF0YS5wbGF5ZXJzID09PSAyID8gd2hvIDogMDtcbiAgICAgICAgICAgICAgICBjb25zdCBwID0gdGhpcy5wbGF5ZXJzW2lkeF07XG4gICAgICAgICAgICAgICAgaWYgKHAgJiYgcC5hbGl2ZSkgcC5mbGlwKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIFwicGF1c2VkXCI6XG4gICAgICAgICAgICAgICAgdGhpcy50b2dnbGVQYXVzZSgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBcIndpblwiOlxuICAgICAgICAgICAgICAgIHRoaXMucHJvY2VlZEFmdGVyV2luKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHRvZ2dsZVBhdXNlKCkge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZSA9PT0gXCJydW5cIikge1xuICAgICAgICAgICAgdGhpcy5zdGF0ZSA9IFwicGF1c2VkXCI7XG4gICAgICAgICAgICB0aGlzLnNldE1zZyhcIlBBVVNFRFwiLCBcIlNQQUNFID0gUkVTVU1FICAgIFIgPSBSRVNUQVJUXCIpO1xuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuc3RhdGUgPT09IFwicGF1c2VkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc3RhdGUgPSBcInJ1blwiO1xuICAgICAgICAgICAgdGhpcy5zZXRNc2coXCJcIiwgXCJcIik7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5zdGF0ZSA9PT0gXCJ3aW5cIikge1xuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiTWVudVwiKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgZnVsbFJlc3RhcnQoKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlID09PSBcImxvYWRpbmdcIiB8fCB0aGlzLnBsYXllcnMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgICAgIHRoaXMudW5zY2hlZHVsZUFsbENhbGxiYWNrcygpO1xuICAgICAgICB0aGlzLnJlc3Bhd25BbGwoKTtcbiAgICAgICAgdGhpcy5zdGF0ZSA9IFwicmVhZHlcIjtcbiAgICAgICAgdGhpcy5zZXRNc2coXCJQUkVTUyBTUEFDRSBUTyBSVU5cIiwgXCJcIik7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSByZXNwYXduQWxsKCkge1xuICAgICAgICBmb3IgKGNvbnN0IHAgb2YgdGhpcy5wbGF5ZXJzKSBwLnJlc2V0KCk7XG4gICAgICAgIGZvciAoY29uc3QgYyBvZiB0aGlzLmxldmVsLmNyeXN0YWxzKSB7XG4gICAgICAgICAgICBjLnRha2VuID0gZmFsc2U7XG4gICAgICAgICAgICBjLm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIGMubm9kZS5zZXRQb3NpdGlvbihjLngsIGMueSk7IC8vIG1hZ25ldCBtYXkgaGF2ZSBkcmFnZ2VkIGl0IGFyb3VuZFxuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgcHUgb2YgdGhpcy5sZXZlbC5wb3dlcnVwcykge1xuICAgICAgICAgICAgcHUudGFrZW4gPSBmYWxzZTtcbiAgICAgICAgICAgIHB1Lm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNyeXN0YWxzVGFrZW4gPSAwO1xuICAgICAgICB0aGlzLnRpbWUgPSAwO1xuICAgICAgICB0aGlzLnRpbWVTY2FsZSA9IDE7XG4gICAgICAgIHRoaXMuc2xvd1QgPSAwO1xuICAgICAgICB0aGlzLnNsb3dPdmVybGF5Lm9wYWNpdHkgPSAwO1xuICAgICAgICB0aGlzLmVuZW15VCA9IDA7XG4gICAgICAgIGNvbnN0IGZvbGxvdyA9IHRoaXMuY2FtZXJhTm9kZS5nZXRDb21wb25lbnQoQ2FtZXJhRm9sbG93KTtcbiAgICAgICAgaWYgKGZvbGxvdykge1xuICAgICAgICAgICAgZm9sbG93LnNldFRhcmdldCh0aGlzLnBsYXllcnNbMF0ubm9kZSk7XG4gICAgICAgICAgICBmb2xsb3cuc25hcCgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYXBwbHlSb3RhdGlvbkZvclgodGhpcy5sZXZlbC5zdGFydC54LCB0cnVlKTtcbiAgICAgICAgdGhpcy5yZWZyZXNoSHVkKCk7XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLSByb3RhdGlvbiB6b25lcyAtLS0tLS0tLS0tXG5cbiAgICBwcml2YXRlIGFwcGx5Um90YXRpb25Gb3JYKHg6IG51bWJlciwgaW5zdGFudDogYm9vbGVhbikge1xuICAgICAgICBsZXQgdGFyZ2V0ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCByIG9mIHRoaXMubGV2ZWwucm90YXRpb25zKSB7XG4gICAgICAgICAgICBpZiAoeCA+PSByLngpIHRhcmdldCA9IHIuYW5nbGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRhcmdldCAhPT0gdGhpcy5yb3RUYXJnZXQpIHtcbiAgICAgICAgICAgIHRoaXMucm90VGFyZ2V0ID0gdGFyZ2V0O1xuICAgICAgICAgICAgaWYgKCFpbnN0YW50KSBTZngucGxheShcInRlbGVwb3J0XCIsIDAuNCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluc3RhbnQpIHtcbiAgICAgICAgICAgIHRoaXMucm90Q3VycmVudCA9IHRhcmdldDtcbiAgICAgICAgICAgIHRoaXMuYXBwbHlXb3JsZFJvdGF0aW9uKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBSb3RhdGUgdGhlIFdPUkxEIG5vZGUgKG5vdCB0aGUgY2FtZXJhIOKAlCBjYy5DYW1lcmEgaW4gMi40IGlnbm9yZXMgaXRzXG4gICAgLy8gbm9kZSdzIHJvdGF0aW9uKSBhcm91bmQgdGhlIGNhbWVyYSdzIGZvY3VzIHBvaW50LiBPYnN0YWNsZXMsIHBsYXllcnMgYW5kXG4gICAgLy8gYXBwYXJlbnQgZ3Jhdml0eSBhbGwgcm90YXRlIG9uIHNjcmVlbiwgd2hpbGUgcGh5c2ljcyBzdGF5IDFEIGJlY2F1c2VcbiAgICAvLyBQbGF5ZXIgd29ya3MgaW4gdGhlIHdvcmxkIG5vZGUncyBsb2NhbCBjb29yZGluYXRlcy5cbiAgICBwcml2YXRlIGFwcGx5V29ybGRSb3RhdGlvbigpIHtcbiAgICAgICAgY29uc3QgdGggPSB0aGlzLnJvdEN1cnJlbnQgKiBNYXRoLlBJIC8gMTgwO1xuICAgICAgICBjb25zdCBweCA9IHRoaXMuY2FtZXJhTm9kZS54OyAvLyBjYW1lcmEgeSBpcyBhbHdheXMgMFxuICAgICAgICB0aGlzLndvcmxkLmFuZ2xlID0gdGhpcy5yb3RDdXJyZW50O1xuICAgICAgICB0aGlzLndvcmxkLnggPSBweCAtIHB4ICogTWF0aC5jb3ModGgpO1xuICAgICAgICB0aGlzLndvcmxkLnkgPSAtcHggKiBNYXRoLnNpbih0aCk7XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLSBwb3dlci11cCBzdXBwb3J0IC0tLS0tLS0tLS1cblxuICAgIGFwcGx5U2xvdyhzZWNvbmRzOiBudW1iZXIsIHNjYWxlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5zbG93VCA9IHNlY29uZHM7XG4gICAgICAgIHRoaXMudGltZVNjYWxlID0gc2NhbGU7XG4gICAgICAgIHRoaXMuc2xvd092ZXJsYXkub3BhY2l0eSA9IDUwO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0gY2FsbGJhY2tzIGZyb20gUGxheWVyIC0tLS0tLS0tLS1cblxuICAgIG9uQ3J5c3RhbCgpIHtcbiAgICAgICAgdGhpcy5jcnlzdGFsc1Rha2VuKys7XG4gICAgICAgIFNmeC5wbGF5KFwiY3J5c3RhbFwiLCAwLjcpO1xuICAgICAgICB0aGlzLnJlZnJlc2hIdWQoKTtcbiAgICB9XG5cbiAgICBvbkRlYXRoKGRlYWQ6IFBsYXllcikge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZSAhPT0gXCJydW5cIikgcmV0dXJuO1xuICAgICAgICB0aGlzLmRlYXRocysrO1xuICAgICAgICBTZngucGxheShcImRlYXRoXCIsIDAuOCk7XG4gICAgICAgIHRoaXMucmVmcmVzaEh1ZCgpO1xuXG4gICAgICAgIGNvbnN0IHN1cnZpdm9yID0gdGhpcy5hbnlBbGl2ZSgpO1xuICAgICAgICBpZiAoc3Vydml2b3IpIHtcbiAgICAgICAgICAgIC8vIHBhcnRuZXIgY2FycmllcyBvbjsgY2FtZXJhIGZvbGxvd3MgdGhlbSwgZGVhZCBwbGF5ZXIgcmV2aXZlcyBpbiAzc1xuICAgICAgICAgICAgY29uc3QgZm9sbG93ID0gdGhpcy5jYW1lcmFOb2RlLmdldENvbXBvbmVudChDYW1lcmFGb2xsb3cpO1xuICAgICAgICAgICAgaWYgKGZvbGxvdykgZm9sbG93LnNldFRhcmdldChzdXJ2aXZvci5ub2RlKTtcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKCgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzID0gdGhpcy5hbnlBbGl2ZSgpO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLnN0YXRlID09PSBcInJ1blwiICYmIHMpIHtcbiAgICAgICAgICAgICAgICAgICAgZGVhZC5yZXNwYXduQXQocy5ub2RlLnggLSA1MCwgcy5ub2RlLnksIHMuZ2V0R3Jhdml0eURpcigpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCAzKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGV2ZXJ5b25lIGlzIGRvd24g4oCUIHF1aWNrIGF1dG8tcmV0cnkga2VlcHMgdGhlIHJoeXRobSBnb2luZ1xuICAgICAgICB0aGlzLnN0YXRlID0gXCJkZWFkXCI7XG4gICAgICAgIHRoaXMudW5zY2hlZHVsZUFsbENhbGxiYWNrcygpO1xuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnJlc3Bhd25BbGwoKTtcbiAgICAgICAgICAgIHRoaXMuc3RhdGUgPSBcInJ1blwiO1xuICAgICAgICB9LCAwLjgpO1xuICAgIH1cblxuICAgIHByaXZhdGUgYW55QWxpdmUoKTogUGxheWVyIHtcbiAgICAgICAgZm9yIChjb25zdCBwIG9mIHRoaXMucGxheWVycykge1xuICAgICAgICAgICAgaWYgKHAuYWxpdmUpIHJldHVybiBwO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIG9uV2luKCkge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZSAhPT0gXCJydW5cIikgcmV0dXJuO1xuICAgICAgICB0aGlzLnN0YXRlID0gXCJ3aW5cIjtcbiAgICAgICAgdGhpcy51bnNjaGVkdWxlQWxsQ2FsbGJhY2tzKCk7XG4gICAgICAgIFNmeC5wbGF5KFwid2luXCIsIDAuOSk7XG4gICAgICAgIEdhbWVEYXRhLnVubG9ja05leHQoR2FtZURhdGEuY3VycmVudExldmVsKTtcbiAgICAgICAgY29uc3QgbGFzdCA9IEdhbWVEYXRhLmN1cnJlbnRMZXZlbCA+PSBHYW1lRGF0YS5NQVhfTEVWRUw7XG4gICAgICAgIHRoaXMuc2V0TXNnKFxuICAgICAgICAgICAgbGFzdCA/IFwiWU9VIEVTQ0FQRUQgQVNUUkEtOSFcIiA6IFwiTEVWRUwgQ0xFQVIhXCIsXG4gICAgICAgICAgICBcIkNSWVNUQUxTIFwiICsgdGhpcy5jcnlzdGFsc1Rha2VuICsgXCIvXCIgKyB0aGlzLmxldmVsLnRvdGFsQ3J5c3RhbHNcbiAgICAgICAgICAgICsgXCIgICAgVElNRSBcIiArIHRoaXMuZm9ybWF0VGltZSh0aGlzLnRpbWUpXG4gICAgICAgICAgICArIFwiICAgIERFQVRIUyBcIiArIHRoaXMuZGVhdGhzXG4gICAgICAgICAgICArIChsYXN0ID8gXCIgICAgU1BBQ0UgPSBNRU5VXCIgOiBcIiAgICBTUEFDRSA9IE5FWFQgICAgRVNDID0gTUVOVVwiKVxuICAgICAgICApO1xuICAgIH1cblxuICAgIHByaXZhdGUgcHJvY2VlZEFmdGVyV2luKCkge1xuICAgICAgICBpZiAoR2FtZURhdGEuY3VycmVudExldmVsIDwgR2FtZURhdGEuTUFYX0xFVkVMKSB7XG4gICAgICAgICAgICBHYW1lRGF0YS5jdXJyZW50TGV2ZWwrKztcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIkdhbWVcIik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJNZW51XCIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLSBwZXItZnJhbWUgLS0tLS0tLS0tLVxuXG4gICAgdXBkYXRlKGR0OiBudW1iZXIpIHtcbiAgICAgICAgLy8ga2VlcCBIVUQgZ2x1ZWQgdG8gdGhlIGNhbWVyYSB2aWV3cG9ydFxuICAgICAgICBpZiAodGhpcy5odWQgJiYgdGhpcy5jYW1lcmFOb2RlKSB7XG4gICAgICAgICAgICB0aGlzLmh1ZC54ID0gdGhpcy5jYW1lcmFOb2RlLng7XG4gICAgICAgICAgICB0aGlzLmh1ZC55ID0gdGhpcy5jYW1lcmFOb2RlLnk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gYW5pbWF0ZSBmaWVsZCByb3RhdGlvbiBhdCBhIGNvbnN0YW50IHJhdGUsIGFuZCByZS1hbmNob3IgZXZlcnkgZnJhbWVcbiAgICAgICAgLy8gYmVjYXVzZSB0aGUgcGl2b3QgKGNhbWVyYSBmb2N1cykga2VlcHMgbW92aW5nXG4gICAgICAgIGlmICh0aGlzLnJvdEN1cnJlbnQgIT09IHRoaXMucm90VGFyZ2V0KSB7XG4gICAgICAgICAgICBjb25zdCBzdGVwID0gMTEwICogZHQ7XG4gICAgICAgICAgICBjb25zdCBkaWZmID0gdGhpcy5yb3RUYXJnZXQgLSB0aGlzLnJvdEN1cnJlbnQ7XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMoZGlmZikgPD0gc3RlcCkgdGhpcy5yb3RDdXJyZW50ID0gdGhpcy5yb3RUYXJnZXQ7XG4gICAgICAgICAgICBlbHNlIHRoaXMucm90Q3VycmVudCArPSBkaWZmID4gMCA/IHN0ZXAgOiAtc3RlcDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy53b3JsZCkgdGhpcy5hcHBseVdvcmxkUm90YXRpb24oKTtcbiAgICAgICAgaWYgKHRoaXMuc3RhdGUgIT09IFwicnVuXCIpIHJldHVybjtcblxuICAgICAgICB0aGlzLnRpbWUgKz0gZHQ7XG4gICAgICAgIHRoaXMudGltZUxhYmVsLnN0cmluZyA9IHRoaXMuZm9ybWF0VGltZSh0aGlzLnRpbWUpO1xuXG4gICAgICAgIC8vIHNsb3ctbW90aW9uIHRpbWVyXG4gICAgICAgIGlmICh0aGlzLnNsb3dUID4gMCkge1xuICAgICAgICAgICAgdGhpcy5zbG93VCAtPSBkdDtcbiAgICAgICAgICAgIGlmICh0aGlzLnNsb3dUIDw9IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRpbWVTY2FsZSA9IDE7XG4gICAgICAgICAgICAgICAgdGhpcy5zbG93T3ZlcmxheS5vcGFjaXR5ID0gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHBhdHJvbCBkcm9uZXMgb3NjaWxsYXRlIG9uIGEgZml4ZWQgZGV0ZXJtaW5pc3RpYyBjbG9ja1xuICAgICAgICB0aGlzLmVuZW15VCArPSBkdCAqIHRoaXMudGltZVNjYWxlO1xuICAgICAgICBmb3IgKGNvbnN0IGUgb2YgdGhpcy5sZXZlbC5lbmVtaWVzKSB7XG4gICAgICAgICAgICBjb25zdCBvZmYgPSBNYXRoLnNpbigodGhpcy5lbmVteVQgKyBlLnBoYXNlKSAqIE1hdGguUEkgKiAyIC8gZS5wZXJpb2QpICogZS5yYW5nZTtcbiAgICAgICAgICAgIGlmIChlLmF4aXMgPT09IFwieFwiKSBlLm5vZGUueCA9IGUueDAgKyBvZmY7XG4gICAgICAgICAgICBlbHNlIGUubm9kZS55ID0gZS55MCArIG9mZjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHJvdGF0aW9uIHpvbmVzIHRyYWNrIHRoZSBsZWFkaW5nIGxpdmluZyBwbGF5ZXJcbiAgICAgICAgY29uc3QgbGVhZCA9IHRoaXMuYW55QWxpdmUoKTtcbiAgICAgICAgaWYgKGxlYWQpIHRoaXMuYXBwbHlSb3RhdGlvbkZvclgobGVhZC5ub2RlLngsIGZhbHNlKTtcbiAgICB9XG59XG4iXX0=