
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Sfx.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a1fddKPDD9HmrL1HaGWmp/l', 'Sfx');
// scripts/Sfx.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameData_1 = require("./GameData");
// Tiny audio helper. Clips live in assets/resources/audio/<name>.wav (or .mp3).
// All volumes are scaled by the user's settings (GameData.settings).
var Sfx = /** @class */ (function () {
    function Sfx() {
    }
    Sfx.preload = function () {
        var names = ["flip", "crystal", "death", "win", "click", "power", "teleport", "shieldbreak"];
        var _loop_1 = function (n) {
            if (Sfx.clips[n])
                return "continue";
            cc.resources.load("audio/" + n, cc.AudioClip, function (err, clip) {
                if (!err && clip)
                    Sfx.clips[n] = clip;
            });
        };
        for (var _i = 0, names_1 = names; _i < names_1.length; _i++) {
            var n = names_1[_i];
            _loop_1(n);
        }
    };
    Sfx.play = function (name, volume) {
        if (volume === void 0) { volume = 1; }
        var clip = Sfx.clips[name];
        var v = volume * GameData_1.default.settings.sfx;
        if (clip && v > 0)
            cc.audioEngine.play(clip, false, v);
    };
    // BGM is optional: drop a file at resources/audio/bgm.mp3 and this picks it up.
    Sfx.playBgm = function () {
        if (Sfx.bgmId >= 0) {
            Sfx.applyBgmVolume();
            return;
        }
        cc.resources.load("audio/bgm", cc.AudioClip, function (err, clip) {
            if (!err && clip && Sfx.bgmId < 0) {
                Sfx.bgmId = cc.audioEngine.play(clip, true, GameData_1.default.settings.bgm);
            }
        });
    };
    Sfx.applyBgmVolume = function () {
        if (Sfx.bgmId >= 0)
            cc.audioEngine.setVolume(Sfx.bgmId, GameData_1.default.settings.bgm);
    };
    Sfx.stopBgm = function () {
        if (Sfx.bgmId >= 0) {
            cc.audioEngine.stop(Sfx.bgmId);
            Sfx.bgmId = -1;
        }
    };
    Sfx.clips = {};
    Sfx.bgmId = -1;
    return Sfx;
}());
exports.default = Sfx;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcU2Z4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdUNBQWtDO0FBRWxDLGdGQUFnRjtBQUNoRixxRUFBcUU7QUFDckU7SUFBQTtJQTJDQSxDQUFDO0lBdkNVLFdBQU8sR0FBZDtRQUNJLElBQU0sS0FBSyxHQUFHLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLGFBQWEsQ0FBQyxDQUFDO2dDQUNwRixDQUFDO1lBQ1IsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztrQ0FBVztZQUMzQixFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsVUFBQyxHQUFHLEVBQUUsSUFBSTtnQkFDcEQsSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJO29CQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBVyxDQUFDO1lBQ2pELENBQUMsQ0FBQyxDQUFDOztRQUpQLEtBQWdCLFVBQUssRUFBTCxlQUFLLEVBQUwsbUJBQUssRUFBTCxJQUFLO1lBQWhCLElBQU0sQ0FBQyxjQUFBO29CQUFELENBQUM7U0FLWDtJQUNMLENBQUM7SUFFTSxRQUFJLEdBQVgsVUFBWSxJQUFZLEVBQUUsTUFBa0I7UUFBbEIsdUJBQUEsRUFBQSxVQUFrQjtRQUN4QyxJQUFNLElBQUksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzdCLElBQU0sQ0FBQyxHQUFHLE1BQU0sR0FBRyxrQkFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7UUFDekMsSUFBSSxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUM7WUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCxnRkFBZ0Y7SUFDekUsV0FBTyxHQUFkO1FBQ0ksSUFBSSxHQUFHLENBQUMsS0FBSyxJQUFJLENBQUMsRUFBRTtZQUNoQixHQUFHLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDckIsT0FBTztTQUNWO1FBQ0QsRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsVUFBQyxHQUFHLEVBQUUsSUFBSTtZQUNuRCxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTtnQkFDL0IsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFXLEVBQUUsSUFBSSxFQUFFLGtCQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzdFO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU0sa0JBQWMsR0FBckI7UUFDSSxJQUFJLEdBQUcsQ0FBQyxLQUFLLElBQUksQ0FBQztZQUFFLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsa0JBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbkYsQ0FBQztJQUVNLFdBQU8sR0FBZDtRQUNJLElBQUksR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLEVBQUU7WUFDaEIsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDbEI7SUFDTCxDQUFDO0lBekNjLFNBQUssR0FBcUMsRUFBRSxDQUFDO0lBQzdDLFNBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztJQXlDOUIsVUFBQztDQTNDRCxBQTJDQyxJQUFBO2tCQTNDb0IsR0FBRyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBHYW1lRGF0YSBmcm9tIFwiLi9HYW1lRGF0YVwiO1xuXG4vLyBUaW55IGF1ZGlvIGhlbHBlci4gQ2xpcHMgbGl2ZSBpbiBhc3NldHMvcmVzb3VyY2VzL2F1ZGlvLzxuYW1lPi53YXYgKG9yIC5tcDMpLlxuLy8gQWxsIHZvbHVtZXMgYXJlIHNjYWxlZCBieSB0aGUgdXNlcidzIHNldHRpbmdzIChHYW1lRGF0YS5zZXR0aW5ncykuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTZngge1xuICAgIHByaXZhdGUgc3RhdGljIGNsaXBzOiB7IFtuYW1lOiBzdHJpbmddOiBjYy5BdWRpb0NsaXAgfSA9IHt9O1xuICAgIHByaXZhdGUgc3RhdGljIGJnbUlkID0gLTE7XG5cbiAgICBzdGF0aWMgcHJlbG9hZCgpIHtcbiAgICAgICAgY29uc3QgbmFtZXMgPSBbXCJmbGlwXCIsIFwiY3J5c3RhbFwiLCBcImRlYXRoXCIsIFwid2luXCIsIFwiY2xpY2tcIiwgXCJwb3dlclwiLCBcInRlbGVwb3J0XCIsIFwic2hpZWxkYnJlYWtcIl07XG4gICAgICAgIGZvciAoY29uc3QgbiBvZiBuYW1lcykge1xuICAgICAgICAgICAgaWYgKFNmeC5jbGlwc1tuXSkgY29udGludWU7XG4gICAgICAgICAgICBjYy5yZXNvdXJjZXMubG9hZChcImF1ZGlvL1wiICsgbiwgY2MuQXVkaW9DbGlwLCAoZXJyLCBjbGlwKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFlcnIgJiYgY2xpcCkgU2Z4LmNsaXBzW25dID0gY2xpcCBhcyBhbnk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHN0YXRpYyBwbGF5KG5hbWU6IHN0cmluZywgdm9sdW1lOiBudW1iZXIgPSAxKSB7XG4gICAgICAgIGNvbnN0IGNsaXAgPSBTZnguY2xpcHNbbmFtZV07XG4gICAgICAgIGNvbnN0IHYgPSB2b2x1bWUgKiBHYW1lRGF0YS5zZXR0aW5ncy5zZng7XG4gICAgICAgIGlmIChjbGlwICYmIHYgPiAwKSBjYy5hdWRpb0VuZ2luZS5wbGF5KGNsaXAsIGZhbHNlLCB2KTtcbiAgICB9XG5cbiAgICAvLyBCR00gaXMgb3B0aW9uYWw6IGRyb3AgYSBmaWxlIGF0IHJlc291cmNlcy9hdWRpby9iZ20ubXAzIGFuZCB0aGlzIHBpY2tzIGl0IHVwLlxuICAgIHN0YXRpYyBwbGF5QmdtKCkge1xuICAgICAgICBpZiAoU2Z4LmJnbUlkID49IDApIHtcbiAgICAgICAgICAgIFNmeC5hcHBseUJnbVZvbHVtZSgpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNjLnJlc291cmNlcy5sb2FkKFwiYXVkaW8vYmdtXCIsIGNjLkF1ZGlvQ2xpcCwgKGVyciwgY2xpcCkgPT4ge1xuICAgICAgICAgICAgaWYgKCFlcnIgJiYgY2xpcCAmJiBTZnguYmdtSWQgPCAwKSB7XG4gICAgICAgICAgICAgICAgU2Z4LmJnbUlkID0gY2MuYXVkaW9FbmdpbmUucGxheShjbGlwIGFzIGFueSwgdHJ1ZSwgR2FtZURhdGEuc2V0dGluZ3MuYmdtKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgc3RhdGljIGFwcGx5QmdtVm9sdW1lKCkge1xuICAgICAgICBpZiAoU2Z4LmJnbUlkID49IDApIGNjLmF1ZGlvRW5naW5lLnNldFZvbHVtZShTZnguYmdtSWQsIEdhbWVEYXRhLnNldHRpbmdzLmJnbSk7XG4gICAgfVxuXG4gICAgc3RhdGljIHN0b3BCZ20oKSB7XG4gICAgICAgIGlmIChTZnguYmdtSWQgPj0gMCkge1xuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUuc3RvcChTZnguYmdtSWQpO1xuICAgICAgICAgICAgU2Z4LmJnbUlkID0gLTE7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=