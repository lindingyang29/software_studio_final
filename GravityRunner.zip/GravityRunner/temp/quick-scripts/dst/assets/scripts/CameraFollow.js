
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/CameraFollow.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '45c56IOadVCLoDL+QPsM0Cw', 'CameraFollow');
// scripts/CameraFollow.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var ccclass = cc._decorator.ccclass;
// Follows the player horizontally with a forward look-ahead.
// Attached at runtime by GameMgr; configure via init().
var CameraFollow = /** @class */ (function (_super) {
    __extends(CameraFollow, _super);
    function CameraFollow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.target = null;
        _this.minX = 0;
        _this.maxX = 0;
        _this.lookAhead = 160;
        _this.smooth = 10;
        return _this;
    }
    CameraFollow.prototype.init = function (target, minX, maxX) {
        this.target = target;
        this.minX = minX;
        this.maxX = Math.max(minX, maxX);
        this.node.x = minX;
        this.node.y = 0;
    };
    CameraFollow.prototype.setTarget = function (target) {
        this.target = target;
    };
    CameraFollow.prototype.snap = function () {
        if (!this.target)
            return;
        this.node.x = this.clampX(this.target.x + this.lookAhead);
    };
    CameraFollow.prototype.clampX = function (x) {
        return Math.max(this.minX, Math.min(this.maxX, x));
    };
    CameraFollow.prototype.update = function (dt) {
        if (!this.target || !this.target.isValid)
            return;
        var targetX = this.clampX(this.target.x + this.lookAhead);
        var t = Math.min(1, this.smooth * dt);
        this.node.x += (targetX - this.node.x) * t;
    };
    CameraFollow = __decorate([
        ccclass
    ], CameraFollow);
    return CameraFollow;
}(cc.Component));
exports.default = CameraFollow;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcQ2FtZXJhRm9sbG93LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFRLElBQUEsT0FBTyxHQUFLLEVBQUUsQ0FBQyxVQUFVLFFBQWxCLENBQW1CO0FBRWxDLDZEQUE2RDtBQUM3RCx3REFBd0Q7QUFFeEQ7SUFBMEMsZ0NBQVk7SUFBdEQ7UUFBQSxxRUFrQ0M7UUFqQ1csWUFBTSxHQUFZLElBQUksQ0FBQztRQUN2QixVQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ1QsVUFBSSxHQUFHLENBQUMsQ0FBQztRQUNULGVBQVMsR0FBRyxHQUFHLENBQUM7UUFDaEIsWUFBTSxHQUFHLEVBQUUsQ0FBQzs7SUE2QnhCLENBQUM7SUEzQkcsMkJBQUksR0FBSixVQUFLLE1BQWUsRUFBRSxJQUFZLEVBQUUsSUFBWTtRQUM1QyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUNyQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUNuQixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUVELGdDQUFTLEdBQVQsVUFBVSxNQUFlO1FBQ3JCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ3pCLENBQUM7SUFFRCwyQkFBSSxHQUFKO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO1lBQUUsT0FBTztRQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRU8sNkJBQU0sR0FBZCxVQUFlLENBQVM7UUFDcEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVELDZCQUFNLEdBQU4sVUFBTyxFQUFVO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ2pELElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzVELElBQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQWpDZ0IsWUFBWTtRQURoQyxPQUFPO09BQ2EsWUFBWSxDQWtDaEM7SUFBRCxtQkFBQztDQWxDRCxBQWtDQyxDQWxDeUMsRUFBRSxDQUFDLFNBQVMsR0FrQ3JEO2tCQWxDb0IsWUFBWSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHsgY2NjbGFzcyB9ID0gY2MuX2RlY29yYXRvcjtcblxuLy8gRm9sbG93cyB0aGUgcGxheWVyIGhvcml6b250YWxseSB3aXRoIGEgZm9yd2FyZCBsb29rLWFoZWFkLlxuLy8gQXR0YWNoZWQgYXQgcnVudGltZSBieSBHYW1lTWdyOyBjb25maWd1cmUgdmlhIGluaXQoKS5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDYW1lcmFGb2xsb3cgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIHByaXZhdGUgdGFyZ2V0OiBjYy5Ob2RlID0gbnVsbDtcbiAgICBwcml2YXRlIG1pblggPSAwO1xuICAgIHByaXZhdGUgbWF4WCA9IDA7XG4gICAgcHJpdmF0ZSBsb29rQWhlYWQgPSAxNjA7XG4gICAgcHJpdmF0ZSBzbW9vdGggPSAxMDtcblxuICAgIGluaXQodGFyZ2V0OiBjYy5Ob2RlLCBtaW5YOiBudW1iZXIsIG1heFg6IG51bWJlcikge1xuICAgICAgICB0aGlzLnRhcmdldCA9IHRhcmdldDtcbiAgICAgICAgdGhpcy5taW5YID0gbWluWDtcbiAgICAgICAgdGhpcy5tYXhYID0gTWF0aC5tYXgobWluWCwgbWF4WCk7XG4gICAgICAgIHRoaXMubm9kZS54ID0gbWluWDtcbiAgICAgICAgdGhpcy5ub2RlLnkgPSAwO1xuICAgIH1cblxuICAgIHNldFRhcmdldCh0YXJnZXQ6IGNjLk5vZGUpIHtcbiAgICAgICAgdGhpcy50YXJnZXQgPSB0YXJnZXQ7XG4gICAgfVxuXG4gICAgc25hcCgpIHtcbiAgICAgICAgaWYgKCF0aGlzLnRhcmdldCkgcmV0dXJuO1xuICAgICAgICB0aGlzLm5vZGUueCA9IHRoaXMuY2xhbXBYKHRoaXMudGFyZ2V0LnggKyB0aGlzLmxvb2tBaGVhZCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjbGFtcFgoeDogbnVtYmVyKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIE1hdGgubWF4KHRoaXMubWluWCwgTWF0aC5taW4odGhpcy5tYXhYLCB4KSk7XG4gICAgfVxuXG4gICAgdXBkYXRlKGR0OiBudW1iZXIpIHtcbiAgICAgICAgaWYgKCF0aGlzLnRhcmdldCB8fCAhdGhpcy50YXJnZXQuaXNWYWxpZCkgcmV0dXJuO1xuICAgICAgICBjb25zdCB0YXJnZXRYID0gdGhpcy5jbGFtcFgodGhpcy50YXJnZXQueCArIHRoaXMubG9va0FoZWFkKTtcbiAgICAgICAgY29uc3QgdCA9IE1hdGgubWluKDEsIHRoaXMuc21vb3RoICogZHQpO1xuICAgICAgICB0aGlzLm5vZGUueCArPSAodGFyZ2V0WCAtIHRoaXMubm9kZS54KSAqIHQ7XG4gICAgfVxufVxuIl19