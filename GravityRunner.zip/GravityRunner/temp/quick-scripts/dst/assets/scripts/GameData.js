
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/GameData.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '89e1fWBY4VFmLl3rdNbk3PK', 'GameData');
// scripts/GameData.ts

"use strict";
// Global game state shared across scenes (plain module, not a component).
Object.defineProperty(exports, "__esModule", { value: true });
var GameData = /** @class */ (function () {
    function GameData() {
    }
    GameData.getUnlocked = function () {
        var raw = cc.sys.localStorage.getItem(GameData.KEY);
        var v = parseInt(raw || "1", 10);
        if (isNaN(v) || v < 1)
            return 1;
        return Math.min(v, GameData.MAX_LEVEL);
    };
    GameData.unlockNext = function (clearedLevel) {
        var next = Math.min(clearedLevel + 1, GameData.MAX_LEVEL);
        if (next > GameData.getUnlocked()) {
            cc.sys.localStorage.setItem(GameData.KEY, String(next));
        }
    };
    GameData.loadSettings = function () {
        var def = { sfx: 1, bgm: 0.6, speed: 1, scheme: 0, brightness: 1 };
        try {
            var raw = cc.sys.localStorage.getItem(GameData.SETTINGS_KEY);
            if (raw) {
                var s = JSON.parse(raw);
                for (var k in def) {
                    if (typeof s[k] === "number")
                        def[k] = s[k];
                }
            }
        }
        catch (e) { /* corrupted settings -> defaults */ }
        return def;
    };
    GameData.saveSettings = function () {
        cc.sys.localStorage.setItem(GameData.SETTINGS_KEY, JSON.stringify(GameData.settings));
    };
    GameData.MAX_LEVEL = 3;
    // Which level the Game scene should load.
    GameData.currentLevel = 1;
    // 1 = solo, 2 = local co-op (P1=W, P2=UP/SPACE).
    GameData.players = 1;
    GameData.settings = GameData.loadSettings();
    GameData.KEY = "gfr_unlocked";
    GameData.SETTINGS_KEY = "gfr_settings";
    return GameData;
}());
exports.default = GameData;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZURhdGEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDBFQUEwRTs7QUFVMUU7SUFBQTtJQTZDQSxDQUFDO0lBL0JVLG9CQUFXLEdBQWxCO1FBQ0ksSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN0RCxJQUFNLENBQUMsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNuQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFTSxtQkFBVSxHQUFqQixVQUFrQixZQUFvQjtRQUNsQyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksR0FBRyxDQUFDLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzVELElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxXQUFXLEVBQUUsRUFBRTtZQUMvQixFQUFFLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUMzRDtJQUNMLENBQUM7SUFFYyxxQkFBWSxHQUEzQjtRQUNJLElBQU0sR0FBRyxHQUFhLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFDL0UsSUFBSTtZQUNBLElBQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDL0QsSUFBSSxHQUFHLEVBQUU7Z0JBQ0wsSUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDMUIsS0FBSyxJQUFNLENBQUMsSUFBSSxHQUFHLEVBQUU7b0JBQ2pCLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUTt3QkFBRyxHQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUN4RDthQUNKO1NBQ0o7UUFBQyxPQUFPLENBQUMsRUFBRSxFQUFFLG9DQUFvQyxFQUFFO1FBQ3BELE9BQU8sR0FBRyxDQUFDO0lBQ2YsQ0FBQztJQUVNLHFCQUFZLEdBQW5CO1FBQ0ksRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUMxRixDQUFDO0lBM0NlLGtCQUFTLEdBQUcsQ0FBQyxDQUFDO0lBRTlCLDBDQUEwQztJQUNuQyxxQkFBWSxHQUFHLENBQUMsQ0FBQztJQUV4QixpREFBaUQ7SUFDMUMsZ0JBQU8sR0FBRyxDQUFDLENBQUM7SUFFWixpQkFBUSxHQUFhLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUU1QixZQUFHLEdBQUcsY0FBYyxDQUFDO0lBQ3JCLHFCQUFZLEdBQUcsY0FBYyxDQUFDO0lBaUMxRCxlQUFDO0NBN0NELEFBNkNDLElBQUE7a0JBN0NvQixRQUFRIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gR2xvYmFsIGdhbWUgc3RhdGUgc2hhcmVkIGFjcm9zcyBzY2VuZXMgKHBsYWluIG1vZHVsZSwgbm90IGEgY29tcG9uZW50KS5cblxuZXhwb3J0IGludGVyZmFjZSBTZXR0aW5ncyB7XG4gICAgc2Z4OiBudW1iZXI7ICAgICAgICAvLyAwLi4xXG4gICAgYmdtOiBudW1iZXI7ICAgICAgICAvLyAwLi4xXG4gICAgc3BlZWQ6IG51bWJlcjsgICAgICAvLyBnYW1lIHNwZWVkIG11bHRpcGxpZXIgMC44IC8gMS4wIC8gMS4yXG4gICAgc2NoZW1lOiBudW1iZXI7ICAgICAvLyBjb2xvciBzY2hlbWUgaW5kZXgsIHNlZSBMZXZlbEJ1aWxkZXIuU0NIRU1FU1xuICAgIGJyaWdodG5lc3M6IG51bWJlcjsgLy8gMC42IC8gMC44IC8gMS4wXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdhbWVEYXRhIHtcbiAgICBzdGF0aWMgcmVhZG9ubHkgTUFYX0xFVkVMID0gMztcblxuICAgIC8vIFdoaWNoIGxldmVsIHRoZSBHYW1lIHNjZW5lIHNob3VsZCBsb2FkLlxuICAgIHN0YXRpYyBjdXJyZW50TGV2ZWwgPSAxO1xuXG4gICAgLy8gMSA9IHNvbG8sIDIgPSBsb2NhbCBjby1vcCAoUDE9VywgUDI9VVAvU1BBQ0UpLlxuICAgIHN0YXRpYyBwbGF5ZXJzID0gMTtcblxuICAgIHN0YXRpYyBzZXR0aW5nczogU2V0dGluZ3MgPSBHYW1lRGF0YS5sb2FkU2V0dGluZ3MoKTtcblxuICAgIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IEtFWSA9IFwiZ2ZyX3VubG9ja2VkXCI7XG4gICAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgU0VUVElOR1NfS0VZID0gXCJnZnJfc2V0dGluZ3NcIjtcblxuICAgIHN0YXRpYyBnZXRVbmxvY2tlZCgpOiBudW1iZXIge1xuICAgICAgICBjb25zdCByYXcgPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oR2FtZURhdGEuS0VZKTtcbiAgICAgICAgY29uc3QgdiA9IHBhcnNlSW50KHJhdyB8fCBcIjFcIiwgMTApO1xuICAgICAgICBpZiAoaXNOYU4odikgfHwgdiA8IDEpIHJldHVybiAxO1xuICAgICAgICByZXR1cm4gTWF0aC5taW4odiwgR2FtZURhdGEuTUFYX0xFVkVMKTtcbiAgICB9XG5cbiAgICBzdGF0aWMgdW5sb2NrTmV4dChjbGVhcmVkTGV2ZWw6IG51bWJlcikge1xuICAgICAgICBjb25zdCBuZXh0ID0gTWF0aC5taW4oY2xlYXJlZExldmVsICsgMSwgR2FtZURhdGEuTUFYX0xFVkVMKTtcbiAgICAgICAgaWYgKG5leHQgPiBHYW1lRGF0YS5nZXRVbmxvY2tlZCgpKSB7XG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oR2FtZURhdGEuS0VZLCBTdHJpbmcobmV4dCkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgbG9hZFNldHRpbmdzKCk6IFNldHRpbmdzIHtcbiAgICAgICAgY29uc3QgZGVmOiBTZXR0aW5ncyA9IHsgc2Z4OiAxLCBiZ206IDAuNiwgc3BlZWQ6IDEsIHNjaGVtZTogMCwgYnJpZ2h0bmVzczogMSB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmF3ID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKEdhbWVEYXRhLlNFVFRJTkdTX0tFWSk7XG4gICAgICAgICAgICBpZiAocmF3KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcyA9IEpTT04ucGFyc2UocmF3KTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGsgaW4gZGVmKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygc1trXSA9PT0gXCJudW1iZXJcIikgKGRlZiBhcyBhbnkpW2tdID0gc1trXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgLyogY29ycnVwdGVkIHNldHRpbmdzIC0+IGRlZmF1bHRzICovIH1cbiAgICAgICAgcmV0dXJuIGRlZjtcbiAgICB9XG5cbiAgICBzdGF0aWMgc2F2ZVNldHRpbmdzKCkge1xuICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oR2FtZURhdGEuU0VUVElOR1NfS0VZLCBKU09OLnN0cmluZ2lmeShHYW1lRGF0YS5zZXR0aW5ncykpO1xuICAgIH1cbn1cbiJdfQ==