
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd321bCHWN5HsYuFcKvZ02bl', 'Player');
// scripts/Player.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Sfx_1 = require("./Sfx");
var ccclass = cc._decorator.ccclass;
var GRAVITY = 2600;
var MAX_FALL = 1000;
var BODY_W = 30;
var BODY_H = 34;
// Auto-runner with flippable gravity. Pure kinematic AABB physics —
// no physics engine, so behavior is deterministic and easy to tune.
// Created and configured at runtime by GameMgr via init().
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.alive = true;
        _this.index = 0; // 0 = P1, 1 = P2
        _this.mgr = null;
        _this.level = null;
        _this.vy = 0;
        _this.gravityDir = -1; // -1: pulls toward floor, +1: toward ceiling
        _this.grounded = false;
        // power-up state
        _this.shield = false;
        _this.magnetT = 0;
        _this.invincibleT = 0;
        _this.shieldNode = null;
        _this.magnetAura = null;
        return _this;
    }
    Player.prototype.init = function (mgr, level, index, frames) {
        this.mgr = mgr;
        this.level = level;
        this.index = index;
        this.shieldNode = new cc.Node("shieldFx");
        var sp = this.shieldNode.addComponent(cc.Sprite);
        sp.spriteFrame = frames["shield"];
        sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.shieldNode.setContentSize(54, 54);
        this.shieldNode.active = false;
        this.node.addChild(this.shieldNode, 1);
        this.magnetAura = new cc.Node("magnetFx");
        var ms = this.magnetAura.addComponent(cc.Sprite);
        ms.spriteFrame = frames["glow"];
        ms.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.magnetAura.setContentSize(120, 120);
        this.magnetAura.color = cc.color(255, 230, 110);
        this.magnetAura.opacity = 150;
        this.magnetAura.active = false;
        this.node.addChild(this.magnetAura, -1);
        this.reset();
    };
    Player.prototype.reset = function () {
        this.node.stopAllActions();
        // P2 trails slightly behind so the cubes don't overlap
        this.node.setPosition(this.level.start.x - this.index * 60, this.level.start.y);
        this.vy = 0;
        this.gravityDir = -1;
        this.grounded = true;
        this.alive = true;
        this.shield = false;
        this.magnetT = 0;
        this.invincibleT = 0;
        this.shieldNode.active = false;
        this.magnetAura.active = false;
        this.node.active = true;
        this.node.opacity = 255;
        this.node.scaleX = 1;
        this.node.scaleY = 1;
        this.node.angle = 0;
    };
    // Co-op revive: drop in next to the surviving partner.
    Player.prototype.respawnAt = function (x, y, gravityDir) {
        this.node.stopAllActions();
        this.node.setPosition(x, y);
        this.vy = 0;
        this.gravityDir = gravityDir;
        this.grounded = false;
        this.alive = true;
        this.shield = false;
        this.magnetT = 0;
        this.shieldNode.active = false;
        this.magnetAura.active = false;
        this.node.active = true;
        this.node.opacity = 255;
        this.node.scaleX = 1;
        this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
        this.node.angle = 0;
        this.setInvincible(1.5);
    };
    Player.prototype.setInvincible = function (seconds) {
        this.invincibleT = seconds;
        this.node.stopAllActions();
        cc.tween(this.node)
            .repeat(Math.ceil(seconds / 0.3), cc.tween().to(0.15, { opacity: 90 }).to(0.15, { opacity: 255 }))
            .start();
    };
    Player.prototype.flip = function () {
        if (!this.alive || !this.grounded)
            return;
        this.gravityDir *= -1;
        this.grounded = false;
        this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
        Sfx_1.default.play("flip", 0.8);
    };
    Player.prototype.applyPower = function (type) {
        if (type === "shield") {
            this.shield = true;
            this.shieldNode.active = true;
        }
        else if (type === "magnet") {
            this.magnetT = 6;
        }
        else if (type === "slow") {
            this.mgr.applySlow(4, 0.55);
        }
        Sfx_1.default.play("power", 0.9);
    };
    Player.prototype.update = function (rawDt) {
        if (!this.alive || !this.mgr || !this.mgr.isRunning())
            return;
        var dt = Math.min(rawDt, 1 / 30) * this.mgr.timeScale;
        if (this.invincibleT > 0)
            this.invincibleT -= rawDt;
        if (this.magnetT > 0)
            this.magnetT -= rawDt;
        var n = this.node;
        n.x += this.level.speed * dt;
        this.vy += this.gravityDir * GRAVITY * dt;
        this.vy = Math.max(-MAX_FALL, Math.min(MAX_FALL, this.vy));
        n.y += this.vy * dt;
        this.grounded = false;
        for (var _i = 0, _a = this.level.solids; _i < _a.length; _i++) {
            var r = _a[_i];
            var px = (BODY_W + r.w) / 2 - Math.abs(n.x - r.x);
            if (px <= 0)
                continue;
            var py = (BODY_H + r.h) / 2 - Math.abs(n.y - r.y);
            if (py <= 0)
                continue;
            if (py <= px) {
                // vertical resolve (land or head-bump)
                var dir = n.y >= r.y ? 1 : -1;
                n.y += dir * py;
                this.vy = 0;
                if (dir === -this.gravityDir)
                    this.grounded = true;
            }
            else {
                // horizontal resolve — running into a wall face is lethal
                var dirx = n.x >= r.x ? 1 : -1;
                n.x += dirx * px;
                if (dirx < 0 && px > 6) {
                    this.hit("wall");
                    if (!this.alive)
                        return;
                }
            }
        }
        // teleporters (one-way, exits are always forward so no re-trigger)
        for (var _b = 0, _c = this.level.teleports; _b < _c.length; _b++) {
            var t = _c[_b];
            if (Math.abs(n.x - t.x) < 40 && Math.abs(n.y - t.y) < 40) {
                n.setPosition(t.tx, t.ty);
                this.vy = 0;
                this.gravityDir = t.ty >= 0 ? 1 : -1;
                this.grounded = false;
                this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
                Sfx_1.default.play("teleport", 0.9);
                break;
            }
        }
        // fell/flew out of the corridor through a gap (shield can't save this)
        if (Math.abs(n.y) > 520) {
            this.die();
            return;
        }
        // spikes (slightly forgiving hitbox)
        for (var _d = 0, _e = this.level.spikes; _d < _e.length; _d++) {
            var s = _e[_d];
            if (this.overlaps(s, -8)) {
                this.hit("spike");
                if (!this.alive)
                    return;
                break;
            }
        }
        // patrol drones
        for (var _f = 0, _g = this.level.enemies; _f < _g.length; _f++) {
            var e = _g[_f];
            if (Math.abs(n.x - e.node.x) < 32 && Math.abs(n.y - e.node.y) < 32) {
                this.hit("enemy");
                if (!this.alive)
                    return;
                break;
            }
        }
        // crystals — the magnet visibly drags them toward the player
        this.magnetAura.active = this.magnetT > 0;
        for (var _h = 0, _j = this.level.crystals; _h < _j.length; _h++) {
            var c = _j[_h];
            if (c.taken)
                continue;
            if (this.magnetT > 0) {
                var ddx = c.node.x - n.x;
                var ddy = c.node.y - n.y;
                var d = Math.sqrt(ddx * ddx + ddy * ddy);
                if (d > 1 && d < 230) {
                    var m = Math.min(1, (900 * dt) / d);
                    c.node.x -= ddx * m;
                    c.node.y -= ddy * m;
                }
            }
            if (Math.abs(c.node.x - n.x) < 38 && Math.abs(c.node.y - n.y) < 38) {
                c.taken = true;
                c.node.active = false;
                this.mgr.onCrystal();
            }
        }
        // powerups
        for (var _k = 0, _l = this.level.powerups; _k < _l.length; _k++) {
            var p = _l[_k];
            if (!p.taken && Math.abs(n.x - p.x) < 36 && Math.abs(n.y - p.y) < 36) {
                p.taken = true;
                p.node.active = false;
                this.applyPower(p.type);
            }
        }
        // goal
        if (this.overlaps(this.level.goal, 0)) {
            this.alive = false;
            this.mgr.onWin();
        }
    };
    Player.prototype.overlaps = function (r, shrink) {
        var n = this.node;
        return Math.abs(n.x - r.x) < (BODY_W + shrink + r.w) / 2 &&
            Math.abs(n.y - r.y) < (BODY_H + shrink + r.h) / 2;
    };
    // Lethal contact that a shield / invincibility may absorb.
    // Shield only saves spike/enemy hits — a wall face stops you physically,
    // so surviving it would leave the runner stuck (worse than death).
    Player.prototype.hit = function (cause) {
        if (this.invincibleT > 0)
            return;
        if (this.shield && cause !== "wall") {
            this.shield = false;
            this.shieldNode.active = false;
            Sfx_1.default.play("shieldbreak", 0.9);
            this.setInvincible(1.2);
            return;
        }
        this.die();
    };
    Player.prototype.die = function () {
        var _this = this;
        if (!this.alive)
            return;
        this.alive = false;
        this.node.stopAllActions();
        cc.tween(this.node)
            .parallel(cc.tween().to(0.35, { scale: 2.2, opacity: 0 }), cc.tween().by(0.35, { angle: 180 }))
            .call(function () { _this.node.active = false; })
            .start();
        this.mgr.onDeath(this);
    };
    Player.prototype.getGravityDir = function () {
        return this.gravityDir;
    };
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(cc.Component));
exports.default = Player;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcUGxheWVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLDZCQUF3QjtBQUdoQixJQUFBLE9BQU8sR0FBSyxFQUFFLENBQUMsVUFBVSxRQUFsQixDQUFtQjtBQUVsQyxJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUM7QUFDckIsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDO0FBQ3RCLElBQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNsQixJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFFbEIsb0VBQW9FO0FBQ3BFLG9FQUFvRTtBQUNwRSwyREFBMkQ7QUFFM0Q7SUFBb0MsMEJBQVk7SUFBaEQ7UUFBQSxxRUFxUUM7UUFwUUcsV0FBSyxHQUFHLElBQUksQ0FBQztRQUNiLFdBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7UUFFcEIsU0FBRyxHQUFZLElBQUksQ0FBQztRQUNwQixXQUFLLEdBQWMsSUFBSSxDQUFDO1FBQ3hCLFFBQUUsR0FBRyxDQUFDLENBQUM7UUFDUCxnQkFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsNkNBQTZDO1FBQzlELGNBQVEsR0FBRyxLQUFLLENBQUM7UUFFekIsaUJBQWlCO1FBQ1QsWUFBTSxHQUFHLEtBQUssQ0FBQztRQUNmLGFBQU8sR0FBRyxDQUFDLENBQUM7UUFDWixpQkFBVyxHQUFHLENBQUMsQ0FBQztRQUVoQixnQkFBVSxHQUFZLElBQUksQ0FBQztRQUMzQixnQkFBVSxHQUFZLElBQUksQ0FBQzs7SUFxUHZDLENBQUM7SUFuUEcscUJBQUksR0FBSixVQUFLLEdBQVksRUFBRSxLQUFnQixFQUFFLEtBQWEsRUFBRSxNQUF1QztRQUN2RixJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ25CLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBRW5CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzFDLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNuRCxFQUFFLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNsQyxFQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztRQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFdkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDMUMsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ25ELEVBQUUsQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2hDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFeEMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ2pCLENBQUM7SUFFRCxzQkFBSyxHQUFMO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMzQix1REFBdUQ7UUFDdkQsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2hGLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ1osSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztRQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUNwQixJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUNqQixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQUVELHVEQUF1RDtJQUN2RCwwQkFBUyxHQUFULFVBQVUsQ0FBUyxFQUFFLENBQVMsRUFBRSxVQUFrQjtRQUM5QyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM1QixJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNaLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1FBQzdCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3BCLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ3BCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVELDhCQUFhLEdBQWIsVUFBYyxPQUFlO1FBQ3pCLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDM0IsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQyxFQUM1QixFQUFFLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQzthQUNuRSxLQUFLLEVBQUUsQ0FBQztJQUNqQixDQUFDO0lBRUQscUJBQUksR0FBSjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxPQUFPO1FBQzFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEQsYUFBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVELDJCQUFVLEdBQVYsVUFBVyxJQUFZO1FBQ25CLElBQUksSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7U0FDakM7YUFBTSxJQUFJLElBQUksS0FBSyxRQUFRLEVBQUU7WUFDMUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7U0FDcEI7YUFBTSxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDeEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBQ0QsYUFBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQUVELHVCQUFNLEdBQU4sVUFBTyxLQUFhO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFO1lBQUUsT0FBTztRQUM5RCxJQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDeEQsSUFBSSxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUM7WUFBRSxJQUFJLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQztRQUNwRCxJQUFJLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQztZQUFFLElBQUksQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDO1FBRTVDLElBQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDcEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxHQUFHLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDMUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzNELENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUM7UUFFcEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsS0FBZ0IsVUFBaUIsRUFBakIsS0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBakIsY0FBaUIsRUFBakIsSUFBaUIsRUFBRTtZQUE5QixJQUFNLENBQUMsU0FBQTtZQUNSLElBQU0sRUFBRSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNwRCxJQUFJLEVBQUUsSUFBSSxDQUFDO2dCQUFFLFNBQVM7WUFDdEIsSUFBTSxFQUFFLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BELElBQUksRUFBRSxJQUFJLENBQUM7Z0JBQUUsU0FBUztZQUV0QixJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUU7Z0JBQ1YsdUNBQXVDO2dCQUN2QyxJQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ1osSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVTtvQkFBRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQzthQUN0RDtpQkFBTTtnQkFDSCwwREFBMEQ7Z0JBQzFELElBQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUNqQixJQUFJLElBQUksR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsRUFBRTtvQkFDcEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO3dCQUFFLE9BQU87aUJBQzNCO2FBQ0o7U0FDSjtRQUVELG1FQUFtRTtRQUNuRSxLQUFnQixVQUFvQixFQUFwQixLQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFwQixjQUFvQixFQUFwQixJQUFvQixFQUFFO1lBQWpDLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDdEQsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ1osSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoRCxhQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDMUIsTUFBTTthQUNUO1NBQ0o7UUFFRCx1RUFBdUU7UUFDdkUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUU7WUFDckIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ1gsT0FBTztTQUNWO1FBRUQscUNBQXFDO1FBQ3JDLEtBQWdCLFVBQWlCLEVBQWpCLEtBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQWpCLGNBQWlCLEVBQWpCLElBQWlCLEVBQUU7WUFBOUIsSUFBTSxDQUFDLFNBQUE7WUFDUixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2xCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztvQkFBRSxPQUFPO2dCQUN4QixNQUFNO2FBQ1Q7U0FDSjtRQUVELGdCQUFnQjtRQUNoQixLQUFnQixVQUFrQixFQUFsQixLQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFsQixjQUFrQixFQUFsQixJQUFrQixFQUFFO1lBQS9CLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUNoRSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUs7b0JBQUUsT0FBTztnQkFDeEIsTUFBTTthQUNUO1NBQ0o7UUFFRCw2REFBNkQ7UUFDN0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDMUMsS0FBZ0IsVUFBbUIsRUFBbkIsS0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBbkIsY0FBbUIsRUFBbkIsSUFBbUIsRUFBRTtZQUFoQyxJQUFNLENBQUMsU0FBQTtZQUNSLElBQUksQ0FBQyxDQUFDLEtBQUs7Z0JBQUUsU0FBUztZQUN0QixJQUFJLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFO2dCQUNsQixJQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixJQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixJQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO2dCQUMzQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRTtvQkFDbEIsSUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3RDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7b0JBQ3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCO2FBQ0o7WUFDRCxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUU7Z0JBQ2hFLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztnQkFDdEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUN4QjtTQUNKO1FBRUQsV0FBVztRQUNYLEtBQWdCLFVBQW1CLEVBQW5CLEtBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQW5CLGNBQW1CLEVBQW5CLElBQW1CLEVBQUU7WUFBaEMsSUFBTSxDQUFDLFNBQUE7WUFDUixJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDbEUsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2dCQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMzQjtTQUNKO1FBRUQsT0FBTztRQUNQLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRTtZQUNuQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNuQixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3BCO0lBQ0wsQ0FBQztJQUVPLHlCQUFRLEdBQWhCLFVBQWlCLENBQVUsRUFBRSxNQUFjO1FBQ3ZDLElBQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDcEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztZQUNqRCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFRCwyREFBMkQ7SUFDM0QseUVBQXlFO0lBQ3pFLG1FQUFtRTtJQUMzRCxvQkFBRyxHQUFYLFVBQVksS0FBYTtRQUNyQixJQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQztZQUFFLE9BQU87UUFDakMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUU7WUFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFDcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQy9CLGFBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzdCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDeEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ2YsQ0FBQztJQUVPLG9CQUFHLEdBQVg7UUFBQSxpQkFZQztRQVhHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztZQUFFLE9BQU87UUFDeEIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMzQixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDZCxRQUFRLENBQ0wsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUMvQyxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUN0QzthQUNBLElBQUksQ0FBQyxjQUFRLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN6QyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFRCw4QkFBYSxHQUFiO1FBQ0ksT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQzNCLENBQUM7SUFwUWdCLE1BQU07UUFEMUIsT0FBTztPQUNhLE1BQU0sQ0FxUTFCO0lBQUQsYUFBQztDQXJRRCxBQXFRQyxDQXJRbUMsRUFBRSxDQUFDLFNBQVMsR0FxUS9DO2tCQXJRb0IsTUFBTSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExldmVsRGF0YSwgUmVjdERlZiB9IGZyb20gXCIuL0xldmVsQnVpbGRlclwiO1xuaW1wb3J0IFNmeCBmcm9tIFwiLi9TZnhcIjtcbmltcG9ydCBHYW1lTWdyIGZyb20gXCIuL0dhbWVNZ3JcIjtcblxuY29uc3QgeyBjY2NsYXNzIH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5jb25zdCBHUkFWSVRZID0gMjYwMDtcbmNvbnN0IE1BWF9GQUxMID0gMTAwMDtcbmNvbnN0IEJPRFlfVyA9IDMwO1xuY29uc3QgQk9EWV9IID0gMzQ7XG5cbi8vIEF1dG8tcnVubmVyIHdpdGggZmxpcHBhYmxlIGdyYXZpdHkuIFB1cmUga2luZW1hdGljIEFBQkIgcGh5c2ljcyDigJRcbi8vIG5vIHBoeXNpY3MgZW5naW5lLCBzbyBiZWhhdmlvciBpcyBkZXRlcm1pbmlzdGljIGFuZCBlYXN5IHRvIHR1bmUuXG4vLyBDcmVhdGVkIGFuZCBjb25maWd1cmVkIGF0IHJ1bnRpbWUgYnkgR2FtZU1nciB2aWEgaW5pdCgpLlxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFBsYXllciBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG4gICAgYWxpdmUgPSB0cnVlO1xuICAgIGluZGV4ID0gMDsgLy8gMCA9IFAxLCAxID0gUDJcblxuICAgIHByaXZhdGUgbWdyOiBHYW1lTWdyID0gbnVsbDtcbiAgICBwcml2YXRlIGxldmVsOiBMZXZlbERhdGEgPSBudWxsO1xuICAgIHByaXZhdGUgdnkgPSAwO1xuICAgIHByaXZhdGUgZ3Jhdml0eURpciA9IC0xOyAvLyAtMTogcHVsbHMgdG93YXJkIGZsb29yLCArMTogdG93YXJkIGNlaWxpbmdcbiAgICBwcml2YXRlIGdyb3VuZGVkID0gZmFsc2U7XG5cbiAgICAvLyBwb3dlci11cCBzdGF0ZVxuICAgIHByaXZhdGUgc2hpZWxkID0gZmFsc2U7XG4gICAgcHJpdmF0ZSBtYWduZXRUID0gMDtcbiAgICBwcml2YXRlIGludmluY2libGVUID0gMDtcblxuICAgIHByaXZhdGUgc2hpZWxkTm9kZTogY2MuTm9kZSA9IG51bGw7XG4gICAgcHJpdmF0ZSBtYWduZXRBdXJhOiBjYy5Ob2RlID0gbnVsbDtcblxuICAgIGluaXQobWdyOiBHYW1lTWdyLCBsZXZlbDogTGV2ZWxEYXRhLCBpbmRleDogbnVtYmVyLCBmcmFtZXM6IHsgW2s6IHN0cmluZ106IGNjLlNwcml0ZUZyYW1lIH0pIHtcbiAgICAgICAgdGhpcy5tZ3IgPSBtZ3I7XG4gICAgICAgIHRoaXMubGV2ZWwgPSBsZXZlbDtcbiAgICAgICAgdGhpcy5pbmRleCA9IGluZGV4O1xuXG4gICAgICAgIHRoaXMuc2hpZWxkTm9kZSA9IG5ldyBjYy5Ob2RlKFwic2hpZWxkRnhcIik7XG4gICAgICAgIGNvbnN0IHNwID0gdGhpcy5zaGllbGROb2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICBzcC5zcHJpdGVGcmFtZSA9IGZyYW1lc1tcInNoaWVsZFwiXTtcbiAgICAgICAgc3Auc2l6ZU1vZGUgPSBjYy5TcHJpdGUuU2l6ZU1vZGUuQ1VTVE9NO1xuICAgICAgICB0aGlzLnNoaWVsZE5vZGUuc2V0Q29udGVudFNpemUoNTQsIDU0KTtcbiAgICAgICAgdGhpcy5zaGllbGROb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQodGhpcy5zaGllbGROb2RlLCAxKTtcblxuICAgICAgICB0aGlzLm1hZ25ldEF1cmEgPSBuZXcgY2MuTm9kZShcIm1hZ25ldEZ4XCIpO1xuICAgICAgICBjb25zdCBtcyA9IHRoaXMubWFnbmV0QXVyYS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgbXMuc3ByaXRlRnJhbWUgPSBmcmFtZXNbXCJnbG93XCJdO1xuICAgICAgICBtcy5zaXplTW9kZSA9IGNjLlNwcml0ZS5TaXplTW9kZS5DVVNUT007XG4gICAgICAgIHRoaXMubWFnbmV0QXVyYS5zZXRDb250ZW50U2l6ZSgxMjAsIDEyMCk7XG4gICAgICAgIHRoaXMubWFnbmV0QXVyYS5jb2xvciA9IGNjLmNvbG9yKDI1NSwgMjMwLCAxMTApO1xuICAgICAgICB0aGlzLm1hZ25ldEF1cmEub3BhY2l0eSA9IDE1MDtcbiAgICAgICAgdGhpcy5tYWduZXRBdXJhLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQodGhpcy5tYWduZXRBdXJhLCAtMSk7XG5cbiAgICAgICAgdGhpcy5yZXNldCgpO1xuICAgIH1cblxuICAgIHJlc2V0KCkge1xuICAgICAgICB0aGlzLm5vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgLy8gUDIgdHJhaWxzIHNsaWdodGx5IGJlaGluZCBzbyB0aGUgY3ViZXMgZG9uJ3Qgb3ZlcmxhcFxuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24odGhpcy5sZXZlbC5zdGFydC54IC0gdGhpcy5pbmRleCAqIDYwLCB0aGlzLmxldmVsLnN0YXJ0LnkpO1xuICAgICAgICB0aGlzLnZ5ID0gMDtcbiAgICAgICAgdGhpcy5ncmF2aXR5RGlyID0gLTE7XG4gICAgICAgIHRoaXMuZ3JvdW5kZWQgPSB0cnVlO1xuICAgICAgICB0aGlzLmFsaXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zaGllbGQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tYWduZXRUID0gMDtcbiAgICAgICAgdGhpcy5pbnZpbmNpYmxlVCA9IDA7XG4gICAgICAgIHRoaXMuc2hpZWxkTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tYWduZXRBdXJhLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAyNTU7XG4gICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAxO1xuICAgICAgICB0aGlzLm5vZGUuc2NhbGVZID0gMTtcbiAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gMDtcbiAgICB9XG5cbiAgICAvLyBDby1vcCByZXZpdmU6IGRyb3AgaW4gbmV4dCB0byB0aGUgc3Vydml2aW5nIHBhcnRuZXIuXG4gICAgcmVzcGF3bkF0KHg6IG51bWJlciwgeTogbnVtYmVyLCBncmF2aXR5RGlyOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5ub2RlLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih4LCB5KTtcbiAgICAgICAgdGhpcy52eSA9IDA7XG4gICAgICAgIHRoaXMuZ3Jhdml0eURpciA9IGdyYXZpdHlEaXI7XG4gICAgICAgIHRoaXMuZ3JvdW5kZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5hbGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMuc2hpZWxkID0gZmFsc2U7XG4gICAgICAgIHRoaXMubWFnbmV0VCA9IDA7XG4gICAgICAgIHRoaXMuc2hpZWxkTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tYWduZXRBdXJhLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAyNTU7XG4gICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAxO1xuICAgICAgICB0aGlzLm5vZGUuc2NhbGVZID0gdGhpcy5ncmF2aXR5RGlyID4gMCA/IC0xIDogMTtcbiAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gMDtcbiAgICAgICAgdGhpcy5zZXRJbnZpbmNpYmxlKDEuNSk7XG4gICAgfVxuXG4gICAgc2V0SW52aW5jaWJsZShzZWNvbmRzOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5pbnZpbmNpYmxlVCA9IHNlY29uZHM7XG4gICAgICAgIHRoaXMubm9kZS5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICBjYy50d2Vlbih0aGlzLm5vZGUpXG4gICAgICAgICAgICAucmVwZWF0KE1hdGguY2VpbChzZWNvbmRzIC8gMC4zKSxcbiAgICAgICAgICAgICAgICBjYy50d2VlbigpLnRvKDAuMTUsIHsgb3BhY2l0eTogOTAgfSkudG8oMC4xNSwgeyBvcGFjaXR5OiAyNTUgfSkpXG4gICAgICAgICAgICAuc3RhcnQoKTtcbiAgICB9XG5cbiAgICBmbGlwKCkge1xuICAgICAgICBpZiAoIXRoaXMuYWxpdmUgfHwgIXRoaXMuZ3JvdW5kZWQpIHJldHVybjtcbiAgICAgICAgdGhpcy5ncmF2aXR5RGlyICo9IC0xO1xuICAgICAgICB0aGlzLmdyb3VuZGVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMubm9kZS5zY2FsZVkgPSB0aGlzLmdyYXZpdHlEaXIgPiAwID8gLTEgOiAxO1xuICAgICAgICBTZngucGxheShcImZsaXBcIiwgMC44KTtcbiAgICB9XG5cbiAgICBhcHBseVBvd2VyKHR5cGU6IHN0cmluZykge1xuICAgICAgICBpZiAodHlwZSA9PT0gXCJzaGllbGRcIikge1xuICAgICAgICAgICAgdGhpcy5zaGllbGQgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5zaGllbGROb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJtYWduZXRcIikge1xuICAgICAgICAgICAgdGhpcy5tYWduZXRUID0gNjtcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlID09PSBcInNsb3dcIikge1xuICAgICAgICAgICAgdGhpcy5tZ3IuYXBwbHlTbG93KDQsIDAuNTUpO1xuICAgICAgICB9XG4gICAgICAgIFNmeC5wbGF5KFwicG93ZXJcIiwgMC45KTtcbiAgICB9XG5cbiAgICB1cGRhdGUocmF3RHQ6IG51bWJlcikge1xuICAgICAgICBpZiAoIXRoaXMuYWxpdmUgfHwgIXRoaXMubWdyIHx8ICF0aGlzLm1nci5pc1J1bm5pbmcoKSkgcmV0dXJuO1xuICAgICAgICBjb25zdCBkdCA9IE1hdGgubWluKHJhd0R0LCAxIC8gMzApICogdGhpcy5tZ3IudGltZVNjYWxlO1xuICAgICAgICBpZiAodGhpcy5pbnZpbmNpYmxlVCA+IDApIHRoaXMuaW52aW5jaWJsZVQgLT0gcmF3RHQ7XG4gICAgICAgIGlmICh0aGlzLm1hZ25ldFQgPiAwKSB0aGlzLm1hZ25ldFQgLT0gcmF3RHQ7XG5cbiAgICAgICAgY29uc3QgbiA9IHRoaXMubm9kZTtcbiAgICAgICAgbi54ICs9IHRoaXMubGV2ZWwuc3BlZWQgKiBkdDtcbiAgICAgICAgdGhpcy52eSArPSB0aGlzLmdyYXZpdHlEaXIgKiBHUkFWSVRZICogZHQ7XG4gICAgICAgIHRoaXMudnkgPSBNYXRoLm1heCgtTUFYX0ZBTEwsIE1hdGgubWluKE1BWF9GQUxMLCB0aGlzLnZ5KSk7XG4gICAgICAgIG4ueSArPSB0aGlzLnZ5ICogZHQ7XG5cbiAgICAgICAgdGhpcy5ncm91bmRlZCA9IGZhbHNlO1xuICAgICAgICBmb3IgKGNvbnN0IHIgb2YgdGhpcy5sZXZlbC5zb2xpZHMpIHtcbiAgICAgICAgICAgIGNvbnN0IHB4ID0gKEJPRFlfVyArIHIudykgLyAyIC0gTWF0aC5hYnMobi54IC0gci54KTtcbiAgICAgICAgICAgIGlmIChweCA8PSAwKSBjb250aW51ZTtcbiAgICAgICAgICAgIGNvbnN0IHB5ID0gKEJPRFlfSCArIHIuaCkgLyAyIC0gTWF0aC5hYnMobi55IC0gci55KTtcbiAgICAgICAgICAgIGlmIChweSA8PSAwKSBjb250aW51ZTtcblxuICAgICAgICAgICAgaWYgKHB5IDw9IHB4KSB7XG4gICAgICAgICAgICAgICAgLy8gdmVydGljYWwgcmVzb2x2ZSAobGFuZCBvciBoZWFkLWJ1bXApXG4gICAgICAgICAgICAgICAgY29uc3QgZGlyID0gbi55ID49IHIueSA/IDEgOiAtMTtcbiAgICAgICAgICAgICAgICBuLnkgKz0gZGlyICogcHk7XG4gICAgICAgICAgICAgICAgdGhpcy52eSA9IDA7XG4gICAgICAgICAgICAgICAgaWYgKGRpciA9PT0gLXRoaXMuZ3Jhdml0eURpcikgdGhpcy5ncm91bmRlZCA9IHRydWU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIGhvcml6b250YWwgcmVzb2x2ZSDigJQgcnVubmluZyBpbnRvIGEgd2FsbCBmYWNlIGlzIGxldGhhbFxuICAgICAgICAgICAgICAgIGNvbnN0IGRpcnggPSBuLnggPj0gci54ID8gMSA6IC0xO1xuICAgICAgICAgICAgICAgIG4ueCArPSBkaXJ4ICogcHg7XG4gICAgICAgICAgICAgICAgaWYgKGRpcnggPCAwICYmIHB4ID4gNikge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmhpdChcIndhbGxcIik7XG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5hbGl2ZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHRlbGVwb3J0ZXJzIChvbmUtd2F5LCBleGl0cyBhcmUgYWx3YXlzIGZvcndhcmQgc28gbm8gcmUtdHJpZ2dlcilcbiAgICAgICAgZm9yIChjb25zdCB0IG9mIHRoaXMubGV2ZWwudGVsZXBvcnRzKSB7XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMobi54IC0gdC54KSA8IDQwICYmIE1hdGguYWJzKG4ueSAtIHQueSkgPCA0MCkge1xuICAgICAgICAgICAgICAgIG4uc2V0UG9zaXRpb24odC50eCwgdC50eSk7XG4gICAgICAgICAgICAgICAgdGhpcy52eSA9IDA7XG4gICAgICAgICAgICAgICAgdGhpcy5ncmF2aXR5RGlyID0gdC50eSA+PSAwID8gMSA6IC0xO1xuICAgICAgICAgICAgICAgIHRoaXMuZ3JvdW5kZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuc2NhbGVZID0gdGhpcy5ncmF2aXR5RGlyID4gMCA/IC0xIDogMTtcbiAgICAgICAgICAgICAgICBTZngucGxheShcInRlbGVwb3J0XCIsIDAuOSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBmZWxsL2ZsZXcgb3V0IG9mIHRoZSBjb3JyaWRvciB0aHJvdWdoIGEgZ2FwIChzaGllbGQgY2FuJ3Qgc2F2ZSB0aGlzKVxuICAgICAgICBpZiAoTWF0aC5hYnMobi55KSA+IDUyMCkge1xuICAgICAgICAgICAgdGhpcy5kaWUoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHNwaWtlcyAoc2xpZ2h0bHkgZm9yZ2l2aW5nIGhpdGJveClcbiAgICAgICAgZm9yIChjb25zdCBzIG9mIHRoaXMubGV2ZWwuc3Bpa2VzKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5vdmVybGFwcyhzLCAtOCkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmhpdChcInNwaWtlXCIpO1xuICAgICAgICAgICAgICAgIGlmICghdGhpcy5hbGl2ZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gcGF0cm9sIGRyb25lc1xuICAgICAgICBmb3IgKGNvbnN0IGUgb2YgdGhpcy5sZXZlbC5lbmVtaWVzKSB7XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMobi54IC0gZS5ub2RlLngpIDwgMzIgJiYgTWF0aC5hYnMobi55IC0gZS5ub2RlLnkpIDwgMzIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmhpdChcImVuZW15XCIpO1xuICAgICAgICAgICAgICAgIGlmICghdGhpcy5hbGl2ZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gY3J5c3RhbHMg4oCUIHRoZSBtYWduZXQgdmlzaWJseSBkcmFncyB0aGVtIHRvd2FyZCB0aGUgcGxheWVyXG4gICAgICAgIHRoaXMubWFnbmV0QXVyYS5hY3RpdmUgPSB0aGlzLm1hZ25ldFQgPiAwO1xuICAgICAgICBmb3IgKGNvbnN0IGMgb2YgdGhpcy5sZXZlbC5jcnlzdGFscykge1xuICAgICAgICAgICAgaWYgKGMudGFrZW4pIGNvbnRpbnVlO1xuICAgICAgICAgICAgaWYgKHRoaXMubWFnbmV0VCA+IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkZHggPSBjLm5vZGUueCAtIG4ueDtcbiAgICAgICAgICAgICAgICBjb25zdCBkZHkgPSBjLm5vZGUueSAtIG4ueTtcbiAgICAgICAgICAgICAgICBjb25zdCBkID0gTWF0aC5zcXJ0KGRkeCAqIGRkeCArIGRkeSAqIGRkeSk7XG4gICAgICAgICAgICAgICAgaWYgKGQgPiAxICYmIGQgPCAyMzApIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbSA9IE1hdGgubWluKDEsICg5MDAgKiBkdCkgLyBkKTtcbiAgICAgICAgICAgICAgICAgICAgYy5ub2RlLnggLT0gZGR4ICogbTtcbiAgICAgICAgICAgICAgICAgICAgYy5ub2RlLnkgLT0gZGR5ICogbTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMoYy5ub2RlLnggLSBuLngpIDwgMzggJiYgTWF0aC5hYnMoYy5ub2RlLnkgLSBuLnkpIDwgMzgpIHtcbiAgICAgICAgICAgICAgICBjLnRha2VuID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBjLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5tZ3Iub25DcnlzdGFsKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBwb3dlcnVwc1xuICAgICAgICBmb3IgKGNvbnN0IHAgb2YgdGhpcy5sZXZlbC5wb3dlcnVwcykge1xuICAgICAgICAgICAgaWYgKCFwLnRha2VuICYmIE1hdGguYWJzKG4ueCAtIHAueCkgPCAzNiAmJiBNYXRoLmFicyhuLnkgLSBwLnkpIDwgMzYpIHtcbiAgICAgICAgICAgICAgICBwLnRha2VuID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBwLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5hcHBseVBvd2VyKHAudHlwZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBnb2FsXG4gICAgICAgIGlmICh0aGlzLm92ZXJsYXBzKHRoaXMubGV2ZWwuZ29hbCwgMCkpIHtcbiAgICAgICAgICAgIHRoaXMuYWxpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMubWdyLm9uV2luKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIG92ZXJsYXBzKHI6IFJlY3REZWYsIHNocmluazogbnVtYmVyKTogYm9vbGVhbiB7XG4gICAgICAgIGNvbnN0IG4gPSB0aGlzLm5vZGU7XG4gICAgICAgIHJldHVybiBNYXRoLmFicyhuLnggLSByLngpIDwgKEJPRFlfVyArIHNocmluayArIHIudykgLyAyICYmXG4gICAgICAgICAgICAgICBNYXRoLmFicyhuLnkgLSByLnkpIDwgKEJPRFlfSCArIHNocmluayArIHIuaCkgLyAyO1xuICAgIH1cblxuICAgIC8vIExldGhhbCBjb250YWN0IHRoYXQgYSBzaGllbGQgLyBpbnZpbmNpYmlsaXR5IG1heSBhYnNvcmIuXG4gICAgLy8gU2hpZWxkIG9ubHkgc2F2ZXMgc3Bpa2UvZW5lbXkgaGl0cyDigJQgYSB3YWxsIGZhY2Ugc3RvcHMgeW91IHBoeXNpY2FsbHksXG4gICAgLy8gc28gc3Vydml2aW5nIGl0IHdvdWxkIGxlYXZlIHRoZSBydW5uZXIgc3R1Y2sgKHdvcnNlIHRoYW4gZGVhdGgpLlxuICAgIHByaXZhdGUgaGl0KGNhdXNlOiBzdHJpbmcpIHtcbiAgICAgICAgaWYgKHRoaXMuaW52aW5jaWJsZVQgPiAwKSByZXR1cm47XG4gICAgICAgIGlmICh0aGlzLnNoaWVsZCAmJiBjYXVzZSAhPT0gXCJ3YWxsXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc2hpZWxkID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLnNoaWVsZE5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICBTZngucGxheShcInNoaWVsZGJyZWFrXCIsIDAuOSk7XG4gICAgICAgICAgICB0aGlzLnNldEludmluY2libGUoMS4yKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmRpZSgpO1xuICAgIH1cblxuICAgIHByaXZhdGUgZGllKCkge1xuICAgICAgICBpZiAoIXRoaXMuYWxpdmUpIHJldHVybjtcbiAgICAgICAgdGhpcy5hbGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgY2MudHdlZW4odGhpcy5ub2RlKVxuICAgICAgICAgICAgLnBhcmFsbGVsKFxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKCkudG8oMC4zNSwgeyBzY2FsZTogMi4yLCBvcGFjaXR5OiAwIH0pLFxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKCkuYnkoMC4zNSwgeyBhbmdsZTogMTgwIH0pXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuY2FsbCgoKSA9PiB7IHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTsgfSlcbiAgICAgICAgICAgIC5zdGFydCgpO1xuICAgICAgICB0aGlzLm1nci5vbkRlYXRoKHRoaXMpO1xuICAgIH1cblxuICAgIGdldEdyYXZpdHlEaXIoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ3Jhdml0eURpcjtcbiAgICB9XG59XG4iXX0=