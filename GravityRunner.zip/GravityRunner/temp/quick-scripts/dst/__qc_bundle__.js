
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scripts/CameraFollow');
require('./assets/scripts/GameData');
require('./assets/scripts/GameMgr');
require('./assets/scripts/LevelBuilder');
require('./assets/scripts/MenuCtrl');
require('./assets/scripts/Player');
require('./assets/scripts/Sfx');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/MenuCtrl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '36f6bzcenBCwpmegGFN63R7', 'MenuCtrl');
// scripts/MenuCtrl.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GameData_1 = require("./GameData");
var LevelBuilder_1 = require("./LevelBuilder");
var Sfx_1 = require("./Sfx");
var ccclass = cc._decorator.ccclass;
// Main menu — built entirely in code (the .fire scene only has Canvas + Camera).
// Mode select (1P / 2P), level buttons, and a settings overlay
// (sfx/bgm volume, game speed, color scheme, brightness).
var MenuCtrl = /** @class */ (function (_super) {
    __extends(MenuCtrl, _super);
    function MenuCtrl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.frames = {};
        _this.bgNode = null;
        _this.modeButtons = [];
        _this.hintLabel = null;
        _this.settingsPanel = null;
        return _this;
    }
    MenuCtrl.prototype.onLoad = function () {
        var _this = this;
        Sfx_1.default.preload();
        Sfx_1.default.playBgm();
        cc.resources.loadDir("textures", cc.SpriteFrame, function (err, assets) {
            if (err) {
                cc.error("texture load failed", err);
                return;
            }
            for (var _i = 0, assets_1 = assets; _i < assets_1.length; _i++) {
                var a = assets_1[_i];
                _this.frames[a.name] = a;
            }
            _this.buildUi();
        });
        cc.director.preloadScene("Game");
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    };
    MenuCtrl.prototype.onDestroy = function () {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    };
    MenuCtrl.prototype.sprite = function (parent, frame, x, y, w, h, color) {
        var n = new cc.Node(frame);
        var sp = n.addComponent(cc.Sprite);
        sp.spriteFrame = this.frames[frame];
        sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        n.setContentSize(w, h);
        n.setPosition(x, y);
        if (color)
            n.color = color;
        parent.addChild(n);
        return n;
    };
    MenuCtrl.prototype.label = function (parent, text, x, y, size, color, anchorX) {
        if (anchorX === void 0) { anchorX = 0.5; }
        var n = new cc.Node("label");
        n.setPosition(x, y);
        n.anchorX = anchorX;
        n.color = color;
        var lb = n.addComponent(cc.Label);
        lb.string = text;
        lb.fontSize = size;
        lb.lineHeight = size + 6;
        parent.addChild(n);
        return n;
    };
    MenuCtrl.prototype.applyBgTint = function () {
        if (!this.bgNode)
            return;
        var b = GameData_1.default.settings.brightness;
        var t = LevelBuilder_1.default.scheme().bgTint;
        this.bgNode.color = cc.color(Math.round(t.r * b), Math.round(t.g * b), Math.round(t.b * b));
    };
    MenuCtrl.prototype.buildUi = function () {
        var _this = this;
        var cyan = cc.color(127, 247, 255);
        var orange = cc.color(255, 181, 74);
        var white = cc.color(235, 240, 255);
        var dim = cc.color(110, 120, 150);
        this.bgNode = this.sprite(this.node, "bg", 0, 0, 970, 650);
        this.applyBgTint();
        // title
        var title = this.label(this.node, "GRAVITY FLIP RUNNER", 0, 230, 56, cyan);
        cc.tween(title)
            .to(1.4, { opacity: 170 }, { easing: "sineInOut" })
            .to(1.4, { opacity: 255 }, { easing: "sineInOut" })
            .repeatForever()
            .start();
        this.label(this.node, "— ESCAPE ASTRA-9 —", 0, 178, 18, orange);
        // decorations
        var deco = this.sprite(this.node, "player", -340, 60, 48, 48);
        cc.tween(deco)
            .to(1.2, { y: 85 }, { easing: "sineInOut" })
            .to(1.2, { y: 60 }, { easing: "sineInOut" })
            .repeatForever()
            .start();
        var deco2 = this.sprite(this.node, "player2", -340, -40, 40, 40);
        deco2.scaleY = -1;
        cc.tween(deco2)
            .to(1.5, { y: -65 }, { easing: "sineInOut" })
            .to(1.5, { y: -40 }, { easing: "sineInOut" })
            .repeatForever()
            .start();
        var c1 = this.sprite(this.node, "crystal", 340, 20, 30, 30);
        cc.tween(c1).by(2.4, { angle: 360 }).repeatForever().start();
        // mode select: 1P / 2P
        this.modeButtons = [];
        var _loop_1 = function (m) {
            var x = m === 1 ? -75 : 75;
            var btn = this_1.sprite(this_1.node, "white", x, 118, 130, 44, cc.color(24, 34, 76));
            this_1.label(btn, m === 1 ? "1 PLAYER" : "2 PLAYERS", 0, 0, 18, white);
            btn.on(cc.Node.EventType.TOUCH_END, function () {
                Sfx_1.default.play("click", 0.8);
                GameData_1.default.players = m;
                _this.refreshModeButtons();
            });
            this_1.modeButtons.push(btn);
        };
        var this_1 = this;
        for (var m = 1; m <= 2; m++) {
            _loop_1(m);
        }
        this.refreshModeButtons();
        // level buttons
        var unlocked = GameData_1.default.getUnlocked();
        var _loop_2 = function (i) {
            var open = i <= unlocked;
            var y = 50 - i * 72;
            var btn = this_2.sprite(this_2.node, "white", 0, y, 260, 56, open ? cc.color(24, 34, 76) : cc.color(22, 24, 34));
            this_2.sprite(this_2.node, "white", 0, y - 26, 260, 3, open ? cyan : dim);
            this_2.label(btn, open ? "LEVEL " + i : "LEVEL " + i + "  [LOCKED]", 0, 0, 24, open ? white : dim);
            if (open) {
                btn.on(cc.Node.EventType.TOUCH_END, function () {
                    Sfx_1.default.play("click", 0.8);
                    GameData_1.default.currentLevel = i;
                    cc.director.loadScene("Game");
                });
            }
        };
        var this_2 = this;
        for (var i = 1; i <= GameData_1.default.MAX_LEVEL; i++) {
            _loop_2(i);
        }
        // settings button
        var sBtn = this.sprite(this.node, "white", 0, -226, 200, 44, cc.color(40, 30, 70));
        this.label(sBtn, "SETTINGS", 0, 0, 20, orange);
        sBtn.on(cc.Node.EventType.TOUCH_END, function () {
            Sfx_1.default.play("click", 0.8);
            _this.toggleSettings();
        });
        this.hintLabel = this.label(this.node, "SPACE / W / UP : FLIP      R : RESTART      ESC : PAUSE      [SPACE = QUICK START]", 0, -286, 15, dim);
    };
    MenuCtrl.prototype.refreshModeButtons = function () {
        var sel = cc.color(53, 100, 150);
        var norm = cc.color(24, 34, 76);
        for (var m = 0; m < 2; m++) {
            this.modeButtons[m].color = GameData_1.default.players === m + 1 ? sel : norm;
        }
        if (this.hintLabel) {
            var lb = this.hintLabel.getComponent(cc.Label);
            lb.string = GameData_1.default.players === 2
                ? "P1 : W = FLIP      P2 : UP / SPACE = FLIP      R : RESTART      ESC : PAUSE"
                : "SPACE / W / UP : FLIP      R : RESTART      ESC : PAUSE      [SPACE = QUICK START]";
        }
    };
    // ---------- settings panel ----------
    MenuCtrl.prototype.toggleSettings = function () {
        if (this.settingsPanel) {
            this.settingsPanel.destroy();
            this.settingsPanel = null;
            return;
        }
        this.buildSettingsPanel();
    };
    MenuCtrl.prototype.buildSettingsPanel = function () {
        var _this = this;
        var white = cc.color(235, 240, 255);
        var cyan = cc.color(127, 247, 255);
        var orange = cc.color(255, 181, 74);
        var panel = this.sprite(this.node, "white", 0, 0, 560, 460, cc.color(10, 12, 26));
        panel.opacity = 245;
        panel.zIndex = 50;
        this.settingsPanel = panel;
        // swallow clicks behind the panel
        panel.on(cc.Node.EventType.TOUCH_START, function (e) { e.stopPropagation(); });
        this.label(panel, "SETTINGS", 0, 190, 30, orange);
        this.label(panel, "click a row to change", 0, 158, 14, cc.color(110, 120, 150));
        var s = GameData_1.default.settings;
        var pct = function (v) { return Math.round(v * 100) + "%"; };
        var rows = [
            {
                name: "SFX VOLUME",
                value: function () { return pct(s.sfx); },
                next: function () { s.sfx = s.sfx >= 1 ? 0 : Math.min(1, s.sfx + 0.25); Sfx_1.default.play("crystal", 0.8); }
            },
            {
                name: "MUSIC VOLUME",
                value: function () { return pct(s.bgm); },
                next: function () { s.bgm = s.bgm >= 1 ? 0 : Math.min(1, s.bgm + 0.2); Sfx_1.default.applyBgmVolume(); }
            },
            {
                name: "GAME SPEED",
                value: function () { return pct(s.speed); },
                next: function () { s.speed = s.speed >= 1.2 ? 0.8 : Math.round((s.speed + 0.2) * 10) / 10; }
            },
            {
                name: "COLOR SCHEME",
                value: function () { return LevelBuilder_1.SCHEMES[s.scheme].name; },
                next: function () { s.scheme = (s.scheme + 1) % LevelBuilder_1.SCHEMES.length; _this.applyBgTint(); }
            },
            {
                name: "BRIGHTNESS",
                value: function () { return pct(s.brightness); },
                next: function () { s.brightness = s.brightness <= 0.6 ? 1 : Math.round((s.brightness - 0.2) * 10) / 10; _this.applyBgTint(); }
            }
        ];
        var _loop_3 = function (i) {
            var row = rows[i];
            var y = 100 - i * 56;
            var rowNode = this_3.sprite(panel, "white", 0, y, 480, 44, cc.color(24, 34, 76));
            this_3.label(rowNode, row.name, -220, 0, 18, white, 0);
            var valNode = this_3.label(rowNode, row.value(), 220, 0, 18, cyan, 1);
            rowNode.on(cc.Node.EventType.TOUCH_END, function () {
                row.next();
                GameData_1.default.saveSettings();
                (valNode.getComponent(cc.Label)).string = row.value();
            });
        };
        var this_3 = this;
        for (var i = 0; i < rows.length; i++) {
            _loop_3(i);
        }
        var closeBtn = this.sprite(panel, "white", 0, -190, 160, 40, cc.color(70, 30, 50));
        this.label(closeBtn, "CLOSE", 0, 0, 18, white);
        closeBtn.on(cc.Node.EventType.TOUCH_END, function () {
            Sfx_1.default.play("click", 0.8);
            _this.toggleSettings();
        });
    };
    MenuCtrl.prototype.onKeyDown = function (e) {
        if (e.keyCode === cc.macro.KEY.space && !this.settingsPanel) {
            GameData_1.default.currentLevel = 1;
            cc.director.loadScene("Game");
        }
        if (e.keyCode === cc.macro.KEY.escape && this.settingsPanel) {
            this.toggleSettings();
        }
    };
    MenuCtrl = __decorate([
        ccclass
    ], MenuCtrl);
    return MenuCtrl;
}(cc.Component));
exports.default = MenuCtrl;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcTWVudUN0cmwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdUNBQWtDO0FBQ2xDLCtDQUF1RDtBQUN2RCw2QkFBd0I7QUFFaEIsSUFBQSxPQUFPLEdBQUssRUFBRSxDQUFDLFVBQVUsUUFBbEIsQ0FBbUI7QUFFbEMsaUZBQWlGO0FBQ2pGLCtEQUErRDtBQUMvRCwwREFBMEQ7QUFFMUQ7SUFBc0MsNEJBQVk7SUFBbEQ7UUFBQSxxRUErT0M7UUE3T1csWUFBTSxHQUFvQyxFQUFFLENBQUM7UUFDN0MsWUFBTSxHQUFZLElBQUksQ0FBQztRQUN2QixpQkFBVyxHQUFjLEVBQUUsQ0FBQztRQUM1QixlQUFTLEdBQVksSUFBSSxDQUFDO1FBQzFCLG1CQUFhLEdBQVksSUFBSSxDQUFDOztJQXlPMUMsQ0FBQztJQXZPRyx5QkFBTSxHQUFOO1FBQUEsaUJBYUM7UUFaRyxhQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDZCxhQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDZCxFQUFFLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLFdBQVcsRUFBRSxVQUFDLEdBQUcsRUFBRSxNQUF3QjtZQUMzRSxJQUFJLEdBQUcsRUFBRTtnQkFDTCxFQUFFLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQyxPQUFPO2FBQ1Y7WUFDRCxLQUFnQixVQUFNLEVBQU4saUJBQU0sRUFBTixvQkFBTSxFQUFOLElBQU07Z0JBQWpCLElBQU0sQ0FBQyxlQUFBO2dCQUFZLEtBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUFBO1lBQ2hELEtBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNuQixDQUFDLENBQUMsQ0FBQztRQUNILEVBQUUsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQy9FLENBQUM7SUFFRCw0QkFBUyxHQUFUO1FBQ0ksRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDaEYsQ0FBQztJQUVPLHlCQUFNLEdBQWQsVUFBZSxNQUFlLEVBQUUsS0FBYSxFQUFFLENBQVMsRUFBRSxDQUFTLEVBQUUsQ0FBUyxFQUFFLENBQVMsRUFBRSxLQUFnQjtRQUN2RyxJQUFNLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDN0IsSUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDckMsRUFBRSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BCLElBQUksS0FBSztZQUFFLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQzNCLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkIsT0FBTyxDQUFDLENBQUM7SUFDYixDQUFDO0lBRU8sd0JBQUssR0FBYixVQUFjLE1BQWUsRUFBRSxJQUFZLEVBQUUsQ0FBUyxFQUFFLENBQVMsRUFBRSxJQUFZLEVBQUUsS0FBZSxFQUFFLE9BQXFCO1FBQXJCLHdCQUFBLEVBQUEsYUFBcUI7UUFDbkgsSUFBTSxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ2hCLElBQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLEVBQUUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLEVBQUUsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ25CLEVBQUUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUN6QixNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25CLE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUVPLDhCQUFXLEdBQW5CO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO1lBQUUsT0FBTztRQUN6QixJQUFNLENBQUMsR0FBRyxrQkFBUSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUM7UUFDdkMsSUFBTSxDQUFDLEdBQUcsc0JBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hHLENBQUM7SUFFTywwQkFBTyxHQUFmO1FBQUEsaUJBOEVDO1FBN0VHLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyQyxJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdEMsSUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3RDLElBQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUVwQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLFFBQVE7UUFDUixJQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUscUJBQXFCLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDN0UsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7YUFDVixFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxDQUFDO2FBQ2xELEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLENBQUM7YUFDbEQsYUFBYSxFQUFFO2FBQ2YsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsb0JBQW9CLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFaEUsY0FBYztRQUNkLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNoRSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQzthQUNULEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLENBQUM7YUFDM0MsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsQ0FBQzthQUMzQyxhQUFhLEVBQUU7YUFDZixLQUFLLEVBQUUsQ0FBQztRQUNiLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ25FLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDbEIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7YUFDVixFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLENBQUM7YUFDNUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxDQUFDO2FBQzVDLGFBQWEsRUFBRTthQUNmLEtBQUssRUFBRSxDQUFDO1FBQ2IsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5RCxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUU3RCx1QkFBdUI7UUFDdkIsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7Z0NBQ2IsQ0FBQztZQUNOLElBQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDN0IsSUFBTSxHQUFHLEdBQUcsT0FBSyxNQUFNLENBQUMsT0FBSyxJQUFJLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNuRixPQUFLLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDckUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUU7Z0JBQ2hDLGFBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUN2QixrQkFBUSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7Z0JBQ3JCLEtBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzlCLENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7UUFUL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUU7b0JBQWxCLENBQUM7U0FVVDtRQUNELElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBRTFCLGdCQUFnQjtRQUNoQixJQUFNLFFBQVEsR0FBRyxrQkFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dDQUMvQixDQUFDO1lBQ04sSUFBTSxJQUFJLEdBQUcsQ0FBQyxJQUFJLFFBQVEsQ0FBQztZQUMzQixJQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUN0QixJQUFNLEdBQUcsR0FBRyxPQUFLLE1BQU0sQ0FBQyxPQUFLLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUMvRyxPQUFLLE1BQU0sQ0FBQyxPQUFLLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEUsT0FBSyxLQUFLLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsR0FBRyxZQUFZLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2pHLElBQUksSUFBSSxFQUFFO2dCQUNOLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFO29CQUNoQyxhQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFDdkIsa0JBQVEsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO29CQUMxQixFQUFFLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDbEMsQ0FBQyxDQUFDLENBQUM7YUFDTjs7O1FBWkwsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLGtCQUFRLENBQUMsU0FBUyxFQUFFLENBQUMsRUFBRTtvQkFBbkMsQ0FBQztTQWFUO1FBRUQsa0JBQWtCO1FBQ2xCLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDckYsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFO1lBQ2pDLGFBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZCLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMxQixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUNqQyxvRkFBb0YsRUFDcEYsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRU8scUNBQWtCLEdBQTFCO1FBQ0ksSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ25DLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNsQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLGtCQUFRLENBQUMsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1NBQ3ZFO1FBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNqRCxFQUFFLENBQUMsTUFBTSxHQUFHLGtCQUFRLENBQUMsT0FBTyxLQUFLLENBQUM7Z0JBQzlCLENBQUMsQ0FBQyw2RUFBNkU7Z0JBQy9FLENBQUMsQ0FBQyxvRkFBb0YsQ0FBQztTQUM5RjtJQUNMLENBQUM7SUFFRCx1Q0FBdUM7SUFFL0IsaUNBQWMsR0FBdEI7UUFDSSxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDcEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztZQUMxQixPQUFPO1NBQ1Y7UUFDRCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRU8scUNBQWtCLEdBQTFCO1FBQUEsaUJBZ0VDO1FBL0RHLElBQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN0QyxJQUFNLElBQUksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDckMsSUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRXRDLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BGLEtBQUssQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO1FBQ3BCLEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLGtDQUFrQztRQUNsQyxLQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQVcsSUFBTyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVuRixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsdUJBQXVCLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFaEYsSUFBTSxDQUFDLEdBQUcsa0JBQVEsQ0FBQyxRQUFRLENBQUM7UUFDNUIsSUFBTSxHQUFHLEdBQUcsVUFBQyxDQUFTLElBQUssT0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEVBQXpCLENBQXlCLENBQUM7UUFDckQsSUFBTSxJQUFJLEdBQThEO1lBQ3BFO2dCQUNJLElBQUksRUFBRSxZQUFZO2dCQUNsQixLQUFLLEVBQUUsY0FBTSxPQUFBLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQVYsQ0FBVTtnQkFDdkIsSUFBSSxFQUFFLGNBQVEsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBRyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2hHO1lBQ0Q7Z0JBQ0ksSUFBSSxFQUFFLGNBQWM7Z0JBQ3BCLEtBQUssRUFBRSxjQUFNLE9BQUEsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBVixDQUFVO2dCQUN2QixJQUFJLEVBQUUsY0FBUSxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxhQUFHLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQzNGO1lBQ0Q7Z0JBQ0ksSUFBSSxFQUFFLFlBQVk7Z0JBQ2xCLEtBQUssRUFBRSxjQUFNLE9BQUEsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBWixDQUFZO2dCQUN6QixJQUFJLEVBQUUsY0FBUSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDMUY7WUFDRDtnQkFDSSxJQUFJLEVBQUUsY0FBYztnQkFDcEIsS0FBSyxFQUFFLGNBQU0sT0FBQSxzQkFBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQXRCLENBQXNCO2dCQUNuQyxJQUFJLEVBQUUsY0FBUSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxzQkFBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDbEY7WUFDRDtnQkFDSSxJQUFJLEVBQUUsWUFBWTtnQkFDbEIsS0FBSyxFQUFFLGNBQU0sT0FBQSxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFqQixDQUFpQjtnQkFDOUIsSUFBSSxFQUFFLGNBQVEsQ0FBQyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsVUFBVSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQzNIO1NBQ0osQ0FBQztnQ0FFTyxDQUFDO1lBQ04sSUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BCLElBQU0sQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLElBQU0sT0FBTyxHQUFHLE9BQUssTUFBTSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ2pGLE9BQUssS0FBSyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3JELElBQU0sT0FBTyxHQUFHLE9BQUssS0FBSyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3RFLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFO2dCQUNwQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ1gsa0JBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDeEIsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDMUQsQ0FBQyxDQUFDLENBQUM7OztRQVZQLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRTtvQkFBM0IsQ0FBQztTQVdUO1FBRUQsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3JGLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMvQyxRQUFRLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRTtZQUNyQyxhQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztZQUN2QixLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sNEJBQVMsR0FBakIsVUFBa0IsQ0FBeUI7UUFDdkMsSUFBSSxDQUFDLENBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDekQsa0JBQVEsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLEVBQUUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2pDO1FBQ0QsSUFBSSxDQUFDLENBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3pELElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztTQUN6QjtJQUNMLENBQUM7SUE5T2dCLFFBQVE7UUFENUIsT0FBTztPQUNhLFFBQVEsQ0ErTzVCO0lBQUQsZUFBQztDQS9PRCxBQStPQyxDQS9PcUMsRUFBRSxDQUFDLFNBQVMsR0ErT2pEO2tCQS9Pb0IsUUFBUSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBHYW1lRGF0YSBmcm9tIFwiLi9HYW1lRGF0YVwiO1xuaW1wb3J0IExldmVsQnVpbGRlciwgeyBTQ0hFTUVTIH0gZnJvbSBcIi4vTGV2ZWxCdWlsZGVyXCI7XG5pbXBvcnQgU2Z4IGZyb20gXCIuL1NmeFwiO1xuXG5jb25zdCB7IGNjY2xhc3MgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbi8vIE1haW4gbWVudSDigJQgYnVpbHQgZW50aXJlbHkgaW4gY29kZSAodGhlIC5maXJlIHNjZW5lIG9ubHkgaGFzIENhbnZhcyArIENhbWVyYSkuXG4vLyBNb2RlIHNlbGVjdCAoMVAgLyAyUCksIGxldmVsIGJ1dHRvbnMsIGFuZCBhIHNldHRpbmdzIG92ZXJsYXlcbi8vIChzZngvYmdtIHZvbHVtZSwgZ2FtZSBzcGVlZCwgY29sb3Igc2NoZW1lLCBicmlnaHRuZXNzKS5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNZW51Q3RybCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG5cbiAgICBwcml2YXRlIGZyYW1lczogeyBbazogc3RyaW5nXTogY2MuU3ByaXRlRnJhbWUgfSA9IHt9O1xuICAgIHByaXZhdGUgYmdOb2RlOiBjYy5Ob2RlID0gbnVsbDtcbiAgICBwcml2YXRlIG1vZGVCdXR0b25zOiBjYy5Ob2RlW10gPSBbXTtcbiAgICBwcml2YXRlIGhpbnRMYWJlbDogY2MuTm9kZSA9IG51bGw7XG4gICAgcHJpdmF0ZSBzZXR0aW5nc1BhbmVsOiBjYy5Ob2RlID0gbnVsbDtcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgU2Z4LnByZWxvYWQoKTtcbiAgICAgICAgU2Z4LnBsYXlCZ20oKTtcbiAgICAgICAgY2MucmVzb3VyY2VzLmxvYWREaXIoXCJ0ZXh0dXJlc1wiLCBjYy5TcHJpdGVGcmFtZSwgKGVyciwgYXNzZXRzOiBjYy5TcHJpdGVGcmFtZVtdKSA9PiB7XG4gICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY2MuZXJyb3IoXCJ0ZXh0dXJlIGxvYWQgZmFpbGVkXCIsIGVycik7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChjb25zdCBhIG9mIGFzc2V0cykgdGhpcy5mcmFtZXNbYS5uYW1lXSA9IGE7XG4gICAgICAgICAgICB0aGlzLmJ1aWxkVWkoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNjLmRpcmVjdG9yLnByZWxvYWRTY2VuZShcIkdhbWVcIik7XG4gICAgICAgIGNjLnN5c3RlbUV2ZW50Lm9uKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfRE9XTiwgdGhpcy5vbktleURvd24sIHRoaXMpO1xuICAgIH1cblxuICAgIG9uRGVzdHJveSgpIHtcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub2ZmKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfRE9XTiwgdGhpcy5vbktleURvd24sIHRoaXMpO1xuICAgIH1cblxuICAgIHByaXZhdGUgc3ByaXRlKHBhcmVudDogY2MuTm9kZSwgZnJhbWU6IHN0cmluZywgeDogbnVtYmVyLCB5OiBudW1iZXIsIHc6IG51bWJlciwgaDogbnVtYmVyLCBjb2xvcj86IGNjLkNvbG9yKTogY2MuTm9kZSB7XG4gICAgICAgIGNvbnN0IG4gPSBuZXcgY2MuTm9kZShmcmFtZSk7XG4gICAgICAgIGNvbnN0IHNwID0gbi5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgc3Auc3ByaXRlRnJhbWUgPSB0aGlzLmZyYW1lc1tmcmFtZV07XG4gICAgICAgIHNwLnNpemVNb2RlID0gY2MuU3ByaXRlLlNpemVNb2RlLkNVU1RPTTtcbiAgICAgICAgbi5zZXRDb250ZW50U2l6ZSh3LCBoKTtcbiAgICAgICAgbi5zZXRQb3NpdGlvbih4LCB5KTtcbiAgICAgICAgaWYgKGNvbG9yKSBuLmNvbG9yID0gY29sb3I7XG4gICAgICAgIHBhcmVudC5hZGRDaGlsZChuKTtcbiAgICAgICAgcmV0dXJuIG47XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBsYWJlbChwYXJlbnQ6IGNjLk5vZGUsIHRleHQ6IHN0cmluZywgeDogbnVtYmVyLCB5OiBudW1iZXIsIHNpemU6IG51bWJlciwgY29sb3I6IGNjLkNvbG9yLCBhbmNob3JYOiBudW1iZXIgPSAwLjUpOiBjYy5Ob2RlIHtcbiAgICAgICAgY29uc3QgbiA9IG5ldyBjYy5Ob2RlKFwibGFiZWxcIik7XG4gICAgICAgIG4uc2V0UG9zaXRpb24oeCwgeSk7XG4gICAgICAgIG4uYW5jaG9yWCA9IGFuY2hvclg7XG4gICAgICAgIG4uY29sb3IgPSBjb2xvcjtcbiAgICAgICAgY29uc3QgbGIgPSBuLmFkZENvbXBvbmVudChjYy5MYWJlbCk7XG4gICAgICAgIGxiLnN0cmluZyA9IHRleHQ7XG4gICAgICAgIGxiLmZvbnRTaXplID0gc2l6ZTtcbiAgICAgICAgbGIubGluZUhlaWdodCA9IHNpemUgKyA2O1xuICAgICAgICBwYXJlbnQuYWRkQ2hpbGQobik7XG4gICAgICAgIHJldHVybiBuO1xuICAgIH1cblxuICAgIHByaXZhdGUgYXBwbHlCZ1RpbnQoKSB7XG4gICAgICAgIGlmICghdGhpcy5iZ05vZGUpIHJldHVybjtcbiAgICAgICAgY29uc3QgYiA9IEdhbWVEYXRhLnNldHRpbmdzLmJyaWdodG5lc3M7XG4gICAgICAgIGNvbnN0IHQgPSBMZXZlbEJ1aWxkZXIuc2NoZW1lKCkuYmdUaW50O1xuICAgICAgICB0aGlzLmJnTm9kZS5jb2xvciA9IGNjLmNvbG9yKE1hdGgucm91bmQodC5yICogYiksIE1hdGgucm91bmQodC5nICogYiksIE1hdGgucm91bmQodC5iICogYikpO1xuICAgIH1cblxuICAgIHByaXZhdGUgYnVpbGRVaSgpIHtcbiAgICAgICAgY29uc3QgY3lhbiA9IGNjLmNvbG9yKDEyNywgMjQ3LCAyNTUpO1xuICAgICAgICBjb25zdCBvcmFuZ2UgPSBjYy5jb2xvcigyNTUsIDE4MSwgNzQpO1xuICAgICAgICBjb25zdCB3aGl0ZSA9IGNjLmNvbG9yKDIzNSwgMjQwLCAyNTUpO1xuICAgICAgICBjb25zdCBkaW0gPSBjYy5jb2xvcigxMTAsIDEyMCwgMTUwKTtcblxuICAgICAgICB0aGlzLmJnTm9kZSA9IHRoaXMuc3ByaXRlKHRoaXMubm9kZSwgXCJiZ1wiLCAwLCAwLCA5NzAsIDY1MCk7XG4gICAgICAgIHRoaXMuYXBwbHlCZ1RpbnQoKTtcblxuICAgICAgICAvLyB0aXRsZVxuICAgICAgICBjb25zdCB0aXRsZSA9IHRoaXMubGFiZWwodGhpcy5ub2RlLCBcIkdSQVZJVFkgRkxJUCBSVU5ORVJcIiwgMCwgMjMwLCA1NiwgY3lhbik7XG4gICAgICAgIGNjLnR3ZWVuKHRpdGxlKVxuICAgICAgICAgICAgLnRvKDEuNCwgeyBvcGFjaXR5OiAxNzAgfSwgeyBlYXNpbmc6IFwic2luZUluT3V0XCIgfSlcbiAgICAgICAgICAgIC50bygxLjQsIHsgb3BhY2l0eTogMjU1IH0sIHsgZWFzaW5nOiBcInNpbmVJbk91dFwiIH0pXG4gICAgICAgICAgICAucmVwZWF0Rm9yZXZlcigpXG4gICAgICAgICAgICAuc3RhcnQoKTtcbiAgICAgICAgdGhpcy5sYWJlbCh0aGlzLm5vZGUsIFwi4oCUIEVTQ0FQRSBBU1RSQS05IOKAlFwiLCAwLCAxNzgsIDE4LCBvcmFuZ2UpO1xuXG4gICAgICAgIC8vIGRlY29yYXRpb25zXG4gICAgICAgIGNvbnN0IGRlY28gPSB0aGlzLnNwcml0ZSh0aGlzLm5vZGUsIFwicGxheWVyXCIsIC0zNDAsIDYwLCA0OCwgNDgpO1xuICAgICAgICBjYy50d2VlbihkZWNvKVxuICAgICAgICAgICAgLnRvKDEuMiwgeyB5OiA4NSB9LCB7IGVhc2luZzogXCJzaW5lSW5PdXRcIiB9KVxuICAgICAgICAgICAgLnRvKDEuMiwgeyB5OiA2MCB9LCB7IGVhc2luZzogXCJzaW5lSW5PdXRcIiB9KVxuICAgICAgICAgICAgLnJlcGVhdEZvcmV2ZXIoKVxuICAgICAgICAgICAgLnN0YXJ0KCk7XG4gICAgICAgIGNvbnN0IGRlY28yID0gdGhpcy5zcHJpdGUodGhpcy5ub2RlLCBcInBsYXllcjJcIiwgLTM0MCwgLTQwLCA0MCwgNDApO1xuICAgICAgICBkZWNvMi5zY2FsZVkgPSAtMTtcbiAgICAgICAgY2MudHdlZW4oZGVjbzIpXG4gICAgICAgICAgICAudG8oMS41LCB7IHk6IC02NSB9LCB7IGVhc2luZzogXCJzaW5lSW5PdXRcIiB9KVxuICAgICAgICAgICAgLnRvKDEuNSwgeyB5OiAtNDAgfSwgeyBlYXNpbmc6IFwic2luZUluT3V0XCIgfSlcbiAgICAgICAgICAgIC5yZXBlYXRGb3JldmVyKClcbiAgICAgICAgICAgIC5zdGFydCgpO1xuICAgICAgICBjb25zdCBjMSA9IHRoaXMuc3ByaXRlKHRoaXMubm9kZSwgXCJjcnlzdGFsXCIsIDM0MCwgMjAsIDMwLCAzMCk7XG4gICAgICAgIGNjLnR3ZWVuKGMxKS5ieSgyLjQsIHsgYW5nbGU6IDM2MCB9KS5yZXBlYXRGb3JldmVyKCkuc3RhcnQoKTtcblxuICAgICAgICAvLyBtb2RlIHNlbGVjdDogMVAgLyAyUFxuICAgICAgICB0aGlzLm1vZGVCdXR0b25zID0gW107XG4gICAgICAgIGZvciAobGV0IG0gPSAxOyBtIDw9IDI7IG0rKykge1xuICAgICAgICAgICAgY29uc3QgeCA9IG0gPT09IDEgPyAtNzUgOiA3NTtcbiAgICAgICAgICAgIGNvbnN0IGJ0biA9IHRoaXMuc3ByaXRlKHRoaXMubm9kZSwgXCJ3aGl0ZVwiLCB4LCAxMTgsIDEzMCwgNDQsIGNjLmNvbG9yKDI0LCAzNCwgNzYpKTtcbiAgICAgICAgICAgIHRoaXMubGFiZWwoYnRuLCBtID09PSAxID8gXCIxIFBMQVlFUlwiIDogXCIyIFBMQVlFUlNcIiwgMCwgMCwgMTgsIHdoaXRlKTtcbiAgICAgICAgICAgIGJ0bi5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsICgpID0+IHtcbiAgICAgICAgICAgICAgICBTZngucGxheShcImNsaWNrXCIsIDAuOCk7XG4gICAgICAgICAgICAgICAgR2FtZURhdGEucGxheWVycyA9IG07XG4gICAgICAgICAgICAgICAgdGhpcy5yZWZyZXNoTW9kZUJ1dHRvbnMoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5tb2RlQnV0dG9ucy5wdXNoKGJ0bik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5yZWZyZXNoTW9kZUJ1dHRvbnMoKTtcblxuICAgICAgICAvLyBsZXZlbCBidXR0b25zXG4gICAgICAgIGNvbnN0IHVubG9ja2VkID0gR2FtZURhdGEuZ2V0VW5sb2NrZWQoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPD0gR2FtZURhdGEuTUFYX0xFVkVMOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IG9wZW4gPSBpIDw9IHVubG9ja2VkO1xuICAgICAgICAgICAgY29uc3QgeSA9IDUwIC0gaSAqIDcyO1xuICAgICAgICAgICAgY29uc3QgYnRuID0gdGhpcy5zcHJpdGUodGhpcy5ub2RlLCBcIndoaXRlXCIsIDAsIHksIDI2MCwgNTYsIG9wZW4gPyBjYy5jb2xvcigyNCwgMzQsIDc2KSA6IGNjLmNvbG9yKDIyLCAyNCwgMzQpKTtcbiAgICAgICAgICAgIHRoaXMuc3ByaXRlKHRoaXMubm9kZSwgXCJ3aGl0ZVwiLCAwLCB5IC0gMjYsIDI2MCwgMywgb3BlbiA/IGN5YW4gOiBkaW0pO1xuICAgICAgICAgICAgdGhpcy5sYWJlbChidG4sIG9wZW4gPyBcIkxFVkVMIFwiICsgaSA6IFwiTEVWRUwgXCIgKyBpICsgXCIgIFtMT0NLRURdXCIsIDAsIDAsIDI0LCBvcGVuID8gd2hpdGUgOiBkaW0pO1xuICAgICAgICAgICAgaWYgKG9wZW4pIHtcbiAgICAgICAgICAgICAgICBidG4ub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIFNmeC5wbGF5KFwiY2xpY2tcIiwgMC44KTtcbiAgICAgICAgICAgICAgICAgICAgR2FtZURhdGEuY3VycmVudExldmVsID0gaTtcbiAgICAgICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiR2FtZVwiKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHNldHRpbmdzIGJ1dHRvblxuICAgICAgICBjb25zdCBzQnRuID0gdGhpcy5zcHJpdGUodGhpcy5ub2RlLCBcIndoaXRlXCIsIDAsIC0yMjYsIDIwMCwgNDQsIGNjLmNvbG9yKDQwLCAzMCwgNzApKTtcbiAgICAgICAgdGhpcy5sYWJlbChzQnRuLCBcIlNFVFRJTkdTXCIsIDAsIDAsIDIwLCBvcmFuZ2UpO1xuICAgICAgICBzQnRuLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgKCkgPT4ge1xuICAgICAgICAgICAgU2Z4LnBsYXkoXCJjbGlja1wiLCAwLjgpO1xuICAgICAgICAgICAgdGhpcy50b2dnbGVTZXR0aW5ncygpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLmhpbnRMYWJlbCA9IHRoaXMubGFiZWwodGhpcy5ub2RlLFxuICAgICAgICAgICAgXCJTUEFDRSAvIFcgLyBVUCA6IEZMSVAgICAgICBSIDogUkVTVEFSVCAgICAgIEVTQyA6IFBBVVNFICAgICAgW1NQQUNFID0gUVVJQ0sgU1RBUlRdXCIsXG4gICAgICAgICAgICAwLCAtMjg2LCAxNSwgZGltKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHJlZnJlc2hNb2RlQnV0dG9ucygpIHtcbiAgICAgICAgY29uc3Qgc2VsID0gY2MuY29sb3IoNTMsIDEwMCwgMTUwKTtcbiAgICAgICAgY29uc3Qgbm9ybSA9IGNjLmNvbG9yKDI0LCAzNCwgNzYpO1xuICAgICAgICBmb3IgKGxldCBtID0gMDsgbSA8IDI7IG0rKykge1xuICAgICAgICAgICAgdGhpcy5tb2RlQnV0dG9uc1ttXS5jb2xvciA9IEdhbWVEYXRhLnBsYXllcnMgPT09IG0gKyAxID8gc2VsIDogbm9ybTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5oaW50TGFiZWwpIHtcbiAgICAgICAgICAgIGNvbnN0IGxiID0gdGhpcy5oaW50TGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICAgICAgICAgIGxiLnN0cmluZyA9IEdhbWVEYXRhLnBsYXllcnMgPT09IDJcbiAgICAgICAgICAgICAgICA/IFwiUDEgOiBXID0gRkxJUCAgICAgIFAyIDogVVAgLyBTUEFDRSA9IEZMSVAgICAgICBSIDogUkVTVEFSVCAgICAgIEVTQyA6IFBBVVNFXCJcbiAgICAgICAgICAgICAgICA6IFwiU1BBQ0UgLyBXIC8gVVAgOiBGTElQICAgICAgUiA6IFJFU1RBUlQgICAgICBFU0MgOiBQQVVTRSAgICAgIFtTUEFDRSA9IFFVSUNLIFNUQVJUXVwiO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLSBzZXR0aW5ncyBwYW5lbCAtLS0tLS0tLS0tXG5cbiAgICBwcml2YXRlIHRvZ2dsZVNldHRpbmdzKCkge1xuICAgICAgICBpZiAodGhpcy5zZXR0aW5nc1BhbmVsKSB7XG4gICAgICAgICAgICB0aGlzLnNldHRpbmdzUGFuZWwuZGVzdHJveSgpO1xuICAgICAgICAgICAgdGhpcy5zZXR0aW5nc1BhbmVsID0gbnVsbDtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmJ1aWxkU2V0dGluZ3NQYW5lbCgpO1xuICAgIH1cblxuICAgIHByaXZhdGUgYnVpbGRTZXR0aW5nc1BhbmVsKCkge1xuICAgICAgICBjb25zdCB3aGl0ZSA9IGNjLmNvbG9yKDIzNSwgMjQwLCAyNTUpO1xuICAgICAgICBjb25zdCBjeWFuID0gY2MuY29sb3IoMTI3LCAyNDcsIDI1NSk7XG4gICAgICAgIGNvbnN0IG9yYW5nZSA9IGNjLmNvbG9yKDI1NSwgMTgxLCA3NCk7XG5cbiAgICAgICAgY29uc3QgcGFuZWwgPSB0aGlzLnNwcml0ZSh0aGlzLm5vZGUsIFwid2hpdGVcIiwgMCwgMCwgNTYwLCA0NjAsIGNjLmNvbG9yKDEwLCAxMiwgMjYpKTtcbiAgICAgICAgcGFuZWwub3BhY2l0eSA9IDI0NTtcbiAgICAgICAgcGFuZWwuekluZGV4ID0gNTA7XG4gICAgICAgIHRoaXMuc2V0dGluZ3NQYW5lbCA9IHBhbmVsO1xuICAgICAgICAvLyBzd2FsbG93IGNsaWNrcyBiZWhpbmQgdGhlIHBhbmVsXG4gICAgICAgIHBhbmVsLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCAoZTogY2MuRXZlbnQpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgfSk7XG5cbiAgICAgICAgdGhpcy5sYWJlbChwYW5lbCwgXCJTRVRUSU5HU1wiLCAwLCAxOTAsIDMwLCBvcmFuZ2UpO1xuICAgICAgICB0aGlzLmxhYmVsKHBhbmVsLCBcImNsaWNrIGEgcm93IHRvIGNoYW5nZVwiLCAwLCAxNTgsIDE0LCBjYy5jb2xvcigxMTAsIDEyMCwgMTUwKSk7XG5cbiAgICAgICAgY29uc3QgcyA9IEdhbWVEYXRhLnNldHRpbmdzO1xuICAgICAgICBjb25zdCBwY3QgPSAodjogbnVtYmVyKSA9PiBNYXRoLnJvdW5kKHYgKiAxMDApICsgXCIlXCI7XG4gICAgICAgIGNvbnN0IHJvd3M6IHsgbmFtZTogc3RyaW5nOyB2YWx1ZTogKCkgPT4gc3RyaW5nOyBuZXh0OiAoKSA9PiB2b2lkIH1bXSA9IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIlNGWCBWT0xVTUVcIixcbiAgICAgICAgICAgICAgICB2YWx1ZTogKCkgPT4gcGN0KHMuc2Z4KSxcbiAgICAgICAgICAgICAgICBuZXh0OiAoKSA9PiB7IHMuc2Z4ID0gcy5zZnggPj0gMSA/IDAgOiBNYXRoLm1pbigxLCBzLnNmeCArIDAuMjUpOyBTZngucGxheShcImNyeXN0YWxcIiwgMC44KTsgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIk1VU0lDIFZPTFVNRVwiLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAoKSA9PiBwY3Qocy5iZ20pLFxuICAgICAgICAgICAgICAgIG5leHQ6ICgpID0+IHsgcy5iZ20gPSBzLmJnbSA+PSAxID8gMCA6IE1hdGgubWluKDEsIHMuYmdtICsgMC4yKTsgU2Z4LmFwcGx5QmdtVm9sdW1lKCk7IH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJHQU1FIFNQRUVEXCIsXG4gICAgICAgICAgICAgICAgdmFsdWU6ICgpID0+IHBjdChzLnNwZWVkKSxcbiAgICAgICAgICAgICAgICBuZXh0OiAoKSA9PiB7IHMuc3BlZWQgPSBzLnNwZWVkID49IDEuMiA/IDAuOCA6IE1hdGgucm91bmQoKHMuc3BlZWQgKyAwLjIpICogMTApIC8gMTA7IH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJDT0xPUiBTQ0hFTUVcIixcbiAgICAgICAgICAgICAgICB2YWx1ZTogKCkgPT4gU0NIRU1FU1tzLnNjaGVtZV0ubmFtZSxcbiAgICAgICAgICAgICAgICBuZXh0OiAoKSA9PiB7IHMuc2NoZW1lID0gKHMuc2NoZW1lICsgMSkgJSBTQ0hFTUVTLmxlbmd0aDsgdGhpcy5hcHBseUJnVGludCgpOyB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5hbWU6IFwiQlJJR0hUTkVTU1wiLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAoKSA9PiBwY3Qocy5icmlnaHRuZXNzKSxcbiAgICAgICAgICAgICAgICBuZXh0OiAoKSA9PiB7IHMuYnJpZ2h0bmVzcyA9IHMuYnJpZ2h0bmVzcyA8PSAwLjYgPyAxIDogTWF0aC5yb3VuZCgocy5icmlnaHRuZXNzIC0gMC4yKSAqIDEwKSAvIDEwOyB0aGlzLmFwcGx5QmdUaW50KCk7IH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXTtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJvd3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHJvdyA9IHJvd3NbaV07XG4gICAgICAgICAgICBjb25zdCB5ID0gMTAwIC0gaSAqIDU2O1xuICAgICAgICAgICAgY29uc3Qgcm93Tm9kZSA9IHRoaXMuc3ByaXRlKHBhbmVsLCBcIndoaXRlXCIsIDAsIHksIDQ4MCwgNDQsIGNjLmNvbG9yKDI0LCAzNCwgNzYpKTtcbiAgICAgICAgICAgIHRoaXMubGFiZWwocm93Tm9kZSwgcm93Lm5hbWUsIC0yMjAsIDAsIDE4LCB3aGl0ZSwgMCk7XG4gICAgICAgICAgICBjb25zdCB2YWxOb2RlID0gdGhpcy5sYWJlbChyb3dOb2RlLCByb3cudmFsdWUoKSwgMjIwLCAwLCAxOCwgY3lhbiwgMSk7XG4gICAgICAgICAgICByb3dOb2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgKCkgPT4ge1xuICAgICAgICAgICAgICAgIHJvdy5uZXh0KCk7XG4gICAgICAgICAgICAgICAgR2FtZURhdGEuc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgICAgICAgKHZhbE5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKSkuc3RyaW5nID0gcm93LnZhbHVlKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNsb3NlQnRuID0gdGhpcy5zcHJpdGUocGFuZWwsIFwid2hpdGVcIiwgMCwgLTE5MCwgMTYwLCA0MCwgY2MuY29sb3IoNzAsIDMwLCA1MCkpO1xuICAgICAgICB0aGlzLmxhYmVsKGNsb3NlQnRuLCBcIkNMT1NFXCIsIDAsIDAsIDE4LCB3aGl0ZSk7XG4gICAgICAgIGNsb3NlQnRuLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgKCkgPT4ge1xuICAgICAgICAgICAgU2Z4LnBsYXkoXCJjbGlja1wiLCAwLjgpO1xuICAgICAgICAgICAgdGhpcy50b2dnbGVTZXR0aW5ncygpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIG9uS2V5RG93bihlOiBjYy5FdmVudC5FdmVudEtleWJvYXJkKSB7XG4gICAgICAgIGlmIChlLmtleUNvZGUgPT09IGNjLm1hY3JvLktFWS5zcGFjZSAmJiAhdGhpcy5zZXR0aW5nc1BhbmVsKSB7XG4gICAgICAgICAgICBHYW1lRGF0YS5jdXJyZW50TGV2ZWwgPSAxO1xuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiR2FtZVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZS5rZXlDb2RlID09PSBjYy5tYWNyby5LRVkuZXNjYXBlICYmIHRoaXMuc2V0dGluZ3NQYW5lbCkge1xuICAgICAgICAgICAgdGhpcy50b2dnbGVTZXR0aW5ncygpO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/GameData.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '89e1fWBY4VFmLl3rdNbk3PK', 'GameData');
// scripts/GameData.ts

"use strict";
// Global game state shared across scenes (plain module, not a component).
Object.defineProperty(exports, "__esModule", { value: true });
var GameData = /** @class */ (function () {
    function GameData() {
    }
    GameData.getUnlocked = function () {
        var raw = cc.sys.localStorage.getItem(GameData.KEY);
        var v = parseInt(raw || "1", 10);
        if (isNaN(v) || v < 1)
            return 1;
        return Math.min(v, GameData.MAX_LEVEL);
    };
    GameData.unlockNext = function (clearedLevel) {
        var next = Math.min(clearedLevel + 1, GameData.MAX_LEVEL);
        if (next > GameData.getUnlocked()) {
            cc.sys.localStorage.setItem(GameData.KEY, String(next));
        }
    };
    GameData.loadSettings = function () {
        var def = { sfx: 1, bgm: 0.6, speed: 1, scheme: 0, brightness: 1 };
        try {
            var raw = cc.sys.localStorage.getItem(GameData.SETTINGS_KEY);
            if (raw) {
                var s = JSON.parse(raw);
                for (var k in def) {
                    if (typeof s[k] === "number")
                        def[k] = s[k];
                }
            }
        }
        catch (e) { /* corrupted settings -> defaults */ }
        return def;
    };
    GameData.saveSettings = function () {
        cc.sys.localStorage.setItem(GameData.SETTINGS_KEY, JSON.stringify(GameData.settings));
    };
    GameData.MAX_LEVEL = 3;
    // Which level the Game scene should load.
    GameData.currentLevel = 1;
    // 1 = solo, 2 = local co-op (P1=W, P2=UP/SPACE).
    GameData.players = 1;
    GameData.settings = GameData.loadSettings();
    GameData.KEY = "gfr_unlocked";
    GameData.SETTINGS_KEY = "gfr_settings";
    return GameData;
}());
exports.default = GameData;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZURhdGEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDBFQUEwRTs7QUFVMUU7SUFBQTtJQTZDQSxDQUFDO0lBL0JVLG9CQUFXLEdBQWxCO1FBQ0ksSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN0RCxJQUFNLENBQUMsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNuQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFTSxtQkFBVSxHQUFqQixVQUFrQixZQUFvQjtRQUNsQyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksR0FBRyxDQUFDLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzVELElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxXQUFXLEVBQUUsRUFBRTtZQUMvQixFQUFFLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUMzRDtJQUNMLENBQUM7SUFFYyxxQkFBWSxHQUEzQjtRQUNJLElBQU0sR0FBRyxHQUFhLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFDL0UsSUFBSTtZQUNBLElBQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDL0QsSUFBSSxHQUFHLEVBQUU7Z0JBQ0wsSUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDMUIsS0FBSyxJQUFNLENBQUMsSUFBSSxHQUFHLEVBQUU7b0JBQ2pCLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUTt3QkFBRyxHQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUN4RDthQUNKO1NBQ0o7UUFBQyxPQUFPLENBQUMsRUFBRSxFQUFFLG9DQUFvQyxFQUFFO1FBQ3BELE9BQU8sR0FBRyxDQUFDO0lBQ2YsQ0FBQztJQUVNLHFCQUFZLEdBQW5CO1FBQ0ksRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUMxRixDQUFDO0lBM0NlLGtCQUFTLEdBQUcsQ0FBQyxDQUFDO0lBRTlCLDBDQUEwQztJQUNuQyxxQkFBWSxHQUFHLENBQUMsQ0FBQztJQUV4QixpREFBaUQ7SUFDMUMsZ0JBQU8sR0FBRyxDQUFDLENBQUM7SUFFWixpQkFBUSxHQUFhLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUU1QixZQUFHLEdBQUcsY0FBYyxDQUFDO0lBQ3JCLHFCQUFZLEdBQUcsY0FBYyxDQUFDO0lBaUMxRCxlQUFDO0NBN0NELEFBNkNDLElBQUE7a0JBN0NvQixRQUFRIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gR2xvYmFsIGdhbWUgc3RhdGUgc2hhcmVkIGFjcm9zcyBzY2VuZXMgKHBsYWluIG1vZHVsZSwgbm90IGEgY29tcG9uZW50KS5cblxuZXhwb3J0IGludGVyZmFjZSBTZXR0aW5ncyB7XG4gICAgc2Z4OiBudW1iZXI7ICAgICAgICAvLyAwLi4xXG4gICAgYmdtOiBudW1iZXI7ICAgICAgICAvLyAwLi4xXG4gICAgc3BlZWQ6IG51bWJlcjsgICAgICAvLyBnYW1lIHNwZWVkIG11bHRpcGxpZXIgMC44IC8gMS4wIC8gMS4yXG4gICAgc2NoZW1lOiBudW1iZXI7ICAgICAvLyBjb2xvciBzY2hlbWUgaW5kZXgsIHNlZSBMZXZlbEJ1aWxkZXIuU0NIRU1FU1xuICAgIGJyaWdodG5lc3M6IG51bWJlcjsgLy8gMC42IC8gMC44IC8gMS4wXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdhbWVEYXRhIHtcbiAgICBzdGF0aWMgcmVhZG9ubHkgTUFYX0xFVkVMID0gMztcblxuICAgIC8vIFdoaWNoIGxldmVsIHRoZSBHYW1lIHNjZW5lIHNob3VsZCBsb2FkLlxuICAgIHN0YXRpYyBjdXJyZW50TGV2ZWwgPSAxO1xuXG4gICAgLy8gMSA9IHNvbG8sIDIgPSBsb2NhbCBjby1vcCAoUDE9VywgUDI9VVAvU1BBQ0UpLlxuICAgIHN0YXRpYyBwbGF5ZXJzID0gMTtcblxuICAgIHN0YXRpYyBzZXR0aW5nczogU2V0dGluZ3MgPSBHYW1lRGF0YS5sb2FkU2V0dGluZ3MoKTtcblxuICAgIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IEtFWSA9IFwiZ2ZyX3VubG9ja2VkXCI7XG4gICAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgU0VUVElOR1NfS0VZID0gXCJnZnJfc2V0dGluZ3NcIjtcblxuICAgIHN0YXRpYyBnZXRVbmxvY2tlZCgpOiBudW1iZXIge1xuICAgICAgICBjb25zdCByYXcgPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oR2FtZURhdGEuS0VZKTtcbiAgICAgICAgY29uc3QgdiA9IHBhcnNlSW50KHJhdyB8fCBcIjFcIiwgMTApO1xuICAgICAgICBpZiAoaXNOYU4odikgfHwgdiA8IDEpIHJldHVybiAxO1xuICAgICAgICByZXR1cm4gTWF0aC5taW4odiwgR2FtZURhdGEuTUFYX0xFVkVMKTtcbiAgICB9XG5cbiAgICBzdGF0aWMgdW5sb2NrTmV4dChjbGVhcmVkTGV2ZWw6IG51bWJlcikge1xuICAgICAgICBjb25zdCBuZXh0ID0gTWF0aC5taW4oY2xlYXJlZExldmVsICsgMSwgR2FtZURhdGEuTUFYX0xFVkVMKTtcbiAgICAgICAgaWYgKG5leHQgPiBHYW1lRGF0YS5nZXRVbmxvY2tlZCgpKSB7XG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oR2FtZURhdGEuS0VZLCBTdHJpbmcobmV4dCkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgbG9hZFNldHRpbmdzKCk6IFNldHRpbmdzIHtcbiAgICAgICAgY29uc3QgZGVmOiBTZXR0aW5ncyA9IHsgc2Z4OiAxLCBiZ206IDAuNiwgc3BlZWQ6IDEsIHNjaGVtZTogMCwgYnJpZ2h0bmVzczogMSB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmF3ID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKEdhbWVEYXRhLlNFVFRJTkdTX0tFWSk7XG4gICAgICAgICAgICBpZiAocmF3KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcyA9IEpTT04ucGFyc2UocmF3KTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGsgaW4gZGVmKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygc1trXSA9PT0gXCJudW1iZXJcIikgKGRlZiBhcyBhbnkpW2tdID0gc1trXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgLyogY29ycnVwdGVkIHNldHRpbmdzIC0+IGRlZmF1bHRzICovIH1cbiAgICAgICAgcmV0dXJuIGRlZjtcbiAgICB9XG5cbiAgICBzdGF0aWMgc2F2ZVNldHRpbmdzKCkge1xuICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oR2FtZURhdGEuU0VUVElOR1NfS0VZLCBKU09OLnN0cmluZ2lmeShHYW1lRGF0YS5zZXR0aW5ncykpO1xuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/GameMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2f636z6hMFHmItBVlgUXfxC', 'GameMgr');
// scripts/GameMgr.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GameData_1 = require("./GameData");
var LevelBuilder_1 = require("./LevelBuilder");
var Player_1 = require("./Player");
var CameraFollow_1 = require("./CameraFollow");
var Sfx_1 = require("./Sfx");
var ccclass = cc._decorator.ccclass;
// Owns the Game scene: loads assets + level JSON, builds the world through
// LevelBuilder, spawns 1-2 Players, and runs the ready/run/dead/win state machine.
// Everything (world, HUD) is created in code — the .fire scene stays minimal.
//
// Co-op rules (GameData.players === 2): P1 = W key, P2 = UP/SPACE.
// If one player dies while the partner survives, they revive next to the
// partner after 3s. If everyone is dead, the level restarts.
var GameMgr = /** @class */ (function (_super) {
    __extends(GameMgr, _super);
    function GameMgr() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // global slow-motion factor (slow power-up); Player multiplies dt by this
        _this.timeScale = 1;
        _this.cameraNode = null;
        _this.world = null;
        _this.hud = null;
        _this.players = [];
        _this.level = null;
        _this.frames = {};
        _this.state = "loading";
        _this.time = 0;
        _this.deaths = 0;
        _this.crystalsTaken = 0;
        _this.slowT = 0;
        _this.enemyT = 0;
        _this.rotCurrent = 0;
        _this.rotTarget = 0;
        _this.nameLabel = null;
        _this.crystalLabel = null;
        _this.deathLabel = null;
        _this.timeLabel = null;
        _this.msgLabel = null;
        _this.subLabel = null;
        _this.slowOverlay = null;
        return _this;
    }
    GameMgr.prototype.isRunning = function () {
        return this.state === "run";
    };
    GameMgr.prototype.onLoad = function () {
        var _this = this;
        Sfx_1.default.preload();
        Sfx_1.default.playBgm();
        this.cameraNode = this.node.getChildByName("Main Camera");
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouch, this);
        cc.resources.loadDir("textures", cc.SpriteFrame, function (err, assets) {
            if (err) {
                cc.error("texture load failed", err);
                return;
            }
            for (var _i = 0, assets_1 = assets; _i < assets_1.length; _i++) {
                var a = assets_1[_i];
                _this.frames[a.name] = a;
            }
            _this.onTexturesReady();
        });
    };
    GameMgr.prototype.onDestroy = function () {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    };
    GameMgr.prototype.onTexturesReady = function () {
        var _this = this;
        // background rides along as a child of the camera (auto screen-aligned,
        // even when the camera rotates in rotation zones)
        var bg = new cc.Node("BG");
        var bgSp = bg.addComponent(cc.Sprite);
        bgSp.spriteFrame = this.frames["bg"];
        bgSp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        bg.setContentSize(1400, 1400); // oversized: stays covering while rotated
        var b = GameData_1.default.settings.brightness;
        var tint = LevelBuilder_1.default.scheme().bgTint;
        bg.color = cc.color(Math.round(tint.r * b), Math.round(tint.g * b), Math.round(tint.b * b));
        this.cameraNode.addChild(bg, -10);
        this.world = new cc.Node("World");
        this.node.addChild(this.world);
        this.buildHud();
        cc.resources.load("levels/level" + GameData_1.default.currentLevel, cc.JsonAsset, function (err, asset) {
            if (err) {
                _this.setMsg("LEVEL " + GameData_1.default.currentLevel + " LOAD ERROR", "");
                cc.error(err);
                return;
            }
            _this.startLevel(asset.json);
        });
    };
    GameMgr.prototype.startLevel = function (data) {
        this.level = LevelBuilder_1.default.build(this.world, data, this.frames);
        var count = GameData_1.default.players === 2 ? 2 : 1;
        this.players = [];
        for (var i = 0; i < count; i++) {
            var pNode = new cc.Node("Player" + (i + 1));
            var sp = pNode.addComponent(cc.Sprite);
            sp.spriteFrame = this.frames[i === 0 ? "player" : "player2"];
            sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            pNode.setContentSize(36, 36);
            this.world.addChild(pNode, 5);
            var p = pNode.addComponent(Player_1.default);
            p.init(this, this.level, i, this.frames);
            this.players.push(p);
        }
        var follow = this.cameraNode.addComponent(CameraFollow_1.default);
        follow.init(this.players[0].node, 0, this.level.length - 480);
        follow.snap();
        this.time = 0;
        this.deaths = 0;
        this.crystalsTaken = 0;
        this.timeScale = 1;
        this.enemyT = 0;
        this.applyRotationForX(this.level.start.x, true);
        this.nameLabel.string = "LEVEL " + GameData_1.default.currentLevel + " — " + this.level.name
            + (count === 2 ? "   [2P]" : "");
        this.refreshHud();
        this.state = "ready";
        this.setMsg("PRESS SPACE TO RUN", count === 2
            ? "P1: W = FLIP      P2: UP / SPACE = FLIP      R = RESTART"
            : "SPACE / W / UP = FLIP GRAVITY    R = RESTART    ESC = PAUSE");
    };
    // ---------- HUD ----------
    GameMgr.prototype.makeLabel = function (parent, x, y, size, color, anchorX) {
        if (anchorX === void 0) { anchorX = 0.5; }
        var n = new cc.Node("label");
        n.setPosition(x, y);
        n.anchorX = anchorX;
        n.color = color;
        var lb = n.addComponent(cc.Label);
        lb.fontSize = size;
        lb.lineHeight = size + 6;
        lb.string = "";
        parent.addChild(n);
        return lb;
    };
    GameMgr.prototype.buildHud = function () {
        // HUD is a sibling of the world; update() keeps it glued to the camera
        // (position AND angle, so it stays upright in rotation zones).
        this.hud = new cc.Node("HUD");
        this.node.addChild(this.hud, 100);
        var cyan = cc.color(127, 247, 255);
        var pink = cc.color(255, 122, 200);
        var orange = cc.color(255, 181, 74);
        var white = cc.color(235, 240, 255);
        this.slowOverlay = new cc.Node("slowFx");
        var so = this.slowOverlay.addComponent(cc.Sprite);
        so.spriteFrame = this.frames["white"];
        so.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.slowOverlay.setContentSize(1400, 1400);
        this.slowOverlay.color = cc.color(120, 150, 255);
        this.slowOverlay.opacity = 0;
        this.hud.addChild(this.slowOverlay, -1);
        this.nameLabel = this.makeLabel(this.hud, -450, 296, 20, cyan, 0);
        this.crystalLabel = this.makeLabel(this.hud, -450, 268, 20, white, 0);
        this.deathLabel = this.makeLabel(this.hud, -450, 240, 20, pink, 0);
        this.timeLabel = this.makeLabel(this.hud, 450, 296, 20, orange, 1);
        this.msgLabel = this.makeLabel(this.hud, 0, 40, 44, white);
        this.subLabel = this.makeLabel(this.hud, 0, -10, 18, cyan);
    };
    GameMgr.prototype.refreshHud = function () {
        this.crystalLabel.string = "CRYSTALS  " + this.crystalsTaken + " / " + this.level.totalCrystals;
        this.deathLabel.string = "DEATHS  " + this.deaths;
        this.timeLabel.string = this.formatTime(this.time);
    };
    GameMgr.prototype.formatTime = function (t) {
        var m = Math.floor(t / 60);
        var s = t - m * 60;
        return (m < 10 ? "0" + m : "" + m) + ":" + (s < 10 ? "0" + s.toFixed(1) : s.toFixed(1));
    };
    GameMgr.prototype.setMsg = function (main, sub) {
        this.msgLabel.string = main;
        this.subLabel.string = sub;
    };
    // ---------- input ----------
    GameMgr.prototype.onKeyDown = function (e) {
        switch (e.keyCode) {
            case cc.macro.KEY.space:
            case cc.macro.KEY.up:
                this.onAction(1);
                break;
            case cc.macro.KEY.w:
                this.onAction(0);
                break;
            case cc.macro.KEY.r:
                this.fullRestart();
                break;
            case cc.macro.KEY.escape:
                this.togglePause();
                break;
        }
    };
    GameMgr.prototype.onTouch = function (e) {
        // 2P touch: left half of the screen = P1, right half = P2
        var half = cc.winSize.width / 2;
        this.onAction(e.getLocationX() < half ? 0 : 1);
    };
    // who: 0 = P1 input, 1 = P2 input (in solo mode every input drives P1)
    GameMgr.prototype.onAction = function (who) {
        switch (this.state) {
            case "ready":
                this.state = "run";
                this.setMsg("", "");
                break;
            case "run": {
                var idx = GameData_1.default.players === 2 ? who : 0;
                var p = this.players[idx];
                if (p && p.alive)
                    p.flip();
                break;
            }
            case "paused":
                this.togglePause();
                break;
            case "win":
                this.proceedAfterWin();
                break;
        }
    };
    GameMgr.prototype.togglePause = function () {
        if (this.state === "run") {
            this.state = "paused";
            this.setMsg("PAUSED", "SPACE = RESUME    R = RESTART");
        }
        else if (this.state === "paused") {
            this.state = "run";
            this.setMsg("", "");
        }
        else if (this.state === "win") {
            cc.director.loadScene("Menu");
        }
    };
    GameMgr.prototype.fullRestart = function () {
        if (this.state === "loading" || this.players.length === 0)
            return;
        this.unscheduleAllCallbacks();
        this.respawnAll();
        this.state = "ready";
        this.setMsg("PRESS SPACE TO RUN", "");
    };
    GameMgr.prototype.respawnAll = function () {
        for (var _i = 0, _a = this.players; _i < _a.length; _i++) {
            var p = _a[_i];
            p.reset();
        }
        for (var _b = 0, _c = this.level.crystals; _b < _c.length; _b++) {
            var c = _c[_b];
            c.taken = false;
            c.node.active = true;
            c.node.setPosition(c.x, c.y); // magnet may have dragged it around
        }
        for (var _d = 0, _e = this.level.powerups; _d < _e.length; _d++) {
            var pu = _e[_d];
            pu.taken = false;
            pu.node.active = true;
        }
        this.crystalsTaken = 0;
        this.time = 0;
        this.timeScale = 1;
        this.slowT = 0;
        this.slowOverlay.opacity = 0;
        this.enemyT = 0;
        var follow = this.cameraNode.getComponent(CameraFollow_1.default);
        if (follow) {
            follow.setTarget(this.players[0].node);
            follow.snap();
        }
        this.applyRotationForX(this.level.start.x, true);
        this.refreshHud();
    };
    // ---------- rotation zones ----------
    GameMgr.prototype.applyRotationForX = function (x, instant) {
        var target = 0;
        for (var _i = 0, _a = this.level.rotations; _i < _a.length; _i++) {
            var r = _a[_i];
            if (x >= r.x)
                target = r.angle;
        }
        if (target !== this.rotTarget) {
            this.rotTarget = target;
            if (!instant)
                Sfx_1.default.play("teleport", 0.4);
        }
        if (instant) {
            this.rotCurrent = target;
            this.applyWorldRotation();
        }
    };
    // Rotate the WORLD node (not the camera — cc.Camera in 2.4 ignores its
    // node's rotation) around the camera's focus point. Obstacles, players and
    // apparent gravity all rotate on screen, while physics stay 1D because
    // Player works in the world node's local coordinates.
    GameMgr.prototype.applyWorldRotation = function () {
        var th = this.rotCurrent * Math.PI / 180;
        var px = this.cameraNode.x; // camera y is always 0
        this.world.angle = this.rotCurrent;
        this.world.x = px - px * Math.cos(th);
        this.world.y = -px * Math.sin(th);
    };
    // ---------- power-up support ----------
    GameMgr.prototype.applySlow = function (seconds, scale) {
        this.slowT = seconds;
        this.timeScale = scale;
        this.slowOverlay.opacity = 50;
    };
    // ---------- callbacks from Player ----------
    GameMgr.prototype.onCrystal = function () {
        this.crystalsTaken++;
        Sfx_1.default.play("crystal", 0.7);
        this.refreshHud();
    };
    GameMgr.prototype.onDeath = function (dead) {
        var _this = this;
        if (this.state !== "run")
            return;
        this.deaths++;
        Sfx_1.default.play("death", 0.8);
        this.refreshHud();
        var survivor = this.anyAlive();
        if (survivor) {
            // partner carries on; camera follows them, dead player revives in 3s
            var follow = this.cameraNode.getComponent(CameraFollow_1.default);
            if (follow)
                follow.setTarget(survivor.node);
            this.scheduleOnce(function () {
                var s = _this.anyAlive();
                if (_this.state === "run" && s) {
                    dead.respawnAt(s.node.x - 50, s.node.y, s.getGravityDir());
                }
            }, 3);
            return;
        }
        // everyone is down — quick auto-retry keeps the rhythm going
        this.state = "dead";
        this.unscheduleAllCallbacks();
        this.scheduleOnce(function () {
            _this.respawnAll();
            _this.state = "run";
        }, 0.8);
    };
    GameMgr.prototype.anyAlive = function () {
        for (var _i = 0, _a = this.players; _i < _a.length; _i++) {
            var p = _a[_i];
            if (p.alive)
                return p;
        }
        return null;
    };
    GameMgr.prototype.onWin = function () {
        if (this.state !== "run")
            return;
        this.state = "win";
        this.unscheduleAllCallbacks();
        Sfx_1.default.play("win", 0.9);
        GameData_1.default.unlockNext(GameData_1.default.currentLevel);
        var last = GameData_1.default.currentLevel >= GameData_1.default.MAX_LEVEL;
        this.setMsg(last ? "YOU ESCAPED ASTRA-9!" : "LEVEL CLEAR!", "CRYSTALS " + this.crystalsTaken + "/" + this.level.totalCrystals
            + "    TIME " + this.formatTime(this.time)
            + "    DEATHS " + this.deaths
            + (last ? "    SPACE = MENU" : "    SPACE = NEXT    ESC = MENU"));
    };
    GameMgr.prototype.proceedAfterWin = function () {
        if (GameData_1.default.currentLevel < GameData_1.default.MAX_LEVEL) {
            GameData_1.default.currentLevel++;
            cc.director.loadScene("Game");
        }
        else {
            cc.director.loadScene("Menu");
        }
    };
    // ---------- per-frame ----------
    GameMgr.prototype.update = function (dt) {
        // keep HUD glued to the camera viewport
        if (this.hud && this.cameraNode) {
            this.hud.x = this.cameraNode.x;
            this.hud.y = this.cameraNode.y;
        }
        // animate field rotation at a constant rate, and re-anchor every frame
        // because the pivot (camera focus) keeps moving
        if (this.rotCurrent !== this.rotTarget) {
            var step = 110 * dt;
            var diff = this.rotTarget - this.rotCurrent;
            if (Math.abs(diff) <= step)
                this.rotCurrent = this.rotTarget;
            else
                this.rotCurrent += diff > 0 ? step : -step;
        }
        if (this.world)
            this.applyWorldRotation();
        if (this.state !== "run")
            return;
        this.time += dt;
        this.timeLabel.string = this.formatTime(this.time);
        // slow-motion timer
        if (this.slowT > 0) {
            this.slowT -= dt;
            if (this.slowT <= 0) {
                this.timeScale = 1;
                this.slowOverlay.opacity = 0;
            }
        }
        // patrol drones oscillate on a fixed deterministic clock
        this.enemyT += dt * this.timeScale;
        for (var _i = 0, _a = this.level.enemies; _i < _a.length; _i++) {
            var e = _a[_i];
            var off = Math.sin((this.enemyT + e.phase) * Math.PI * 2 / e.period) * e.range;
            if (e.axis === "x")
                e.node.x = e.x0 + off;
            else
                e.node.y = e.y0 + off;
        }
        // rotation zones track the leading living player
        var lead = this.anyAlive();
        if (lead)
            this.applyRotationForX(lead.node.x, false);
    };
    GameMgr = __decorate([
        ccclass
    ], GameMgr);
    return GameMgr;
}(cc.Component));
exports.default = GameMgr;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZU1nci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSx1Q0FBa0M7QUFDbEMsK0NBQXlEO0FBQ3pELG1DQUE4QjtBQUM5QiwrQ0FBMEM7QUFDMUMsNkJBQXdCO0FBRWhCLElBQUEsT0FBTyxHQUFLLEVBQUUsQ0FBQyxVQUFVLFFBQWxCLENBQW1CO0FBSWxDLDJFQUEyRTtBQUMzRSxtRkFBbUY7QUFDbkYsOEVBQThFO0FBQzlFLEVBQUU7QUFDRixtRUFBbUU7QUFDbkUseUVBQXlFO0FBQ3pFLDZEQUE2RDtBQUU3RDtJQUFxQywyQkFBWTtJQUFqRDtRQUFBLHFFQXVhQztRQXJhRywwRUFBMEU7UUFDMUUsZUFBUyxHQUFHLENBQUMsQ0FBQztRQUVOLGdCQUFVLEdBQVksSUFBSSxDQUFDO1FBQzNCLFdBQUssR0FBWSxJQUFJLENBQUM7UUFDdEIsU0FBRyxHQUFZLElBQUksQ0FBQztRQUNwQixhQUFPLEdBQWEsRUFBRSxDQUFDO1FBQ3ZCLFdBQUssR0FBYyxJQUFJLENBQUM7UUFDeEIsWUFBTSxHQUFvQyxFQUFFLENBQUM7UUFFN0MsV0FBSyxHQUFjLFNBQVMsQ0FBQztRQUM3QixVQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ1QsWUFBTSxHQUFHLENBQUMsQ0FBQztRQUNYLG1CQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQ2xCLFdBQUssR0FBRyxDQUFDLENBQUM7UUFDVixZQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ1gsZ0JBQVUsR0FBRyxDQUFDLENBQUM7UUFDZixlQUFTLEdBQUcsQ0FBQyxDQUFDO1FBRWQsZUFBUyxHQUFhLElBQUksQ0FBQztRQUMzQixrQkFBWSxHQUFhLElBQUksQ0FBQztRQUM5QixnQkFBVSxHQUFhLElBQUksQ0FBQztRQUM1QixlQUFTLEdBQWEsSUFBSSxDQUFDO1FBQzNCLGNBQVEsR0FBYSxJQUFJLENBQUM7UUFDMUIsY0FBUSxHQUFhLElBQUksQ0FBQztRQUMxQixpQkFBVyxHQUFZLElBQUksQ0FBQzs7SUE0WXhDLENBQUM7SUExWUcsMkJBQVMsR0FBVDtRQUNJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLENBQUM7SUFDaEMsQ0FBQztJQUVELHdCQUFNLEdBQU47UUFBQSxpQkFnQkM7UUFmRyxhQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDZCxhQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDZCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRTFELEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRWhFLEVBQUUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsV0FBVyxFQUFFLFVBQUMsR0FBRyxFQUFFLE1BQXdCO1lBQzNFLElBQUksR0FBRyxFQUFFO2dCQUNMLEVBQUUsQ0FBQyxLQUFLLENBQUMscUJBQXFCLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ3JDLE9BQU87YUFDVjtZQUNELEtBQWdCLFVBQU0sRUFBTixpQkFBTSxFQUFOLG9CQUFNLEVBQU4sSUFBTTtnQkFBakIsSUFBTSxDQUFDLGVBQUE7Z0JBQVksS0FBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQUE7WUFDaEQsS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDJCQUFTLEdBQVQ7UUFDSSxFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNoRixDQUFDO0lBRU8saUNBQWUsR0FBdkI7UUFBQSxpQkEwQkM7UUF6Qkcsd0VBQXdFO1FBQ3hFLGtEQUFrRDtRQUNsRCxJQUFNLEVBQUUsR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0IsSUFBTSxJQUFJLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1FBQzFDLEVBQUUsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsMENBQTBDO1FBQ3pFLElBQU0sQ0FBQyxHQUFHLGtCQUFRLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQztRQUN2QyxJQUFNLElBQUksR0FBRyxzQkFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUMxQyxFQUFFLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1RixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFL0IsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRWhCLEVBQUUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxrQkFBUSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsU0FBUyxFQUFFLFVBQUMsR0FBRyxFQUFFLEtBQW1CO1lBQzdGLElBQUksR0FBRyxFQUFFO2dCQUNMLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLGtCQUFRLENBQUMsWUFBWSxHQUFHLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDbEUsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDZCxPQUFPO2FBQ1Y7WUFDRCxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNoQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyw0QkFBVSxHQUFsQixVQUFtQixJQUFTO1FBQ3hCLElBQUksQ0FBQyxLQUFLLEdBQUcsc0JBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRS9ELElBQU0sS0FBSyxHQUFHLGtCQUFRLENBQUMsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDbEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM1QixJQUFNLEtBQUssR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDOUMsSUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDekMsRUFBRSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDN0QsRUFBRSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7WUFDeEMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzlCLElBQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsZ0JBQU0sQ0FBQyxDQUFDO1lBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4QjtRQUVELElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLHNCQUFZLENBQUMsQ0FBQztRQUMxRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztRQUM5RCxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7UUFFZCxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUNkLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsUUFBUSxHQUFHLGtCQUFRLENBQUMsWUFBWSxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUk7Y0FDNUUsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUM1QixLQUFLLEtBQUssQ0FBQztZQUNQLENBQUMsQ0FBQywwREFBMEQ7WUFDNUQsQ0FBQyxDQUFDLDZEQUE2RCxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVELDRCQUE0QjtJQUVwQiwyQkFBUyxHQUFqQixVQUFrQixNQUFlLEVBQUUsQ0FBUyxFQUFFLENBQVMsRUFBRSxJQUFZLEVBQUUsS0FBZSxFQUFFLE9BQXFCO1FBQXJCLHdCQUFBLEVBQUEsYUFBcUI7UUFDekcsSUFBTSxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ2hCLElBQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ25CLEVBQUUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUN6QixFQUFFLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkIsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRU8sMEJBQVEsR0FBaEI7UUFDSSx1RUFBdUU7UUFDdkUsK0RBQStEO1FBQy9ELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFbEMsSUFBTSxJQUFJLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3JDLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyQyxJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdEMsSUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRXRDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwRCxFQUFFLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsRUFBRSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7UUFDeEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXhDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ25FLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNuRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFFTyw0QkFBVSxHQUFsQjtRQUNJLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQztRQUNoRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNsRCxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRU8sNEJBQVUsR0FBbEIsVUFBbUIsQ0FBUztRQUN4QixJQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUM3QixJQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNyQixPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDNUYsQ0FBQztJQUVPLHdCQUFNLEdBQWQsVUFBZSxJQUFZLEVBQUUsR0FBVztRQUNwQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO0lBQy9CLENBQUM7SUFFRCw4QkFBOEI7SUFFdEIsMkJBQVMsR0FBakIsVUFBa0IsQ0FBeUI7UUFDdkMsUUFBUSxDQUFDLENBQUMsT0FBTyxFQUFFO1lBQ2YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7WUFDeEIsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNoQixJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLE1BQU07WUFDVixLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixNQUFNO1lBQ1YsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNO2dCQUNwQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25CLE1BQU07U0FDYjtJQUNMLENBQUM7SUFFTyx5QkFBTyxHQUFmLFVBQWdCLENBQXNCO1FBQ2xDLDBEQUEwRDtRQUMxRCxJQUFNLElBQUksR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCx1RUFBdUU7SUFDL0QsMEJBQVEsR0FBaEIsVUFBaUIsR0FBVztRQUN4QixRQUFRLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDaEIsS0FBSyxPQUFPO2dCQUNSLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUNuQixJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDcEIsTUFBTTtZQUNWLEtBQUssS0FBSyxDQUFDLENBQUM7Z0JBQ1IsSUFBTSxHQUFHLEdBQUcsa0JBQVEsQ0FBQyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0MsSUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUs7b0JBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUMzQixNQUFNO2FBQ1Q7WUFDRCxLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixNQUFNO1lBQ1YsS0FBSyxLQUFLO2dCQUNOLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFDdkIsTUFBTTtTQUNiO0lBQ0wsQ0FBQztJQUVPLDZCQUFXLEdBQW5CO1FBQ0ksSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLEtBQUssRUFBRTtZQUN0QixJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztZQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDO1NBQzFEO2FBQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLFFBQVEsRUFBRTtZQUNoQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNuQixJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN2QjthQUFNLElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLEVBQUU7WUFDN0IsRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRU8sNkJBQVcsR0FBbkI7UUFDSSxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUM7WUFBRSxPQUFPO1FBQ2xFLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFTyw0QkFBVSxHQUFsQjtRQUNJLEtBQWdCLFVBQVksRUFBWixLQUFBLElBQUksQ0FBQyxPQUFPLEVBQVosY0FBWSxFQUFaLElBQVk7WUFBdkIsSUFBTSxDQUFDLFNBQUE7WUFBa0IsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQUE7UUFDeEMsS0FBZ0IsVUFBbUIsRUFBbkIsS0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBbkIsY0FBbUIsRUFBbkIsSUFBbUIsRUFBRTtZQUFoQyxJQUFNLENBQUMsU0FBQTtZQUNSLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1lBQ2hCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUNyQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9DQUFvQztTQUNyRTtRQUNELEtBQWlCLFVBQW1CLEVBQW5CLEtBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQW5CLGNBQW1CLEVBQW5CLElBQW1CLEVBQUU7WUFBakMsSUFBTSxFQUFFLFNBQUE7WUFDVCxFQUFFLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNqQixFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7U0FDekI7UUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztRQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUNkLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2hCLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLHNCQUFZLENBQUMsQ0FBQztRQUMxRCxJQUFJLE1BQU0sRUFBRTtZQUNSLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN2QyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDakI7UUFDRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsdUNBQXVDO0lBRS9CLG1DQUFpQixHQUF6QixVQUEwQixDQUFTLEVBQUUsT0FBZ0I7UUFDakQsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2YsS0FBZ0IsVUFBb0IsRUFBcEIsS0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBcEIsY0FBb0IsRUFBcEIsSUFBb0IsRUFBRTtZQUFqQyxJQUFNLENBQUMsU0FBQTtZQUNSLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO1NBQ2xDO1FBQ0QsSUFBSSxNQUFNLEtBQUssSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQztZQUN4QixJQUFJLENBQUMsT0FBTztnQkFBRSxhQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUMzQztRQUNELElBQUksT0FBTyxFQUFFO1lBQ1QsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7WUFDekIsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBRUQsdUVBQXVFO0lBQ3ZFLDJFQUEyRTtJQUMzRSx1RUFBdUU7SUFDdkUsc0RBQXNEO0lBQzlDLG9DQUFrQixHQUExQjtRQUNJLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUM7UUFDM0MsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7UUFDckQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQseUNBQXlDO0lBRXpDLDJCQUFTLEdBQVQsVUFBVSxPQUFlLEVBQUUsS0FBYTtRQUNwQyxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUNyQixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN2QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELDhDQUE4QztJQUU5QywyQkFBUyxHQUFUO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLGFBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQseUJBQU8sR0FBUCxVQUFRLElBQVk7UUFBcEIsaUJBMkJDO1FBMUJHLElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLO1lBQUUsT0FBTztRQUNqQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZCxhQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN2QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFFbEIsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pDLElBQUksUUFBUSxFQUFFO1lBQ1YscUVBQXFFO1lBQ3JFLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLHNCQUFZLENBQUMsQ0FBQztZQUMxRCxJQUFJLE1BQU07Z0JBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDZCxJQUFNLENBQUMsR0FBRyxLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQzFCLElBQUksS0FBSSxDQUFDLEtBQUssS0FBSyxLQUFLLElBQUksQ0FBQyxFQUFFO29CQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQztpQkFDOUQ7WUFDTCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDTixPQUFPO1NBQ1Y7UUFFRCw2REFBNkQ7UUFDN0QsSUFBSSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7UUFDcEIsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDOUIsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUNkLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNsQixLQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUN2QixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDWixDQUFDO0lBRU8sMEJBQVEsR0FBaEI7UUFDSSxLQUFnQixVQUFZLEVBQVosS0FBQSxJQUFJLENBQUMsT0FBTyxFQUFaLGNBQVksRUFBWixJQUFZLEVBQUU7WUFBekIsSUFBTSxDQUFDLFNBQUE7WUFDUixJQUFJLENBQUMsQ0FBQyxLQUFLO2dCQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ3pCO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELHVCQUFLLEdBQUw7UUFDSSxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssS0FBSztZQUFFLE9BQU87UUFDakMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDOUIsYUFBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDckIsa0JBQVEsQ0FBQyxVQUFVLENBQUMsa0JBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMzQyxJQUFNLElBQUksR0FBRyxrQkFBUSxDQUFDLFlBQVksSUFBSSxrQkFBUSxDQUFDLFNBQVMsQ0FBQztRQUN6RCxJQUFJLENBQUMsTUFBTSxDQUNQLElBQUksQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLGNBQWMsRUFDOUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYTtjQUMvRCxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2NBQ3hDLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTTtjQUMzQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLENBQ25FLENBQUM7SUFDTixDQUFDO0lBRU8saUNBQWUsR0FBdkI7UUFDSSxJQUFJLGtCQUFRLENBQUMsWUFBWSxHQUFHLGtCQUFRLENBQUMsU0FBUyxFQUFFO1lBQzVDLGtCQUFRLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDeEIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDakM7YUFBTTtZQUNILEVBQUUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQztJQUVELGtDQUFrQztJQUVsQyx3QkFBTSxHQUFOLFVBQU8sRUFBVTtRQUNiLHdDQUF3QztRQUN4QyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUM3QixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztZQUMvQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztTQUNsQztRQUNELHVFQUF1RTtRQUN2RSxnREFBZ0Q7UUFDaEQsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDcEMsSUFBTSxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUN0QixJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7WUFDOUMsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUk7Z0JBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDOztnQkFDeEQsSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1NBQ25EO1FBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzFDLElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLO1lBQUUsT0FBTztRQUVqQyxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVuRCxvQkFBb0I7UUFDcEIsSUFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTtZQUNoQixJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQztZQUNqQixJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxFQUFFO2dCQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO2FBQ2hDO1NBQ0o7UUFFRCx5REFBeUQ7UUFDekQsSUFBSSxDQUFDLE1BQU0sSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxLQUFnQixVQUFrQixFQUFsQixLQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFsQixjQUFrQixFQUFsQixJQUFrQixFQUFFO1lBQS9CLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQ2pGLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHO2dCQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDOztnQkFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUM7U0FDOUI7UUFFRCxpREFBaUQ7UUFDakQsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzdCLElBQUksSUFBSTtZQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBdGFnQixPQUFPO1FBRDNCLE9BQU87T0FDYSxPQUFPLENBdWEzQjtJQUFELGNBQUM7Q0F2YUQsQUF1YUMsQ0F2YW9DLEVBQUUsQ0FBQyxTQUFTLEdBdWFoRDtrQkF2YW9CLE9BQU8iLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgR2FtZURhdGEgZnJvbSBcIi4vR2FtZURhdGFcIjtcbmltcG9ydCBMZXZlbEJ1aWxkZXIsIHsgTGV2ZWxEYXRhIH0gZnJvbSBcIi4vTGV2ZWxCdWlsZGVyXCI7XG5pbXBvcnQgUGxheWVyIGZyb20gXCIuL1BsYXllclwiO1xuaW1wb3J0IENhbWVyYUZvbGxvdyBmcm9tIFwiLi9DYW1lcmFGb2xsb3dcIjtcbmltcG9ydCBTZnggZnJvbSBcIi4vU2Z4XCI7XG5cbmNvbnN0IHsgY2NjbGFzcyB9ID0gY2MuX2RlY29yYXRvcjtcblxudHlwZSBHYW1lU3RhdGUgPSBcImxvYWRpbmdcIiB8IFwicmVhZHlcIiB8IFwicnVuXCIgfCBcImRlYWRcIiB8IFwid2luXCIgfCBcInBhdXNlZFwiO1xuXG4vLyBPd25zIHRoZSBHYW1lIHNjZW5lOiBsb2FkcyBhc3NldHMgKyBsZXZlbCBKU09OLCBidWlsZHMgdGhlIHdvcmxkIHRocm91Z2hcbi8vIExldmVsQnVpbGRlciwgc3Bhd25zIDEtMiBQbGF5ZXJzLCBhbmQgcnVucyB0aGUgcmVhZHkvcnVuL2RlYWQvd2luIHN0YXRlIG1hY2hpbmUuXG4vLyBFdmVyeXRoaW5nICh3b3JsZCwgSFVEKSBpcyBjcmVhdGVkIGluIGNvZGUg4oCUIHRoZSAuZmlyZSBzY2VuZSBzdGF5cyBtaW5pbWFsLlxuLy9cbi8vIENvLW9wIHJ1bGVzIChHYW1lRGF0YS5wbGF5ZXJzID09PSAyKTogUDEgPSBXIGtleSwgUDIgPSBVUC9TUEFDRS5cbi8vIElmIG9uZSBwbGF5ZXIgZGllcyB3aGlsZSB0aGUgcGFydG5lciBzdXJ2aXZlcywgdGhleSByZXZpdmUgbmV4dCB0byB0aGVcbi8vIHBhcnRuZXIgYWZ0ZXIgM3MuIElmIGV2ZXJ5b25lIGlzIGRlYWQsIHRoZSBsZXZlbCByZXN0YXJ0cy5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBHYW1lTWdyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcblxuICAgIC8vIGdsb2JhbCBzbG93LW1vdGlvbiBmYWN0b3IgKHNsb3cgcG93ZXItdXApOyBQbGF5ZXIgbXVsdGlwbGllcyBkdCBieSB0aGlzXG4gICAgdGltZVNjYWxlID0gMTtcblxuICAgIHByaXZhdGUgY2FtZXJhTm9kZTogY2MuTm9kZSA9IG51bGw7XG4gICAgcHJpdmF0ZSB3b3JsZDogY2MuTm9kZSA9IG51bGw7XG4gICAgcHJpdmF0ZSBodWQ6IGNjLk5vZGUgPSBudWxsO1xuICAgIHByaXZhdGUgcGxheWVyczogUGxheWVyW10gPSBbXTtcbiAgICBwcml2YXRlIGxldmVsOiBMZXZlbERhdGEgPSBudWxsO1xuICAgIHByaXZhdGUgZnJhbWVzOiB7IFtrOiBzdHJpbmddOiBjYy5TcHJpdGVGcmFtZSB9ID0ge307XG5cbiAgICBwcml2YXRlIHN0YXRlOiBHYW1lU3RhdGUgPSBcImxvYWRpbmdcIjtcbiAgICBwcml2YXRlIHRpbWUgPSAwO1xuICAgIHByaXZhdGUgZGVhdGhzID0gMDtcbiAgICBwcml2YXRlIGNyeXN0YWxzVGFrZW4gPSAwO1xuICAgIHByaXZhdGUgc2xvd1QgPSAwO1xuICAgIHByaXZhdGUgZW5lbXlUID0gMDtcbiAgICBwcml2YXRlIHJvdEN1cnJlbnQgPSAwO1xuICAgIHByaXZhdGUgcm90VGFyZ2V0ID0gMDtcblxuICAgIHByaXZhdGUgbmFtZUxhYmVsOiBjYy5MYWJlbCA9IG51bGw7XG4gICAgcHJpdmF0ZSBjcnlzdGFsTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcbiAgICBwcml2YXRlIGRlYXRoTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcbiAgICBwcml2YXRlIHRpbWVMYWJlbDogY2MuTGFiZWwgPSBudWxsO1xuICAgIHByaXZhdGUgbXNnTGFiZWw6IGNjLkxhYmVsID0gbnVsbDtcbiAgICBwcml2YXRlIHN1YkxhYmVsOiBjYy5MYWJlbCA9IG51bGw7XG4gICAgcHJpdmF0ZSBzbG93T3ZlcmxheTogY2MuTm9kZSA9IG51bGw7XG5cbiAgICBpc1J1bm5pbmcoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLnN0YXRlID09PSBcInJ1blwiO1xuICAgIH1cblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgU2Z4LnByZWxvYWQoKTtcbiAgICAgICAgU2Z4LnBsYXlCZ20oKTtcbiAgICAgICAgdGhpcy5jYW1lcmFOb2RlID0gdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiTWFpbiBDYW1lcmFcIik7XG5cbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub24oY2MuU3lzdGVtRXZlbnQuRXZlbnRUeXBlLktFWV9ET1dOLCB0aGlzLm9uS2V5RG93biwgdGhpcyk7XG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoLCB0aGlzKTtcblxuICAgICAgICBjYy5yZXNvdXJjZXMubG9hZERpcihcInRleHR1cmVzXCIsIGNjLlNwcml0ZUZyYW1lLCAoZXJyLCBhc3NldHM6IGNjLlNwcml0ZUZyYW1lW10pID0+IHtcbiAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICBjYy5lcnJvcihcInRleHR1cmUgbG9hZCBmYWlsZWRcIiwgZXJyKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGEgb2YgYXNzZXRzKSB0aGlzLmZyYW1lc1thLm5hbWVdID0gYTtcbiAgICAgICAgICAgIHRoaXMub25UZXh0dXJlc1JlYWR5KCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG9uRGVzdHJveSgpIHtcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub2ZmKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfRE9XTiwgdGhpcy5vbktleURvd24sIHRoaXMpO1xuICAgIH1cblxuICAgIHByaXZhdGUgb25UZXh0dXJlc1JlYWR5KCkge1xuICAgICAgICAvLyBiYWNrZ3JvdW5kIHJpZGVzIGFsb25nIGFzIGEgY2hpbGQgb2YgdGhlIGNhbWVyYSAoYXV0byBzY3JlZW4tYWxpZ25lZCxcbiAgICAgICAgLy8gZXZlbiB3aGVuIHRoZSBjYW1lcmEgcm90YXRlcyBpbiByb3RhdGlvbiB6b25lcylcbiAgICAgICAgY29uc3QgYmcgPSBuZXcgY2MuTm9kZShcIkJHXCIpO1xuICAgICAgICBjb25zdCBiZ1NwID0gYmcuYWRkQ29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgIGJnU3Auc3ByaXRlRnJhbWUgPSB0aGlzLmZyYW1lc1tcImJnXCJdO1xuICAgICAgICBiZ1NwLnNpemVNb2RlID0gY2MuU3ByaXRlLlNpemVNb2RlLkNVU1RPTTtcbiAgICAgICAgYmcuc2V0Q29udGVudFNpemUoMTQwMCwgMTQwMCk7IC8vIG92ZXJzaXplZDogc3RheXMgY292ZXJpbmcgd2hpbGUgcm90YXRlZFxuICAgICAgICBjb25zdCBiID0gR2FtZURhdGEuc2V0dGluZ3MuYnJpZ2h0bmVzcztcbiAgICAgICAgY29uc3QgdGludCA9IExldmVsQnVpbGRlci5zY2hlbWUoKS5iZ1RpbnQ7XG4gICAgICAgIGJnLmNvbG9yID0gY2MuY29sb3IoTWF0aC5yb3VuZCh0aW50LnIgKiBiKSwgTWF0aC5yb3VuZCh0aW50LmcgKiBiKSwgTWF0aC5yb3VuZCh0aW50LmIgKiBiKSk7XG4gICAgICAgIHRoaXMuY2FtZXJhTm9kZS5hZGRDaGlsZChiZywgLTEwKTtcblxuICAgICAgICB0aGlzLndvcmxkID0gbmV3IGNjLk5vZGUoXCJXb3JsZFwiKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHRoaXMud29ybGQpO1xuXG4gICAgICAgIHRoaXMuYnVpbGRIdWQoKTtcblxuICAgICAgICBjYy5yZXNvdXJjZXMubG9hZChcImxldmVscy9sZXZlbFwiICsgR2FtZURhdGEuY3VycmVudExldmVsLCBjYy5Kc29uQXNzZXQsIChlcnIsIGFzc2V0OiBjYy5Kc29uQXNzZXQpID0+IHtcbiAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldE1zZyhcIkxFVkVMIFwiICsgR2FtZURhdGEuY3VycmVudExldmVsICsgXCIgTE9BRCBFUlJPUlwiLCBcIlwiKTtcbiAgICAgICAgICAgICAgICBjYy5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuc3RhcnRMZXZlbChhc3NldC5qc29uKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGFydExldmVsKGRhdGE6IGFueSkge1xuICAgICAgICB0aGlzLmxldmVsID0gTGV2ZWxCdWlsZGVyLmJ1aWxkKHRoaXMud29ybGQsIGRhdGEsIHRoaXMuZnJhbWVzKTtcblxuICAgICAgICBjb25zdCBjb3VudCA9IEdhbWVEYXRhLnBsYXllcnMgPT09IDIgPyAyIDogMTtcbiAgICAgICAgdGhpcy5wbGF5ZXJzID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQ7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcE5vZGUgPSBuZXcgY2MuTm9kZShcIlBsYXllclwiICsgKGkgKyAxKSk7XG4gICAgICAgICAgICBjb25zdCBzcCA9IHBOb2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICAgICAgc3Auc3ByaXRlRnJhbWUgPSB0aGlzLmZyYW1lc1tpID09PSAwID8gXCJwbGF5ZXJcIiA6IFwicGxheWVyMlwiXTtcbiAgICAgICAgICAgIHNwLnNpemVNb2RlID0gY2MuU3ByaXRlLlNpemVNb2RlLkNVU1RPTTtcbiAgICAgICAgICAgIHBOb2RlLnNldENvbnRlbnRTaXplKDM2LCAzNik7XG4gICAgICAgICAgICB0aGlzLndvcmxkLmFkZENoaWxkKHBOb2RlLCA1KTtcbiAgICAgICAgICAgIGNvbnN0IHAgPSBwTm9kZS5hZGRDb21wb25lbnQoUGxheWVyKTtcbiAgICAgICAgICAgIHAuaW5pdCh0aGlzLCB0aGlzLmxldmVsLCBpLCB0aGlzLmZyYW1lcyk7XG4gICAgICAgICAgICB0aGlzLnBsYXllcnMucHVzaChwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGZvbGxvdyA9IHRoaXMuY2FtZXJhTm9kZS5hZGRDb21wb25lbnQoQ2FtZXJhRm9sbG93KTtcbiAgICAgICAgZm9sbG93LmluaXQodGhpcy5wbGF5ZXJzWzBdLm5vZGUsIDAsIHRoaXMubGV2ZWwubGVuZ3RoIC0gNDgwKTtcbiAgICAgICAgZm9sbG93LnNuYXAoKTtcblxuICAgICAgICB0aGlzLnRpbWUgPSAwO1xuICAgICAgICB0aGlzLmRlYXRocyA9IDA7XG4gICAgICAgIHRoaXMuY3J5c3RhbHNUYWtlbiA9IDA7XG4gICAgICAgIHRoaXMudGltZVNjYWxlID0gMTtcbiAgICAgICAgdGhpcy5lbmVteVQgPSAwO1xuICAgICAgICB0aGlzLmFwcGx5Um90YXRpb25Gb3JYKHRoaXMubGV2ZWwuc3RhcnQueCwgdHJ1ZSk7XG4gICAgICAgIHRoaXMubmFtZUxhYmVsLnN0cmluZyA9IFwiTEVWRUwgXCIgKyBHYW1lRGF0YS5jdXJyZW50TGV2ZWwgKyBcIiDigJQgXCIgKyB0aGlzLmxldmVsLm5hbWVcbiAgICAgICAgICAgICsgKGNvdW50ID09PSAyID8gXCIgICBbMlBdXCIgOiBcIlwiKTtcbiAgICAgICAgdGhpcy5yZWZyZXNoSHVkKCk7XG4gICAgICAgIHRoaXMuc3RhdGUgPSBcInJlYWR5XCI7XG4gICAgICAgIHRoaXMuc2V0TXNnKFwiUFJFU1MgU1BBQ0UgVE8gUlVOXCIsXG4gICAgICAgICAgICBjb3VudCA9PT0gMlxuICAgICAgICAgICAgICAgID8gXCJQMTogVyA9IEZMSVAgICAgICBQMjogVVAgLyBTUEFDRSA9IEZMSVAgICAgICBSID0gUkVTVEFSVFwiXG4gICAgICAgICAgICAgICAgOiBcIlNQQUNFIC8gVyAvIFVQID0gRkxJUCBHUkFWSVRZICAgIFIgPSBSRVNUQVJUICAgIEVTQyA9IFBBVVNFXCIpO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0gSFVEIC0tLS0tLS0tLS1cblxuICAgIHByaXZhdGUgbWFrZUxhYmVsKHBhcmVudDogY2MuTm9kZSwgeDogbnVtYmVyLCB5OiBudW1iZXIsIHNpemU6IG51bWJlciwgY29sb3I6IGNjLkNvbG9yLCBhbmNob3JYOiBudW1iZXIgPSAwLjUpOiBjYy5MYWJlbCB7XG4gICAgICAgIGNvbnN0IG4gPSBuZXcgY2MuTm9kZShcImxhYmVsXCIpO1xuICAgICAgICBuLnNldFBvc2l0aW9uKHgsIHkpO1xuICAgICAgICBuLmFuY2hvclggPSBhbmNob3JYO1xuICAgICAgICBuLmNvbG9yID0gY29sb3I7XG4gICAgICAgIGNvbnN0IGxiID0gbi5hZGRDb21wb25lbnQoY2MuTGFiZWwpO1xuICAgICAgICBsYi5mb250U2l6ZSA9IHNpemU7XG4gICAgICAgIGxiLmxpbmVIZWlnaHQgPSBzaXplICsgNjtcbiAgICAgICAgbGIuc3RyaW5nID0gXCJcIjtcbiAgICAgICAgcGFyZW50LmFkZENoaWxkKG4pO1xuICAgICAgICByZXR1cm4gbGI7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBidWlsZEh1ZCgpIHtcbiAgICAgICAgLy8gSFVEIGlzIGEgc2libGluZyBvZiB0aGUgd29ybGQ7IHVwZGF0ZSgpIGtlZXBzIGl0IGdsdWVkIHRvIHRoZSBjYW1lcmFcbiAgICAgICAgLy8gKHBvc2l0aW9uIEFORCBhbmdsZSwgc28gaXQgc3RheXMgdXByaWdodCBpbiByb3RhdGlvbiB6b25lcykuXG4gICAgICAgIHRoaXMuaHVkID0gbmV3IGNjLk5vZGUoXCJIVURcIik7XG4gICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZCh0aGlzLmh1ZCwgMTAwKTtcblxuICAgICAgICBjb25zdCBjeWFuID0gY2MuY29sb3IoMTI3LCAyNDcsIDI1NSk7XG4gICAgICAgIGNvbnN0IHBpbmsgPSBjYy5jb2xvcigyNTUsIDEyMiwgMjAwKTtcbiAgICAgICAgY29uc3Qgb3JhbmdlID0gY2MuY29sb3IoMjU1LCAxODEsIDc0KTtcbiAgICAgICAgY29uc3Qgd2hpdGUgPSBjYy5jb2xvcigyMzUsIDI0MCwgMjU1KTtcblxuICAgICAgICB0aGlzLnNsb3dPdmVybGF5ID0gbmV3IGNjLk5vZGUoXCJzbG93RnhcIik7XG4gICAgICAgIGNvbnN0IHNvID0gdGhpcy5zbG93T3ZlcmxheS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgc28uc3ByaXRlRnJhbWUgPSB0aGlzLmZyYW1lc1tcIndoaXRlXCJdO1xuICAgICAgICBzby5zaXplTW9kZSA9IGNjLlNwcml0ZS5TaXplTW9kZS5DVVNUT007XG4gICAgICAgIHRoaXMuc2xvd092ZXJsYXkuc2V0Q29udGVudFNpemUoMTQwMCwgMTQwMCk7XG4gICAgICAgIHRoaXMuc2xvd092ZXJsYXkuY29sb3IgPSBjYy5jb2xvcigxMjAsIDE1MCwgMjU1KTtcbiAgICAgICAgdGhpcy5zbG93T3ZlcmxheS5vcGFjaXR5ID0gMDtcbiAgICAgICAgdGhpcy5odWQuYWRkQ2hpbGQodGhpcy5zbG93T3ZlcmxheSwgLTEpO1xuXG4gICAgICAgIHRoaXMubmFtZUxhYmVsID0gdGhpcy5tYWtlTGFiZWwodGhpcy5odWQsIC00NTAsIDI5NiwgMjAsIGN5YW4sIDApO1xuICAgICAgICB0aGlzLmNyeXN0YWxMYWJlbCA9IHRoaXMubWFrZUxhYmVsKHRoaXMuaHVkLCAtNDUwLCAyNjgsIDIwLCB3aGl0ZSwgMCk7XG4gICAgICAgIHRoaXMuZGVhdGhMYWJlbCA9IHRoaXMubWFrZUxhYmVsKHRoaXMuaHVkLCAtNDUwLCAyNDAsIDIwLCBwaW5rLCAwKTtcbiAgICAgICAgdGhpcy50aW1lTGFiZWwgPSB0aGlzLm1ha2VMYWJlbCh0aGlzLmh1ZCwgNDUwLCAyOTYsIDIwLCBvcmFuZ2UsIDEpO1xuICAgICAgICB0aGlzLm1zZ0xhYmVsID0gdGhpcy5tYWtlTGFiZWwodGhpcy5odWQsIDAsIDQwLCA0NCwgd2hpdGUpO1xuICAgICAgICB0aGlzLnN1YkxhYmVsID0gdGhpcy5tYWtlTGFiZWwodGhpcy5odWQsIDAsIC0xMCwgMTgsIGN5YW4pO1xuICAgIH1cblxuICAgIHByaXZhdGUgcmVmcmVzaEh1ZCgpIHtcbiAgICAgICAgdGhpcy5jcnlzdGFsTGFiZWwuc3RyaW5nID0gXCJDUllTVEFMUyAgXCIgKyB0aGlzLmNyeXN0YWxzVGFrZW4gKyBcIiAvIFwiICsgdGhpcy5sZXZlbC50b3RhbENyeXN0YWxzO1xuICAgICAgICB0aGlzLmRlYXRoTGFiZWwuc3RyaW5nID0gXCJERUFUSFMgIFwiICsgdGhpcy5kZWF0aHM7XG4gICAgICAgIHRoaXMudGltZUxhYmVsLnN0cmluZyA9IHRoaXMuZm9ybWF0VGltZSh0aGlzLnRpbWUpO1xuICAgIH1cblxuICAgIHByaXZhdGUgZm9ybWF0VGltZSh0OiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCBtID0gTWF0aC5mbG9vcih0IC8gNjApO1xuICAgICAgICBjb25zdCBzID0gdCAtIG0gKiA2MDtcbiAgICAgICAgcmV0dXJuIChtIDwgMTAgPyBcIjBcIiArIG0gOiBcIlwiICsgbSkgKyBcIjpcIiArIChzIDwgMTAgPyBcIjBcIiArIHMudG9GaXhlZCgxKSA6IHMudG9GaXhlZCgxKSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzZXRNc2cobWFpbjogc3RyaW5nLCBzdWI6IHN0cmluZykge1xuICAgICAgICB0aGlzLm1zZ0xhYmVsLnN0cmluZyA9IG1haW47XG4gICAgICAgIHRoaXMuc3ViTGFiZWwuc3RyaW5nID0gc3ViO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0gaW5wdXQgLS0tLS0tLS0tLVxuXG4gICAgcHJpdmF0ZSBvbktleURvd24oZTogY2MuRXZlbnQuRXZlbnRLZXlib2FyZCkge1xuICAgICAgICBzd2l0Y2ggKGUua2V5Q29kZSkge1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuc3BhY2U6XG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS51cDpcbiAgICAgICAgICAgICAgICB0aGlzLm9uQWN0aW9uKDEpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkudzpcbiAgICAgICAgICAgICAgICB0aGlzLm9uQWN0aW9uKDApO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkucjpcbiAgICAgICAgICAgICAgICB0aGlzLmZ1bGxSZXN0YXJ0KCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5lc2NhcGU6XG4gICAgICAgICAgICAgICAgdGhpcy50b2dnbGVQYXVzZSgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBvblRvdWNoKGU6IGNjLkV2ZW50LkV2ZW50VG91Y2gpIHtcbiAgICAgICAgLy8gMlAgdG91Y2g6IGxlZnQgaGFsZiBvZiB0aGUgc2NyZWVuID0gUDEsIHJpZ2h0IGhhbGYgPSBQMlxuICAgICAgICBjb25zdCBoYWxmID0gY2Mud2luU2l6ZS53aWR0aCAvIDI7XG4gICAgICAgIHRoaXMub25BY3Rpb24oZS5nZXRMb2NhdGlvblgoKSA8IGhhbGYgPyAwIDogMSk7XG4gICAgfVxuXG4gICAgLy8gd2hvOiAwID0gUDEgaW5wdXQsIDEgPSBQMiBpbnB1dCAoaW4gc29sbyBtb2RlIGV2ZXJ5IGlucHV0IGRyaXZlcyBQMSlcbiAgICBwcml2YXRlIG9uQWN0aW9uKHdobzogbnVtYmVyKSB7XG4gICAgICAgIHN3aXRjaCAodGhpcy5zdGF0ZSkge1xuICAgICAgICAgICAgY2FzZSBcInJlYWR5XCI6XG4gICAgICAgICAgICAgICAgdGhpcy5zdGF0ZSA9IFwicnVuXCI7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRNc2coXCJcIiwgXCJcIik7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwicnVuXCI6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZHggPSBHYW1lRGF0YS5wbGF5ZXJzID09PSAyID8gd2hvIDogMDtcbiAgICAgICAgICAgICAgICBjb25zdCBwID0gdGhpcy5wbGF5ZXJzW2lkeF07XG4gICAgICAgICAgICAgICAgaWYgKHAgJiYgcC5hbGl2ZSkgcC5mbGlwKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIFwicGF1c2VkXCI6XG4gICAgICAgICAgICAgICAgdGhpcy50b2dnbGVQYXVzZSgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBcIndpblwiOlxuICAgICAgICAgICAgICAgIHRoaXMucHJvY2VlZEFmdGVyV2luKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHRvZ2dsZVBhdXNlKCkge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZSA9PT0gXCJydW5cIikge1xuICAgICAgICAgICAgdGhpcy5zdGF0ZSA9IFwicGF1c2VkXCI7XG4gICAgICAgICAgICB0aGlzLnNldE1zZyhcIlBBVVNFRFwiLCBcIlNQQUNFID0gUkVTVU1FICAgIFIgPSBSRVNUQVJUXCIpO1xuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuc3RhdGUgPT09IFwicGF1c2VkXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc3RhdGUgPSBcInJ1blwiO1xuICAgICAgICAgICAgdGhpcy5zZXRNc2coXCJcIiwgXCJcIik7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5zdGF0ZSA9PT0gXCJ3aW5cIikge1xuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiTWVudVwiKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgZnVsbFJlc3RhcnQoKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlID09PSBcImxvYWRpbmdcIiB8fCB0aGlzLnBsYXllcnMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgICAgIHRoaXMudW5zY2hlZHVsZUFsbENhbGxiYWNrcygpO1xuICAgICAgICB0aGlzLnJlc3Bhd25BbGwoKTtcbiAgICAgICAgdGhpcy5zdGF0ZSA9IFwicmVhZHlcIjtcbiAgICAgICAgdGhpcy5zZXRNc2coXCJQUkVTUyBTUEFDRSBUTyBSVU5cIiwgXCJcIik7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSByZXNwYXduQWxsKCkge1xuICAgICAgICBmb3IgKGNvbnN0IHAgb2YgdGhpcy5wbGF5ZXJzKSBwLnJlc2V0KCk7XG4gICAgICAgIGZvciAoY29uc3QgYyBvZiB0aGlzLmxldmVsLmNyeXN0YWxzKSB7XG4gICAgICAgICAgICBjLnRha2VuID0gZmFsc2U7XG4gICAgICAgICAgICBjLm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIGMubm9kZS5zZXRQb3NpdGlvbihjLngsIGMueSk7IC8vIG1hZ25ldCBtYXkgaGF2ZSBkcmFnZ2VkIGl0IGFyb3VuZFxuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgcHUgb2YgdGhpcy5sZXZlbC5wb3dlcnVwcykge1xuICAgICAgICAgICAgcHUudGFrZW4gPSBmYWxzZTtcbiAgICAgICAgICAgIHB1Lm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNyeXN0YWxzVGFrZW4gPSAwO1xuICAgICAgICB0aGlzLnRpbWUgPSAwO1xuICAgICAgICB0aGlzLnRpbWVTY2FsZSA9IDE7XG4gICAgICAgIHRoaXMuc2xvd1QgPSAwO1xuICAgICAgICB0aGlzLnNsb3dPdmVybGF5Lm9wYWNpdHkgPSAwO1xuICAgICAgICB0aGlzLmVuZW15VCA9IDA7XG4gICAgICAgIGNvbnN0IGZvbGxvdyA9IHRoaXMuY2FtZXJhTm9kZS5nZXRDb21wb25lbnQoQ2FtZXJhRm9sbG93KTtcbiAgICAgICAgaWYgKGZvbGxvdykge1xuICAgICAgICAgICAgZm9sbG93LnNldFRhcmdldCh0aGlzLnBsYXllcnNbMF0ubm9kZSk7XG4gICAgICAgICAgICBmb2xsb3cuc25hcCgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYXBwbHlSb3RhdGlvbkZvclgodGhpcy5sZXZlbC5zdGFydC54LCB0cnVlKTtcbiAgICAgICAgdGhpcy5yZWZyZXNoSHVkKCk7XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLSByb3RhdGlvbiB6b25lcyAtLS0tLS0tLS0tXG5cbiAgICBwcml2YXRlIGFwcGx5Um90YXRpb25Gb3JYKHg6IG51bWJlciwgaW5zdGFudDogYm9vbGVhbikge1xuICAgICAgICBsZXQgdGFyZ2V0ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCByIG9mIHRoaXMubGV2ZWwucm90YXRpb25zKSB7XG4gICAgICAgICAgICBpZiAoeCA+PSByLngpIHRhcmdldCA9IHIuYW5nbGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRhcmdldCAhPT0gdGhpcy5yb3RUYXJnZXQpIHtcbiAgICAgICAgICAgIHRoaXMucm90VGFyZ2V0ID0gdGFyZ2V0O1xuICAgICAgICAgICAgaWYgKCFpbnN0YW50KSBTZngucGxheShcInRlbGVwb3J0XCIsIDAuNCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluc3RhbnQpIHtcbiAgICAgICAgICAgIHRoaXMucm90Q3VycmVudCA9IHRhcmdldDtcbiAgICAgICAgICAgIHRoaXMuYXBwbHlXb3JsZFJvdGF0aW9uKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBSb3RhdGUgdGhlIFdPUkxEIG5vZGUgKG5vdCB0aGUgY2FtZXJhIOKAlCBjYy5DYW1lcmEgaW4gMi40IGlnbm9yZXMgaXRzXG4gICAgLy8gbm9kZSdzIHJvdGF0aW9uKSBhcm91bmQgdGhlIGNhbWVyYSdzIGZvY3VzIHBvaW50LiBPYnN0YWNsZXMsIHBsYXllcnMgYW5kXG4gICAgLy8gYXBwYXJlbnQgZ3Jhdml0eSBhbGwgcm90YXRlIG9uIHNjcmVlbiwgd2hpbGUgcGh5c2ljcyBzdGF5IDFEIGJlY2F1c2VcbiAgICAvLyBQbGF5ZXIgd29ya3MgaW4gdGhlIHdvcmxkIG5vZGUncyBsb2NhbCBjb29yZGluYXRlcy5cbiAgICBwcml2YXRlIGFwcGx5V29ybGRSb3RhdGlvbigpIHtcbiAgICAgICAgY29uc3QgdGggPSB0aGlzLnJvdEN1cnJlbnQgKiBNYXRoLlBJIC8gMTgwO1xuICAgICAgICBjb25zdCBweCA9IHRoaXMuY2FtZXJhTm9kZS54OyAvLyBjYW1lcmEgeSBpcyBhbHdheXMgMFxuICAgICAgICB0aGlzLndvcmxkLmFuZ2xlID0gdGhpcy5yb3RDdXJyZW50O1xuICAgICAgICB0aGlzLndvcmxkLnggPSBweCAtIHB4ICogTWF0aC5jb3ModGgpO1xuICAgICAgICB0aGlzLndvcmxkLnkgPSAtcHggKiBNYXRoLnNpbih0aCk7XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLSBwb3dlci11cCBzdXBwb3J0IC0tLS0tLS0tLS1cblxuICAgIGFwcGx5U2xvdyhzZWNvbmRzOiBudW1iZXIsIHNjYWxlOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5zbG93VCA9IHNlY29uZHM7XG4gICAgICAgIHRoaXMudGltZVNjYWxlID0gc2NhbGU7XG4gICAgICAgIHRoaXMuc2xvd092ZXJsYXkub3BhY2l0eSA9IDUwO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0gY2FsbGJhY2tzIGZyb20gUGxheWVyIC0tLS0tLS0tLS1cblxuICAgIG9uQ3J5c3RhbCgpIHtcbiAgICAgICAgdGhpcy5jcnlzdGFsc1Rha2VuKys7XG4gICAgICAgIFNmeC5wbGF5KFwiY3J5c3RhbFwiLCAwLjcpO1xuICAgICAgICB0aGlzLnJlZnJlc2hIdWQoKTtcbiAgICB9XG5cbiAgICBvbkRlYXRoKGRlYWQ6IFBsYXllcikge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZSAhPT0gXCJydW5cIikgcmV0dXJuO1xuICAgICAgICB0aGlzLmRlYXRocysrO1xuICAgICAgICBTZngucGxheShcImRlYXRoXCIsIDAuOCk7XG4gICAgICAgIHRoaXMucmVmcmVzaEh1ZCgpO1xuXG4gICAgICAgIGNvbnN0IHN1cnZpdm9yID0gdGhpcy5hbnlBbGl2ZSgpO1xuICAgICAgICBpZiAoc3Vydml2b3IpIHtcbiAgICAgICAgICAgIC8vIHBhcnRuZXIgY2FycmllcyBvbjsgY2FtZXJhIGZvbGxvd3MgdGhlbSwgZGVhZCBwbGF5ZXIgcmV2aXZlcyBpbiAzc1xuICAgICAgICAgICAgY29uc3QgZm9sbG93ID0gdGhpcy5jYW1lcmFOb2RlLmdldENvbXBvbmVudChDYW1lcmFGb2xsb3cpO1xuICAgICAgICAgICAgaWYgKGZvbGxvdykgZm9sbG93LnNldFRhcmdldChzdXJ2aXZvci5ub2RlKTtcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKCgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzID0gdGhpcy5hbnlBbGl2ZSgpO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLnN0YXRlID09PSBcInJ1blwiICYmIHMpIHtcbiAgICAgICAgICAgICAgICAgICAgZGVhZC5yZXNwYXduQXQocy5ub2RlLnggLSA1MCwgcy5ub2RlLnksIHMuZ2V0R3Jhdml0eURpcigpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCAzKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGV2ZXJ5b25lIGlzIGRvd24g4oCUIHF1aWNrIGF1dG8tcmV0cnkga2VlcHMgdGhlIHJoeXRobSBnb2luZ1xuICAgICAgICB0aGlzLnN0YXRlID0gXCJkZWFkXCI7XG4gICAgICAgIHRoaXMudW5zY2hlZHVsZUFsbENhbGxiYWNrcygpO1xuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnJlc3Bhd25BbGwoKTtcbiAgICAgICAgICAgIHRoaXMuc3RhdGUgPSBcInJ1blwiO1xuICAgICAgICB9LCAwLjgpO1xuICAgIH1cblxuICAgIHByaXZhdGUgYW55QWxpdmUoKTogUGxheWVyIHtcbiAgICAgICAgZm9yIChjb25zdCBwIG9mIHRoaXMucGxheWVycykge1xuICAgICAgICAgICAgaWYgKHAuYWxpdmUpIHJldHVybiBwO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIG9uV2luKCkge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZSAhPT0gXCJydW5cIikgcmV0dXJuO1xuICAgICAgICB0aGlzLnN0YXRlID0gXCJ3aW5cIjtcbiAgICAgICAgdGhpcy51bnNjaGVkdWxlQWxsQ2FsbGJhY2tzKCk7XG4gICAgICAgIFNmeC5wbGF5KFwid2luXCIsIDAuOSk7XG4gICAgICAgIEdhbWVEYXRhLnVubG9ja05leHQoR2FtZURhdGEuY3VycmVudExldmVsKTtcbiAgICAgICAgY29uc3QgbGFzdCA9IEdhbWVEYXRhLmN1cnJlbnRMZXZlbCA+PSBHYW1lRGF0YS5NQVhfTEVWRUw7XG4gICAgICAgIHRoaXMuc2V0TXNnKFxuICAgICAgICAgICAgbGFzdCA/IFwiWU9VIEVTQ0FQRUQgQVNUUkEtOSFcIiA6IFwiTEVWRUwgQ0xFQVIhXCIsXG4gICAgICAgICAgICBcIkNSWVNUQUxTIFwiICsgdGhpcy5jcnlzdGFsc1Rha2VuICsgXCIvXCIgKyB0aGlzLmxldmVsLnRvdGFsQ3J5c3RhbHNcbiAgICAgICAgICAgICsgXCIgICAgVElNRSBcIiArIHRoaXMuZm9ybWF0VGltZSh0aGlzLnRpbWUpXG4gICAgICAgICAgICArIFwiICAgIERFQVRIUyBcIiArIHRoaXMuZGVhdGhzXG4gICAgICAgICAgICArIChsYXN0ID8gXCIgICAgU1BBQ0UgPSBNRU5VXCIgOiBcIiAgICBTUEFDRSA9IE5FWFQgICAgRVNDID0gTUVOVVwiKVxuICAgICAgICApO1xuICAgIH1cblxuICAgIHByaXZhdGUgcHJvY2VlZEFmdGVyV2luKCkge1xuICAgICAgICBpZiAoR2FtZURhdGEuY3VycmVudExldmVsIDwgR2FtZURhdGEuTUFYX0xFVkVMKSB7XG4gICAgICAgICAgICBHYW1lRGF0YS5jdXJyZW50TGV2ZWwrKztcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIkdhbWVcIik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJNZW51XCIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLSBwZXItZnJhbWUgLS0tLS0tLS0tLVxuXG4gICAgdXBkYXRlKGR0OiBudW1iZXIpIHtcbiAgICAgICAgLy8ga2VlcCBIVUQgZ2x1ZWQgdG8gdGhlIGNhbWVyYSB2aWV3cG9ydFxuICAgICAgICBpZiAodGhpcy5odWQgJiYgdGhpcy5jYW1lcmFOb2RlKSB7XG4gICAgICAgICAgICB0aGlzLmh1ZC54ID0gdGhpcy5jYW1lcmFOb2RlLng7XG4gICAgICAgICAgICB0aGlzLmh1ZC55ID0gdGhpcy5jYW1lcmFOb2RlLnk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gYW5pbWF0ZSBmaWVsZCByb3RhdGlvbiBhdCBhIGNvbnN0YW50IHJhdGUsIGFuZCByZS1hbmNob3IgZXZlcnkgZnJhbWVcbiAgICAgICAgLy8gYmVjYXVzZSB0aGUgcGl2b3QgKGNhbWVyYSBmb2N1cykga2VlcHMgbW92aW5nXG4gICAgICAgIGlmICh0aGlzLnJvdEN1cnJlbnQgIT09IHRoaXMucm90VGFyZ2V0KSB7XG4gICAgICAgICAgICBjb25zdCBzdGVwID0gMTEwICogZHQ7XG4gICAgICAgICAgICBjb25zdCBkaWZmID0gdGhpcy5yb3RUYXJnZXQgLSB0aGlzLnJvdEN1cnJlbnQ7XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMoZGlmZikgPD0gc3RlcCkgdGhpcy5yb3RDdXJyZW50ID0gdGhpcy5yb3RUYXJnZXQ7XG4gICAgICAgICAgICBlbHNlIHRoaXMucm90Q3VycmVudCArPSBkaWZmID4gMCA/IHN0ZXAgOiAtc3RlcDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy53b3JsZCkgdGhpcy5hcHBseVdvcmxkUm90YXRpb24oKTtcbiAgICAgICAgaWYgKHRoaXMuc3RhdGUgIT09IFwicnVuXCIpIHJldHVybjtcblxuICAgICAgICB0aGlzLnRpbWUgKz0gZHQ7XG4gICAgICAgIHRoaXMudGltZUxhYmVsLnN0cmluZyA9IHRoaXMuZm9ybWF0VGltZSh0aGlzLnRpbWUpO1xuXG4gICAgICAgIC8vIHNsb3ctbW90aW9uIHRpbWVyXG4gICAgICAgIGlmICh0aGlzLnNsb3dUID4gMCkge1xuICAgICAgICAgICAgdGhpcy5zbG93VCAtPSBkdDtcbiAgICAgICAgICAgIGlmICh0aGlzLnNsb3dUIDw9IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRpbWVTY2FsZSA9IDE7XG4gICAgICAgICAgICAgICAgdGhpcy5zbG93T3ZlcmxheS5vcGFjaXR5ID0gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHBhdHJvbCBkcm9uZXMgb3NjaWxsYXRlIG9uIGEgZml4ZWQgZGV0ZXJtaW5pc3RpYyBjbG9ja1xuICAgICAgICB0aGlzLmVuZW15VCArPSBkdCAqIHRoaXMudGltZVNjYWxlO1xuICAgICAgICBmb3IgKGNvbnN0IGUgb2YgdGhpcy5sZXZlbC5lbmVtaWVzKSB7XG4gICAgICAgICAgICBjb25zdCBvZmYgPSBNYXRoLnNpbigodGhpcy5lbmVteVQgKyBlLnBoYXNlKSAqIE1hdGguUEkgKiAyIC8gZS5wZXJpb2QpICogZS5yYW5nZTtcbiAgICAgICAgICAgIGlmIChlLmF4aXMgPT09IFwieFwiKSBlLm5vZGUueCA9IGUueDAgKyBvZmY7XG4gICAgICAgICAgICBlbHNlIGUubm9kZS55ID0gZS55MCArIG9mZjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHJvdGF0aW9uIHpvbmVzIHRyYWNrIHRoZSBsZWFkaW5nIGxpdmluZyBwbGF5ZXJcbiAgICAgICAgY29uc3QgbGVhZCA9IHRoaXMuYW55QWxpdmUoKTtcbiAgICAgICAgaWYgKGxlYWQpIHRoaXMuYXBwbHlSb3RhdGlvbkZvclgobGVhZC5ub2RlLngsIGZhbHNlKTtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/LevelBuilder.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c345141/mdA6LYsM3BvsIYf', 'LevelBuilder');
// scripts/LevelBuilder.ts

"use strict";
// Builds a level from a JSON file in resources/levels/.
// All collision is plain AABB data (center x/y + w/h); visuals are tinted sprites.
//
// Corridor layout (world coordinates, y=0 is the corridor center):
//   ceiling surface  y = +250
//   floor surface    y = -250
// Solid bands are THICK px deep behind each surface.
//
// Supported JSON fields (see levels/level1.json for an example):
//   segments  [{x, w, side:"floor"|"ceiling"}]      solid floor/ceiling bands
//   platforms [{x, y, w, h}]                        free-floating solids
//   spikes    [{x, side}]                           lethal triangles on a surface
//   crystals  [{x, y}]                              collectibles
//   powerups  [{x, y, type:"shield"|"slow"|"magnet"}]
//   teleports [{x, y, tx, ty}]                      one-way A->B (tx MUST be > x+50)
//   enemies   [{x, y, axis:"x"|"y", range, period, phase?}]   patrol drones
//   rotations [{x, angle}]                          visual field rotation from x on
//   goal      {x}                                   portal column
//   speed, length, start {x, side}, name
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCHEMES = exports.THICK = exports.CEIL_Y = exports.FLOOR_Y = void 0;
var GameData_1 = require("./GameData");
exports.FLOOR_Y = -250;
exports.CEIL_Y = 250;
exports.THICK = 70;
// Color schemes selectable in settings. Index = GameData.settings.scheme.
exports.SCHEMES = [
    {
        name: "NEON",
        floorEdge: cc.color(53, 240, 255),
        ceilEdge: cc.color(255, 122, 200),
        platform: cc.color(20, 26, 58),
        goal: cc.color(255, 181, 74),
        crystal: cc.color(127, 247, 255),
        bgTint: cc.color(255, 255, 255)
    },
    {
        name: "SUNSET",
        floorEdge: cc.color(255, 181, 74),
        ceilEdge: cc.color(255, 90, 90),
        platform: cc.color(46, 22, 38),
        goal: cc.color(255, 240, 150),
        crystal: cc.color(255, 214, 140),
        bgTint: cc.color(255, 196, 170)
    },
    {
        name: "MATRIX",
        floorEdge: cc.color(77, 255, 124),
        ceilEdge: cc.color(196, 255, 80),
        platform: cc.color(12, 34, 20),
        goal: cc.color(190, 255, 130),
        crystal: cc.color(170, 255, 190),
        bgTint: cc.color(180, 255, 200)
    }
];
var POWER_COLORS = {
    shield: cc.color(120, 220, 255),
    slow: cc.color(170, 140, 255),
    magnet: cc.color(255, 230, 110)
};
var LevelBuilder = /** @class */ (function () {
    function LevelBuilder() {
    }
    LevelBuilder.scheme = function () {
        var i = GameData_1.default.settings.scheme;
        return exports.SCHEMES[i >= 0 && i < exports.SCHEMES.length ? i : 0];
    };
    LevelBuilder.build = function (world, data, frames) {
        var pal = LevelBuilder.scheme();
        var solids = [];
        var spikes = [];
        var crystals = [];
        var powerups = [];
        var teleports = [];
        var enemies = [];
        var rotations = [];
        var sprite = function (frame, x, y, w, h, color, z) {
            var n = new cc.Node(frame);
            var sp = n.addComponent(cc.Sprite);
            sp.spriteFrame = frames[frame];
            sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            n.setContentSize(w, h);
            n.setPosition(x, y);
            if (color)
                n.color = color;
            if (z !== undefined)
                n.zIndex = z;
            world.addChild(n);
            return n;
        };
        var addGlow = function (parent, size, color, opacity) {
            var glow = new cc.Node("glow");
            var gs = glow.addComponent(cc.Sprite);
            gs.spriteFrame = frames["glow"];
            gs.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            glow.setContentSize(size, size);
            glow.color = color;
            glow.opacity = opacity;
            parent.addChild(glow, -1);
            return glow;
        };
        // --- floor / ceiling segments ---
        for (var _i = 0, _a = (data.segments || []); _i < _a.length; _i++) {
            var seg = _a[_i];
            var isFloor = seg.side === "floor";
            var cy = isFloor ? exports.FLOOR_Y - exports.THICK / 2 : exports.CEIL_Y + exports.THICK / 2;
            var cx = seg.x + seg.w / 2;
            solids.push({ x: cx, y: cy, w: seg.w, h: exports.THICK });
            sprite("white", cx, cy, seg.w, exports.THICK, pal.platform);
            var edgeY = isFloor ? exports.FLOOR_Y - 2 : exports.CEIL_Y + 2;
            sprite("white", cx, edgeY, seg.w, 4, isFloor ? pal.floorEdge : pal.ceilEdge, 1);
        }
        // --- free-floating platforms ---
        for (var _b = 0, _c = (data.platforms || []); _b < _c.length; _b++) {
            var p = _c[_b];
            solids.push({ x: p.x, y: p.y, w: p.w, h: p.h });
            sprite("white", p.x, p.y, p.w, p.h, pal.platform);
            sprite("white", p.x, p.y + p.h / 2 - 2, p.w, 4, pal.floorEdge, 1);
            sprite("white", p.x, p.y - p.h / 2 + 2, p.w, 4, pal.ceilEdge, 1);
        }
        // --- spikes ---
        for (var _d = 0, _e = (data.spikes || []); _d < _e.length; _d++) {
            var s = _e[_d];
            var onFloor = s.side === "floor";
            var baseY = onFloor ? exports.FLOOR_Y : exports.CEIL_Y;
            var n = sprite("spike", s.x, baseY + (onFloor ? 19 : -19), 48, 40, undefined, 2);
            if (!onFloor)
                n.scaleY = -1;
            spikes.push({ x: s.x, y: baseY + (onFloor ? 13 : -13), w: 22, h: 24 });
        }
        // --- crystals ---
        for (var _f = 0, _g = (data.crystals || []); _f < _g.length; _f++) {
            var c = _g[_f];
            var n = sprite("crystal", c.x, c.y, 28, 28, pal.crystal, 2);
            addGlow(n, 64, pal.crystal, 120);
            cc.tween(n).by(2.4, { angle: 360 }).repeatForever().start();
            crystals.push({ x: c.x, y: c.y, taken: false, node: n });
        }
        // --- powerups ---
        for (var _h = 0, _j = (data.powerups || []); _h < _j.length; _h++) {
            var p = _j[_h];
            var col = POWER_COLORS[p.type] || cc.Color.WHITE;
            var n = sprite(p.type, p.x, p.y, 34, 34, undefined, 2);
            addGlow(n, 80, col, 140);
            cc.tween(n)
                .to(0.8, { y: p.y + 8 }, { easing: "sineInOut" })
                .to(0.8, { y: p.y - 8 }, { easing: "sineInOut" })
                .repeatForever()
                .start();
            powerups.push({ x: p.x, y: p.y, type: p.type, taken: false, node: n });
        }
        // --- teleports (one-way entry -> exit) ---
        for (var _k = 0, _l = (data.teleports || []); _k < _l.length; _k++) {
            var t = _l[_k];
            var entry = sprite("tport", t.x, t.y, 52, 52, cc.color(190, 120, 255), 2);
            addGlow(entry, 90, cc.color(190, 120, 255), 150);
            cc.tween(entry).by(1.6, { angle: -360 }).repeatForever().start();
            var exit = sprite("tport", t.tx, t.ty, 52, 52, cc.color(120, 255, 210), 2);
            exit.opacity = 170;
            addGlow(exit, 70, cc.color(120, 255, 210), 100);
            cc.tween(exit).by(2.2, { angle: 360 }).repeatForever().start();
            teleports.push({ x: t.x, y: t.y, tx: t.tx, ty: t.ty });
        }
        // --- patrol drones ---
        for (var _m = 0, _o = (data.enemies || []); _m < _o.length; _m++) {
            var e = _o[_m];
            var n = sprite("drone", e.x, e.y, 36, 36, undefined, 3);
            addGlow(n, 70, cc.color(255, 90, 90), 130);
            cc.tween(n).by(1.2, { angle: 360 }).repeatForever().start();
            enemies.push({
                node: n,
                x0: e.x,
                y0: e.y,
                axis: e.axis === "x" ? "x" : "y",
                range: e.range || 120,
                period: e.period || 2,
                phase: e.phase || 0
            });
        }
        // --- visual rotation zones ---
        for (var _p = 0, _q = (data.rotations || []); _p < _q.length; _p++) {
            var r = _q[_p];
            rotations.push({ x: r.x, angle: r.angle || 0 });
            // subtle marker so players see something changed here
            var marker = sprite("white", r.x, 0, 6, 2 * exports.CEIL_Y, pal.goal, 0);
            marker.opacity = 40;
        }
        rotations.sort(function (a, b) { return a.x - b.x; });
        // --- goal portal: a glowing column spanning the corridor ---
        var goalX = data.goal.x;
        var goal = { x: goalX, y: 0, w: 56, h: 2 * exports.CEIL_Y };
        var beam = sprite("white", goalX, 0, 24, 2 * exports.CEIL_Y, pal.goal, 1);
        beam.opacity = 90;
        var ring = sprite("portal", goalX, 0, 96, 160, undefined, 2);
        cc.tween(ring)
            .to(0.8, { scale: 1.12 })
            .to(0.8, { scale: 1.0 })
            .repeatForever()
            .start();
        cc.tween(beam)
            .to(0.6, { opacity: 150 })
            .to(0.6, { opacity: 60 })
            .repeatForever()
            .start();
        var startSide = (data.start && data.start.side) === "ceiling" ? 1 : -1;
        var startY = startSide === -1 ? exports.FLOOR_Y + 18 : exports.CEIL_Y - 18;
        return {
            name: data.name || "LEVEL",
            speed: (data.speed || 300) * GameData_1.default.settings.speed,
            length: data.length,
            start: { x: (data.start && data.start.x) || 0, y: startY },
            solids: solids,
            spikes: spikes,
            crystals: crystals,
            powerups: powerups,
            teleports: teleports,
            enemies: enemies,
            rotations: rotations,
            goal: goal,
            totalCrystals: crystals.length
        };
    };
    return LevelBuilder;
}());
exports.default = LevelBuilder;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcTGV2ZWxCdWlsZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSx3REFBd0Q7QUFDeEQsbUZBQW1GO0FBQ25GLEVBQUU7QUFDRixtRUFBbUU7QUFDbkUsOEJBQThCO0FBQzlCLDhCQUE4QjtBQUM5QixxREFBcUQ7QUFDckQsRUFBRTtBQUNGLGlFQUFpRTtBQUNqRSw4RUFBOEU7QUFDOUUseUVBQXlFO0FBQ3pFLGtGQUFrRjtBQUNsRixpRUFBaUU7QUFDakUsc0RBQXNEO0FBQ3RELHFGQUFxRjtBQUNyRiw0RUFBNEU7QUFDNUUsb0ZBQW9GO0FBQ3BGLGtFQUFrRTtBQUNsRSx5Q0FBeUM7OztBQUV6Qyx1Q0FBa0M7QUFFckIsUUFBQSxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDZixRQUFBLE1BQU0sR0FBRyxHQUFHLENBQUM7QUFDYixRQUFBLEtBQUssR0FBRyxFQUFFLENBQUM7QUE4RHhCLDBFQUEwRTtBQUM3RCxRQUFBLE9BQU8sR0FBRztJQUNuQjtRQUNJLElBQUksRUFBRSxNQUFNO1FBQ1osU0FBUyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDakMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDakMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDOUIsSUFBSSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUM7UUFDNUIsT0FBTyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDaEMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7S0FDbEM7SUFDRDtRQUNJLElBQUksRUFBRSxRQUFRO1FBQ2QsU0FBUyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUM7UUFDakMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDL0IsUUFBUSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDOUIsSUFBSSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDN0IsT0FBTyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDaEMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7S0FDbEM7SUFDRDtRQUNJLElBQUksRUFBRSxRQUFRO1FBQ2QsU0FBUyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDakMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUM7UUFDaEMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDOUIsSUFBSSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDN0IsT0FBTyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDaEMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7S0FDbEM7Q0FDSixDQUFDO0FBRUYsSUFBTSxZQUFZLEdBQThCO0lBQzVDLE1BQU0sRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO0lBQy9CLElBQUksRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO0lBQzdCLE1BQU0sRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO0NBQ2xDLENBQUM7QUFFRjtJQUFBO0lBb0tBLENBQUM7SUFsS1UsbUJBQU0sR0FBYjtRQUNJLElBQU0sQ0FBQyxHQUFHLGtCQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztRQUNuQyxPQUFPLGVBQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxlQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFFTSxrQkFBSyxHQUFaLFVBQWEsS0FBYyxFQUFFLElBQVMsRUFBRSxNQUF1QztRQUMzRSxJQUFNLEdBQUcsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbEMsSUFBTSxNQUFNLEdBQWMsRUFBRSxDQUFDO1FBQzdCLElBQU0sTUFBTSxHQUFjLEVBQUUsQ0FBQztRQUM3QixJQUFNLFFBQVEsR0FBaUIsRUFBRSxDQUFDO1FBQ2xDLElBQU0sUUFBUSxHQUFpQixFQUFFLENBQUM7UUFDbEMsSUFBTSxTQUFTLEdBQWtCLEVBQUUsQ0FBQztRQUNwQyxJQUFNLE9BQU8sR0FBZSxFQUFFLENBQUM7UUFDL0IsSUFBTSxTQUFTLEdBQWtCLEVBQUUsQ0FBQztRQUVwQyxJQUFNLE1BQU0sR0FBRyxVQUFDLEtBQWEsRUFBRSxDQUFTLEVBQUUsQ0FBUyxFQUFFLENBQVMsRUFBRSxDQUFTLEVBQUUsS0FBZ0IsRUFBRSxDQUFVO1lBQ25HLElBQU0sQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM3QixJQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyQyxFQUFFLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvQixFQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztZQUN4QyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUN2QixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNwQixJQUFJLEtBQUs7Z0JBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDM0IsSUFBSSxDQUFDLEtBQUssU0FBUztnQkFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUNsQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2xCLE9BQU8sQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDO1FBRUYsSUFBTSxPQUFPLEdBQUcsVUFBQyxNQUFlLEVBQUUsSUFBWSxFQUFFLEtBQWUsRUFBRSxPQUFlO1lBQzVFLElBQU0sSUFBSSxHQUFHLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqQyxJQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN4QyxFQUFFLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNoQyxFQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztZQUN4QyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNoQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNuQixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztZQUN2QixNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFCLE9BQU8sSUFBSSxDQUFDO1FBQ2hCLENBQUMsQ0FBQztRQUVGLG1DQUFtQztRQUNuQyxLQUFrQixVQUFxQixFQUFyQixNQUFDLElBQUksQ0FBQyxRQUFRLElBQUksRUFBRSxDQUFDLEVBQXJCLGNBQXFCLEVBQXJCLElBQXFCLEVBQUU7WUFBcEMsSUFBTSxHQUFHLFNBQUE7WUFDVixJQUFNLE9BQU8sR0FBRyxHQUFHLENBQUMsSUFBSSxLQUFLLE9BQU8sQ0FBQztZQUNyQyxJQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQU8sR0FBRyxhQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFNLEdBQUcsYUFBSyxHQUFHLENBQUMsQ0FBQztZQUM5RCxJQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLGFBQUssRUFBRSxDQUFDLENBQUM7WUFDbEQsTUFBTSxDQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsYUFBSyxFQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNwRCxJQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQU0sR0FBRyxDQUFDLENBQUM7WUFDakQsTUFBTSxDQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNuRjtRQUVELGtDQUFrQztRQUNsQyxLQUFnQixVQUFzQixFQUF0QixNQUFDLElBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLEVBQXRCLGNBQXNCLEVBQXRCLElBQXNCLEVBQUU7WUFBbkMsSUFBTSxDQUFDLFNBQUE7WUFDUixNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ2hELE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDbEQsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDbEUsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDcEU7UUFFRCxpQkFBaUI7UUFDakIsS0FBZ0IsVUFBbUIsRUFBbkIsTUFBQyxJQUFJLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUFuQixjQUFtQixFQUFuQixJQUFtQixFQUFFO1lBQWhDLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUM7WUFDbkMsSUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFPLENBQUMsQ0FBQyxDQUFDLGNBQU0sQ0FBQztZQUN6QyxJQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDbkYsSUFBSSxDQUFDLE9BQU87Z0JBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztZQUM1QixNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDMUU7UUFFRCxtQkFBbUI7UUFDbkIsS0FBZ0IsVUFBcUIsRUFBckIsTUFBQyxJQUFJLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQyxFQUFyQixjQUFxQixFQUFyQixJQUFxQixFQUFFO1lBQWxDLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzlELE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDakMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDNUQsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDNUQ7UUFFRCxtQkFBbUI7UUFDbkIsS0FBZ0IsVUFBcUIsRUFBckIsTUFBQyxJQUFJLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQyxFQUFyQixjQUFxQixFQUFyQixJQUFxQixFQUFFO1lBQWxDLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBTSxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNuRCxJQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDekQsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ3pCLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2lCQUNOLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsQ0FBQztpQkFDaEQsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxDQUFDO2lCQUNoRCxhQUFhLEVBQUU7aUJBQ2YsS0FBSyxFQUFFLENBQUM7WUFDYixRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUMxRTtRQUVELDRDQUE0QztRQUM1QyxLQUFnQixVQUFzQixFQUF0QixNQUFDLElBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLEVBQXRCLGNBQXNCLEVBQXRCLElBQXNCLEVBQUU7WUFBbkMsSUFBTSxDQUFDLFNBQUE7WUFDUixJQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM1RSxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDakQsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNqRSxJQUFNLElBQUksR0FBRyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM3RSxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztZQUNuQixPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDaEQsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDL0QsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUMxRDtRQUVELHdCQUF3QjtRQUN4QixLQUFnQixVQUFvQixFQUFwQixNQUFDLElBQUksQ0FBQyxPQUFPLElBQUksRUFBRSxDQUFDLEVBQXBCLGNBQW9CLEVBQXBCLElBQW9CLEVBQUU7WUFBakMsSUFBTSxDQUFDLFNBQUE7WUFDUixJQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUMxRCxPQUFPLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDM0MsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDNUQsT0FBTyxDQUFDLElBQUksQ0FBQztnQkFDVCxJQUFJLEVBQUUsQ0FBQztnQkFDUCxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNQLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHO2dCQUNoQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxHQUFHO2dCQUNyQixNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDO2dCQUNyQixLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNOO1FBRUQsZ0NBQWdDO1FBQ2hDLEtBQWdCLFVBQXNCLEVBQXRCLE1BQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsRUFBdEIsY0FBc0IsRUFBdEIsSUFBc0IsRUFBRTtZQUFuQyxJQUFNLENBQUMsU0FBQTtZQUNSLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ2hELHNEQUFzRDtZQUN0RCxJQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsY0FBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDbkUsTUFBTSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7U0FDdkI7UUFDRCxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSyxPQUFBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBVCxDQUFTLENBQUMsQ0FBQztRQUVwQyw4REFBOEQ7UUFDOUQsSUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDMUIsSUFBTSxJQUFJLEdBQVksRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLGNBQU0sRUFBRSxDQUFDO1FBQy9ELElBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFHLGNBQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLElBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUMvRCxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQzthQUNULEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUM7YUFDeEIsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQzthQUN2QixhQUFhLEVBQUU7YUFDZixLQUFLLEVBQUUsQ0FBQztRQUNiLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO2FBQ1QsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQzthQUN6QixFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDO2FBQ3hCLGFBQWEsRUFBRTthQUNmLEtBQUssRUFBRSxDQUFDO1FBRWIsSUFBTSxTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pFLElBQU0sTUFBTSxHQUFHLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBTyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsY0FBTSxHQUFHLEVBQUUsQ0FBQztRQUU3RCxPQUFPO1lBQ0gsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLElBQUksT0FBTztZQUMxQixLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsQ0FBQyxHQUFHLGtCQUFRLENBQUMsUUFBUSxDQUFDLEtBQUs7WUFDcEQsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRTtZQUMxRCxNQUFNLEVBQUUsTUFBTTtZQUNkLE1BQU0sRUFBRSxNQUFNO1lBQ2QsUUFBUSxFQUFFLFFBQVE7WUFDbEIsUUFBUSxFQUFFLFFBQVE7WUFDbEIsU0FBUyxFQUFFLFNBQVM7WUFDcEIsT0FBTyxFQUFFLE9BQU87WUFDaEIsU0FBUyxFQUFFLFNBQVM7WUFDcEIsSUFBSSxFQUFFLElBQUk7WUFDVixhQUFhLEVBQUUsUUFBUSxDQUFDLE1BQU07U0FDakMsQ0FBQztJQUNOLENBQUM7SUFDTCxtQkFBQztBQUFELENBcEtBLEFBb0tDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBCdWlsZHMgYSBsZXZlbCBmcm9tIGEgSlNPTiBmaWxlIGluIHJlc291cmNlcy9sZXZlbHMvLlxuLy8gQWxsIGNvbGxpc2lvbiBpcyBwbGFpbiBBQUJCIGRhdGEgKGNlbnRlciB4L3kgKyB3L2gpOyB2aXN1YWxzIGFyZSB0aW50ZWQgc3ByaXRlcy5cbi8vXG4vLyBDb3JyaWRvciBsYXlvdXQgKHdvcmxkIGNvb3JkaW5hdGVzLCB5PTAgaXMgdGhlIGNvcnJpZG9yIGNlbnRlcik6XG4vLyAgIGNlaWxpbmcgc3VyZmFjZSAgeSA9ICsyNTBcbi8vICAgZmxvb3Igc3VyZmFjZSAgICB5ID0gLTI1MFxuLy8gU29saWQgYmFuZHMgYXJlIFRISUNLIHB4IGRlZXAgYmVoaW5kIGVhY2ggc3VyZmFjZS5cbi8vXG4vLyBTdXBwb3J0ZWQgSlNPTiBmaWVsZHMgKHNlZSBsZXZlbHMvbGV2ZWwxLmpzb24gZm9yIGFuIGV4YW1wbGUpOlxuLy8gICBzZWdtZW50cyAgW3t4LCB3LCBzaWRlOlwiZmxvb3JcInxcImNlaWxpbmdcIn1dICAgICAgc29saWQgZmxvb3IvY2VpbGluZyBiYW5kc1xuLy8gICBwbGF0Zm9ybXMgW3t4LCB5LCB3LCBofV0gICAgICAgICAgICAgICAgICAgICAgICBmcmVlLWZsb2F0aW5nIHNvbGlkc1xuLy8gICBzcGlrZXMgICAgW3t4LCBzaWRlfV0gICAgICAgICAgICAgICAgICAgICAgICAgICBsZXRoYWwgdHJpYW5nbGVzIG9uIGEgc3VyZmFjZVxuLy8gICBjcnlzdGFscyAgW3t4LCB5fV0gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xsZWN0aWJsZXNcbi8vICAgcG93ZXJ1cHMgIFt7eCwgeSwgdHlwZTpcInNoaWVsZFwifFwic2xvd1wifFwibWFnbmV0XCJ9XVxuLy8gICB0ZWxlcG9ydHMgW3t4LCB5LCB0eCwgdHl9XSAgICAgICAgICAgICAgICAgICAgICBvbmUtd2F5IEEtPkIgKHR4IE1VU1QgYmUgPiB4KzUwKVxuLy8gICBlbmVtaWVzICAgW3t4LCB5LCBheGlzOlwieFwifFwieVwiLCByYW5nZSwgcGVyaW9kLCBwaGFzZT99XSAgIHBhdHJvbCBkcm9uZXNcbi8vICAgcm90YXRpb25zIFt7eCwgYW5nbGV9XSAgICAgICAgICAgICAgICAgICAgICAgICAgdmlzdWFsIGZpZWxkIHJvdGF0aW9uIGZyb20geCBvblxuLy8gICBnb2FsICAgICAge3h9ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3J0YWwgY29sdW1uXG4vLyAgIHNwZWVkLCBsZW5ndGgsIHN0YXJ0IHt4LCBzaWRlfSwgbmFtZVxuXG5pbXBvcnQgR2FtZURhdGEgZnJvbSBcIi4vR2FtZURhdGFcIjtcblxuZXhwb3J0IGNvbnN0IEZMT09SX1kgPSAtMjUwO1xuZXhwb3J0IGNvbnN0IENFSUxfWSA9IDI1MDtcbmV4cG9ydCBjb25zdCBUSElDSyA9IDcwO1xuXG5leHBvcnQgaW50ZXJmYWNlIFJlY3REZWYge1xuICAgIHg6IG51bWJlcjsgLy8gY2VudGVyXG4gICAgeTogbnVtYmVyOyAvLyBjZW50ZXJcbiAgICB3OiBudW1iZXI7XG4gICAgaDogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENyeXN0YWxSZWYge1xuICAgIHg6IG51bWJlcjtcbiAgICB5OiBudW1iZXI7XG4gICAgdGFrZW46IGJvb2xlYW47XG4gICAgbm9kZTogY2MuTm9kZTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQb3dlcnVwUmVmIHtcbiAgICB4OiBudW1iZXI7XG4gICAgeTogbnVtYmVyO1xuICAgIHR5cGU6IHN0cmluZzsgLy8gXCJzaGllbGRcIiB8IFwic2xvd1wiIHwgXCJtYWduZXRcIlxuICAgIHRha2VuOiBib29sZWFuO1xuICAgIG5vZGU6IGNjLk5vZGU7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGVsZXBvcnRSZWYge1xuICAgIHg6IG51bWJlcjtcbiAgICB5OiBudW1iZXI7XG4gICAgdHg6IG51bWJlcjtcbiAgICB0eTogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEVuZW15UmVmIHtcbiAgICBub2RlOiBjYy5Ob2RlO1xuICAgIHgwOiBudW1iZXI7XG4gICAgeTA6IG51bWJlcjtcbiAgICBheGlzOiBzdHJpbmc7ICAvLyBcInhcIiB8IFwieVwiXG4gICAgcmFuZ2U6IG51bWJlcjtcbiAgICBwZXJpb2Q6IG51bWJlcjtcbiAgICBwaGFzZTogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJvdGF0aW9uUmVmIHtcbiAgICB4OiBudW1iZXI7XG4gICAgYW5nbGU6IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBMZXZlbERhdGEge1xuICAgIG5hbWU6IHN0cmluZztcbiAgICBzcGVlZDogbnVtYmVyO1xuICAgIGxlbmd0aDogbnVtYmVyO1xuICAgIHN0YXJ0OiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH07XG4gICAgc29saWRzOiBSZWN0RGVmW107XG4gICAgc3Bpa2VzOiBSZWN0RGVmW107XG4gICAgY3J5c3RhbHM6IENyeXN0YWxSZWZbXTtcbiAgICBwb3dlcnVwczogUG93ZXJ1cFJlZltdO1xuICAgIHRlbGVwb3J0czogVGVsZXBvcnRSZWZbXTtcbiAgICBlbmVtaWVzOiBFbmVteVJlZltdO1xuICAgIHJvdGF0aW9uczogUm90YXRpb25SZWZbXTtcbiAgICBnb2FsOiBSZWN0RGVmO1xuICAgIHRvdGFsQ3J5c3RhbHM6IG51bWJlcjtcbn1cblxuLy8gQ29sb3Igc2NoZW1lcyBzZWxlY3RhYmxlIGluIHNldHRpbmdzLiBJbmRleCA9IEdhbWVEYXRhLnNldHRpbmdzLnNjaGVtZS5cbmV4cG9ydCBjb25zdCBTQ0hFTUVTID0gW1xuICAgIHtcbiAgICAgICAgbmFtZTogXCJORU9OXCIsXG4gICAgICAgIGZsb29yRWRnZTogY2MuY29sb3IoNTMsIDI0MCwgMjU1KSxcbiAgICAgICAgY2VpbEVkZ2U6IGNjLmNvbG9yKDI1NSwgMTIyLCAyMDApLFxuICAgICAgICBwbGF0Zm9ybTogY2MuY29sb3IoMjAsIDI2LCA1OCksXG4gICAgICAgIGdvYWw6IGNjLmNvbG9yKDI1NSwgMTgxLCA3NCksXG4gICAgICAgIGNyeXN0YWw6IGNjLmNvbG9yKDEyNywgMjQ3LCAyNTUpLFxuICAgICAgICBiZ1RpbnQ6IGNjLmNvbG9yKDI1NSwgMjU1LCAyNTUpXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6IFwiU1VOU0VUXCIsXG4gICAgICAgIGZsb29yRWRnZTogY2MuY29sb3IoMjU1LCAxODEsIDc0KSxcbiAgICAgICAgY2VpbEVkZ2U6IGNjLmNvbG9yKDI1NSwgOTAsIDkwKSxcbiAgICAgICAgcGxhdGZvcm06IGNjLmNvbG9yKDQ2LCAyMiwgMzgpLFxuICAgICAgICBnb2FsOiBjYy5jb2xvcigyNTUsIDI0MCwgMTUwKSxcbiAgICAgICAgY3J5c3RhbDogY2MuY29sb3IoMjU1LCAyMTQsIDE0MCksXG4gICAgICAgIGJnVGludDogY2MuY29sb3IoMjU1LCAxOTYsIDE3MClcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogXCJNQVRSSVhcIixcbiAgICAgICAgZmxvb3JFZGdlOiBjYy5jb2xvcig3NywgMjU1LCAxMjQpLFxuICAgICAgICBjZWlsRWRnZTogY2MuY29sb3IoMTk2LCAyNTUsIDgwKSxcbiAgICAgICAgcGxhdGZvcm06IGNjLmNvbG9yKDEyLCAzNCwgMjApLFxuICAgICAgICBnb2FsOiBjYy5jb2xvcigxOTAsIDI1NSwgMTMwKSxcbiAgICAgICAgY3J5c3RhbDogY2MuY29sb3IoMTcwLCAyNTUsIDE5MCksXG4gICAgICAgIGJnVGludDogY2MuY29sb3IoMTgwLCAyNTUsIDIwMClcbiAgICB9XG5dO1xuXG5jb25zdCBQT1dFUl9DT0xPUlM6IHsgW3Q6IHN0cmluZ106IGNjLkNvbG9yIH0gPSB7XG4gICAgc2hpZWxkOiBjYy5jb2xvcigxMjAsIDIyMCwgMjU1KSxcbiAgICBzbG93OiBjYy5jb2xvcigxNzAsIDE0MCwgMjU1KSxcbiAgICBtYWduZXQ6IGNjLmNvbG9yKDI1NSwgMjMwLCAxMTApXG59O1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMZXZlbEJ1aWxkZXIge1xuXG4gICAgc3RhdGljIHNjaGVtZSgpIHtcbiAgICAgICAgY29uc3QgaSA9IEdhbWVEYXRhLnNldHRpbmdzLnNjaGVtZTtcbiAgICAgICAgcmV0dXJuIFNDSEVNRVNbaSA+PSAwICYmIGkgPCBTQ0hFTUVTLmxlbmd0aCA/IGkgOiAwXTtcbiAgICB9XG5cbiAgICBzdGF0aWMgYnVpbGQod29ybGQ6IGNjLk5vZGUsIGRhdGE6IGFueSwgZnJhbWVzOiB7IFtrOiBzdHJpbmddOiBjYy5TcHJpdGVGcmFtZSB9KTogTGV2ZWxEYXRhIHtcbiAgICAgICAgY29uc3QgcGFsID0gTGV2ZWxCdWlsZGVyLnNjaGVtZSgpO1xuICAgICAgICBjb25zdCBzb2xpZHM6IFJlY3REZWZbXSA9IFtdO1xuICAgICAgICBjb25zdCBzcGlrZXM6IFJlY3REZWZbXSA9IFtdO1xuICAgICAgICBjb25zdCBjcnlzdGFsczogQ3J5c3RhbFJlZltdID0gW107XG4gICAgICAgIGNvbnN0IHBvd2VydXBzOiBQb3dlcnVwUmVmW10gPSBbXTtcbiAgICAgICAgY29uc3QgdGVsZXBvcnRzOiBUZWxlcG9ydFJlZltdID0gW107XG4gICAgICAgIGNvbnN0IGVuZW1pZXM6IEVuZW15UmVmW10gPSBbXTtcbiAgICAgICAgY29uc3Qgcm90YXRpb25zOiBSb3RhdGlvblJlZltdID0gW107XG5cbiAgICAgICAgY29uc3Qgc3ByaXRlID0gKGZyYW1lOiBzdHJpbmcsIHg6IG51bWJlciwgeTogbnVtYmVyLCB3OiBudW1iZXIsIGg6IG51bWJlciwgY29sb3I/OiBjYy5Db2xvciwgej86IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgY29uc3QgbiA9IG5ldyBjYy5Ob2RlKGZyYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IHNwID0gbi5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgICAgIHNwLnNwcml0ZUZyYW1lID0gZnJhbWVzW2ZyYW1lXTtcbiAgICAgICAgICAgIHNwLnNpemVNb2RlID0gY2MuU3ByaXRlLlNpemVNb2RlLkNVU1RPTTtcbiAgICAgICAgICAgIG4uc2V0Q29udGVudFNpemUodywgaCk7XG4gICAgICAgICAgICBuLnNldFBvc2l0aW9uKHgsIHkpO1xuICAgICAgICAgICAgaWYgKGNvbG9yKSBuLmNvbG9yID0gY29sb3I7XG4gICAgICAgICAgICBpZiAoeiAhPT0gdW5kZWZpbmVkKSBuLnpJbmRleCA9IHo7XG4gICAgICAgICAgICB3b3JsZC5hZGRDaGlsZChuKTtcbiAgICAgICAgICAgIHJldHVybiBuO1xuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IGFkZEdsb3cgPSAocGFyZW50OiBjYy5Ob2RlLCBzaXplOiBudW1iZXIsIGNvbG9yOiBjYy5Db2xvciwgb3BhY2l0eTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBnbG93ID0gbmV3IGNjLk5vZGUoXCJnbG93XCIpO1xuICAgICAgICAgICAgY29uc3QgZ3MgPSBnbG93LmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICAgICAgZ3Muc3ByaXRlRnJhbWUgPSBmcmFtZXNbXCJnbG93XCJdO1xuICAgICAgICAgICAgZ3Muc2l6ZU1vZGUgPSBjYy5TcHJpdGUuU2l6ZU1vZGUuQ1VTVE9NO1xuICAgICAgICAgICAgZ2xvdy5zZXRDb250ZW50U2l6ZShzaXplLCBzaXplKTtcbiAgICAgICAgICAgIGdsb3cuY29sb3IgPSBjb2xvcjtcbiAgICAgICAgICAgIGdsb3cub3BhY2l0eSA9IG9wYWNpdHk7XG4gICAgICAgICAgICBwYXJlbnQuYWRkQ2hpbGQoZ2xvdywgLTEpO1xuICAgICAgICAgICAgcmV0dXJuIGdsb3c7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gLS0tIGZsb29yIC8gY2VpbGluZyBzZWdtZW50cyAtLS1cbiAgICAgICAgZm9yIChjb25zdCBzZWcgb2YgKGRhdGEuc2VnbWVudHMgfHwgW10pKSB7XG4gICAgICAgICAgICBjb25zdCBpc0Zsb29yID0gc2VnLnNpZGUgPT09IFwiZmxvb3JcIjtcbiAgICAgICAgICAgIGNvbnN0IGN5ID0gaXNGbG9vciA/IEZMT09SX1kgLSBUSElDSyAvIDIgOiBDRUlMX1kgKyBUSElDSyAvIDI7XG4gICAgICAgICAgICBjb25zdCBjeCA9IHNlZy54ICsgc2VnLncgLyAyO1xuICAgICAgICAgICAgc29saWRzLnB1c2goeyB4OiBjeCwgeTogY3ksIHc6IHNlZy53LCBoOiBUSElDSyB9KTtcbiAgICAgICAgICAgIHNwcml0ZShcIndoaXRlXCIsIGN4LCBjeSwgc2VnLncsIFRISUNLLCBwYWwucGxhdGZvcm0pO1xuICAgICAgICAgICAgY29uc3QgZWRnZVkgPSBpc0Zsb29yID8gRkxPT1JfWSAtIDIgOiBDRUlMX1kgKyAyO1xuICAgICAgICAgICAgc3ByaXRlKFwid2hpdGVcIiwgY3gsIGVkZ2VZLCBzZWcudywgNCwgaXNGbG9vciA/IHBhbC5mbG9vckVkZ2UgOiBwYWwuY2VpbEVkZ2UsIDEpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gLS0tIGZyZWUtZmxvYXRpbmcgcGxhdGZvcm1zIC0tLVxuICAgICAgICBmb3IgKGNvbnN0IHAgb2YgKGRhdGEucGxhdGZvcm1zIHx8IFtdKSkge1xuICAgICAgICAgICAgc29saWRzLnB1c2goeyB4OiBwLngsIHk6IHAueSwgdzogcC53LCBoOiBwLmggfSk7XG4gICAgICAgICAgICBzcHJpdGUoXCJ3aGl0ZVwiLCBwLngsIHAueSwgcC53LCBwLmgsIHBhbC5wbGF0Zm9ybSk7XG4gICAgICAgICAgICBzcHJpdGUoXCJ3aGl0ZVwiLCBwLngsIHAueSArIHAuaCAvIDIgLSAyLCBwLncsIDQsIHBhbC5mbG9vckVkZ2UsIDEpO1xuICAgICAgICAgICAgc3ByaXRlKFwid2hpdGVcIiwgcC54LCBwLnkgLSBwLmggLyAyICsgMiwgcC53LCA0LCBwYWwuY2VpbEVkZ2UsIDEpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gLS0tIHNwaWtlcyAtLS1cbiAgICAgICAgZm9yIChjb25zdCBzIG9mIChkYXRhLnNwaWtlcyB8fCBbXSkpIHtcbiAgICAgICAgICAgIGNvbnN0IG9uRmxvb3IgPSBzLnNpZGUgPT09IFwiZmxvb3JcIjtcbiAgICAgICAgICAgIGNvbnN0IGJhc2VZID0gb25GbG9vciA/IEZMT09SX1kgOiBDRUlMX1k7XG4gICAgICAgICAgICBjb25zdCBuID0gc3ByaXRlKFwic3Bpa2VcIiwgcy54LCBiYXNlWSArIChvbkZsb29yID8gMTkgOiAtMTkpLCA0OCwgNDAsIHVuZGVmaW5lZCwgMik7XG4gICAgICAgICAgICBpZiAoIW9uRmxvb3IpIG4uc2NhbGVZID0gLTE7XG4gICAgICAgICAgICBzcGlrZXMucHVzaCh7IHg6IHMueCwgeTogYmFzZVkgKyAob25GbG9vciA/IDEzIDogLTEzKSwgdzogMjIsIGg6IDI0IH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gLS0tIGNyeXN0YWxzIC0tLVxuICAgICAgICBmb3IgKGNvbnN0IGMgb2YgKGRhdGEuY3J5c3RhbHMgfHwgW10pKSB7XG4gICAgICAgICAgICBjb25zdCBuID0gc3ByaXRlKFwiY3J5c3RhbFwiLCBjLngsIGMueSwgMjgsIDI4LCBwYWwuY3J5c3RhbCwgMik7XG4gICAgICAgICAgICBhZGRHbG93KG4sIDY0LCBwYWwuY3J5c3RhbCwgMTIwKTtcbiAgICAgICAgICAgIGNjLnR3ZWVuKG4pLmJ5KDIuNCwgeyBhbmdsZTogMzYwIH0pLnJlcGVhdEZvcmV2ZXIoKS5zdGFydCgpO1xuICAgICAgICAgICAgY3J5c3RhbHMucHVzaCh7IHg6IGMueCwgeTogYy55LCB0YWtlbjogZmFsc2UsIG5vZGU6IG4gfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyAtLS0gcG93ZXJ1cHMgLS0tXG4gICAgICAgIGZvciAoY29uc3QgcCBvZiAoZGF0YS5wb3dlcnVwcyB8fCBbXSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvbCA9IFBPV0VSX0NPTE9SU1twLnR5cGVdIHx8IGNjLkNvbG9yLldISVRFO1xuICAgICAgICAgICAgY29uc3QgbiA9IHNwcml0ZShwLnR5cGUsIHAueCwgcC55LCAzNCwgMzQsIHVuZGVmaW5lZCwgMik7XG4gICAgICAgICAgICBhZGRHbG93KG4sIDgwLCBjb2wsIDE0MCk7XG4gICAgICAgICAgICBjYy50d2VlbihuKVxuICAgICAgICAgICAgICAgIC50bygwLjgsIHsgeTogcC55ICsgOCB9LCB7IGVhc2luZzogXCJzaW5lSW5PdXRcIiB9KVxuICAgICAgICAgICAgICAgIC50bygwLjgsIHsgeTogcC55IC0gOCB9LCB7IGVhc2luZzogXCJzaW5lSW5PdXRcIiB9KVxuICAgICAgICAgICAgICAgIC5yZXBlYXRGb3JldmVyKClcbiAgICAgICAgICAgICAgICAuc3RhcnQoKTtcbiAgICAgICAgICAgIHBvd2VydXBzLnB1c2goeyB4OiBwLngsIHk6IHAueSwgdHlwZTogcC50eXBlLCB0YWtlbjogZmFsc2UsIG5vZGU6IG4gfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyAtLS0gdGVsZXBvcnRzIChvbmUtd2F5IGVudHJ5IC0+IGV4aXQpIC0tLVxuICAgICAgICBmb3IgKGNvbnN0IHQgb2YgKGRhdGEudGVsZXBvcnRzIHx8IFtdKSkge1xuICAgICAgICAgICAgY29uc3QgZW50cnkgPSBzcHJpdGUoXCJ0cG9ydFwiLCB0LngsIHQueSwgNTIsIDUyLCBjYy5jb2xvcigxOTAsIDEyMCwgMjU1KSwgMik7XG4gICAgICAgICAgICBhZGRHbG93KGVudHJ5LCA5MCwgY2MuY29sb3IoMTkwLCAxMjAsIDI1NSksIDE1MCk7XG4gICAgICAgICAgICBjYy50d2VlbihlbnRyeSkuYnkoMS42LCB7IGFuZ2xlOiAtMzYwIH0pLnJlcGVhdEZvcmV2ZXIoKS5zdGFydCgpO1xuICAgICAgICAgICAgY29uc3QgZXhpdCA9IHNwcml0ZShcInRwb3J0XCIsIHQudHgsIHQudHksIDUyLCA1MiwgY2MuY29sb3IoMTIwLCAyNTUsIDIxMCksIDIpO1xuICAgICAgICAgICAgZXhpdC5vcGFjaXR5ID0gMTcwO1xuICAgICAgICAgICAgYWRkR2xvdyhleGl0LCA3MCwgY2MuY29sb3IoMTIwLCAyNTUsIDIxMCksIDEwMCk7XG4gICAgICAgICAgICBjYy50d2VlbihleGl0KS5ieSgyLjIsIHsgYW5nbGU6IDM2MCB9KS5yZXBlYXRGb3JldmVyKCkuc3RhcnQoKTtcbiAgICAgICAgICAgIHRlbGVwb3J0cy5wdXNoKHsgeDogdC54LCB5OiB0LnksIHR4OiB0LnR4LCB0eTogdC50eSB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIC0tLSBwYXRyb2wgZHJvbmVzIC0tLVxuICAgICAgICBmb3IgKGNvbnN0IGUgb2YgKGRhdGEuZW5lbWllcyB8fCBbXSkpIHtcbiAgICAgICAgICAgIGNvbnN0IG4gPSBzcHJpdGUoXCJkcm9uZVwiLCBlLngsIGUueSwgMzYsIDM2LCB1bmRlZmluZWQsIDMpO1xuICAgICAgICAgICAgYWRkR2xvdyhuLCA3MCwgY2MuY29sb3IoMjU1LCA5MCwgOTApLCAxMzApO1xuICAgICAgICAgICAgY2MudHdlZW4obikuYnkoMS4yLCB7IGFuZ2xlOiAzNjAgfSkucmVwZWF0Rm9yZXZlcigpLnN0YXJ0KCk7XG4gICAgICAgICAgICBlbmVtaWVzLnB1c2goe1xuICAgICAgICAgICAgICAgIG5vZGU6IG4sXG4gICAgICAgICAgICAgICAgeDA6IGUueCxcbiAgICAgICAgICAgICAgICB5MDogZS55LFxuICAgICAgICAgICAgICAgIGF4aXM6IGUuYXhpcyA9PT0gXCJ4XCIgPyBcInhcIiA6IFwieVwiLFxuICAgICAgICAgICAgICAgIHJhbmdlOiBlLnJhbmdlIHx8IDEyMCxcbiAgICAgICAgICAgICAgICBwZXJpb2Q6IGUucGVyaW9kIHx8IDIsXG4gICAgICAgICAgICAgICAgcGhhc2U6IGUucGhhc2UgfHwgMFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyAtLS0gdmlzdWFsIHJvdGF0aW9uIHpvbmVzIC0tLVxuICAgICAgICBmb3IgKGNvbnN0IHIgb2YgKGRhdGEucm90YXRpb25zIHx8IFtdKSkge1xuICAgICAgICAgICAgcm90YXRpb25zLnB1c2goeyB4OiByLngsIGFuZ2xlOiByLmFuZ2xlIHx8IDAgfSk7XG4gICAgICAgICAgICAvLyBzdWJ0bGUgbWFya2VyIHNvIHBsYXllcnMgc2VlIHNvbWV0aGluZyBjaGFuZ2VkIGhlcmVcbiAgICAgICAgICAgIGNvbnN0IG1hcmtlciA9IHNwcml0ZShcIndoaXRlXCIsIHIueCwgMCwgNiwgMiAqIENFSUxfWSwgcGFsLmdvYWwsIDApO1xuICAgICAgICAgICAgbWFya2VyLm9wYWNpdHkgPSA0MDtcbiAgICAgICAgfVxuICAgICAgICByb3RhdGlvbnMuc29ydCgoYSwgYikgPT4gYS54IC0gYi54KTtcblxuICAgICAgICAvLyAtLS0gZ29hbCBwb3J0YWw6IGEgZ2xvd2luZyBjb2x1bW4gc3Bhbm5pbmcgdGhlIGNvcnJpZG9yIC0tLVxuICAgICAgICBjb25zdCBnb2FsWCA9IGRhdGEuZ29hbC54O1xuICAgICAgICBjb25zdCBnb2FsOiBSZWN0RGVmID0geyB4OiBnb2FsWCwgeTogMCwgdzogNTYsIGg6IDIgKiBDRUlMX1kgfTtcbiAgICAgICAgY29uc3QgYmVhbSA9IHNwcml0ZShcIndoaXRlXCIsIGdvYWxYLCAwLCAyNCwgMiAqIENFSUxfWSwgcGFsLmdvYWwsIDEpO1xuICAgICAgICBiZWFtLm9wYWNpdHkgPSA5MDtcbiAgICAgICAgY29uc3QgcmluZyA9IHNwcml0ZShcInBvcnRhbFwiLCBnb2FsWCwgMCwgOTYsIDE2MCwgdW5kZWZpbmVkLCAyKTtcbiAgICAgICAgY2MudHdlZW4ocmluZylcbiAgICAgICAgICAgIC50bygwLjgsIHsgc2NhbGU6IDEuMTIgfSlcbiAgICAgICAgICAgIC50bygwLjgsIHsgc2NhbGU6IDEuMCB9KVxuICAgICAgICAgICAgLnJlcGVhdEZvcmV2ZXIoKVxuICAgICAgICAgICAgLnN0YXJ0KCk7XG4gICAgICAgIGNjLnR3ZWVuKGJlYW0pXG4gICAgICAgICAgICAudG8oMC42LCB7IG9wYWNpdHk6IDE1MCB9KVxuICAgICAgICAgICAgLnRvKDAuNiwgeyBvcGFjaXR5OiA2MCB9KVxuICAgICAgICAgICAgLnJlcGVhdEZvcmV2ZXIoKVxuICAgICAgICAgICAgLnN0YXJ0KCk7XG5cbiAgICAgICAgY29uc3Qgc3RhcnRTaWRlID0gKGRhdGEuc3RhcnQgJiYgZGF0YS5zdGFydC5zaWRlKSA9PT0gXCJjZWlsaW5nXCIgPyAxIDogLTE7XG4gICAgICAgIGNvbnN0IHN0YXJ0WSA9IHN0YXJ0U2lkZSA9PT0gLTEgPyBGTE9PUl9ZICsgMTggOiBDRUlMX1kgLSAxODtcblxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbmFtZTogZGF0YS5uYW1lIHx8IFwiTEVWRUxcIixcbiAgICAgICAgICAgIHNwZWVkOiAoZGF0YS5zcGVlZCB8fCAzMDApICogR2FtZURhdGEuc2V0dGluZ3Muc3BlZWQsXG4gICAgICAgICAgICBsZW5ndGg6IGRhdGEubGVuZ3RoLFxuICAgICAgICAgICAgc3RhcnQ6IHsgeDogKGRhdGEuc3RhcnQgJiYgZGF0YS5zdGFydC54KSB8fCAwLCB5OiBzdGFydFkgfSxcbiAgICAgICAgICAgIHNvbGlkczogc29saWRzLFxuICAgICAgICAgICAgc3Bpa2VzOiBzcGlrZXMsXG4gICAgICAgICAgICBjcnlzdGFsczogY3J5c3RhbHMsXG4gICAgICAgICAgICBwb3dlcnVwczogcG93ZXJ1cHMsXG4gICAgICAgICAgICB0ZWxlcG9ydHM6IHRlbGVwb3J0cyxcbiAgICAgICAgICAgIGVuZW1pZXM6IGVuZW1pZXMsXG4gICAgICAgICAgICByb3RhdGlvbnM6IHJvdGF0aW9ucyxcbiAgICAgICAgICAgIGdvYWw6IGdvYWwsXG4gICAgICAgICAgICB0b3RhbENyeXN0YWxzOiBjcnlzdGFscy5sZW5ndGhcbiAgICAgICAgfTtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/CameraFollow.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '45c56IOadVCLoDL+QPsM0Cw', 'CameraFollow');
// scripts/CameraFollow.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var ccclass = cc._decorator.ccclass;
// Follows the player horizontally with a forward look-ahead.
// Attached at runtime by GameMgr; configure via init().
var CameraFollow = /** @class */ (function (_super) {
    __extends(CameraFollow, _super);
    function CameraFollow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.target = null;
        _this.minX = 0;
        _this.maxX = 0;
        _this.lookAhead = 160;
        _this.smooth = 10;
        return _this;
    }
    CameraFollow.prototype.init = function (target, minX, maxX) {
        this.target = target;
        this.minX = minX;
        this.maxX = Math.max(minX, maxX);
        this.node.x = minX;
        this.node.y = 0;
    };
    CameraFollow.prototype.setTarget = function (target) {
        this.target = target;
    };
    CameraFollow.prototype.snap = function () {
        if (!this.target)
            return;
        this.node.x = this.clampX(this.target.x + this.lookAhead);
    };
    CameraFollow.prototype.clampX = function (x) {
        return Math.max(this.minX, Math.min(this.maxX, x));
    };
    CameraFollow.prototype.update = function (dt) {
        if (!this.target || !this.target.isValid)
            return;
        var targetX = this.clampX(this.target.x + this.lookAhead);
        var t = Math.min(1, this.smooth * dt);
        this.node.x += (targetX - this.node.x) * t;
    };
    CameraFollow = __decorate([
        ccclass
    ], CameraFollow);
    return CameraFollow;
}(cc.Component));
exports.default = CameraFollow;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcQ2FtZXJhRm9sbG93LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFRLElBQUEsT0FBTyxHQUFLLEVBQUUsQ0FBQyxVQUFVLFFBQWxCLENBQW1CO0FBRWxDLDZEQUE2RDtBQUM3RCx3REFBd0Q7QUFFeEQ7SUFBMEMsZ0NBQVk7SUFBdEQ7UUFBQSxxRUFrQ0M7UUFqQ1csWUFBTSxHQUFZLElBQUksQ0FBQztRQUN2QixVQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ1QsVUFBSSxHQUFHLENBQUMsQ0FBQztRQUNULGVBQVMsR0FBRyxHQUFHLENBQUM7UUFDaEIsWUFBTSxHQUFHLEVBQUUsQ0FBQzs7SUE2QnhCLENBQUM7SUEzQkcsMkJBQUksR0FBSixVQUFLLE1BQWUsRUFBRSxJQUFZLEVBQUUsSUFBWTtRQUM1QyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUNyQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUNuQixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUVELGdDQUFTLEdBQVQsVUFBVSxNQUFlO1FBQ3JCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ3pCLENBQUM7SUFFRCwyQkFBSSxHQUFKO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO1lBQUUsT0FBTztRQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRU8sNkJBQU0sR0FBZCxVQUFlLENBQVM7UUFDcEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVELDZCQUFNLEdBQU4sVUFBTyxFQUFVO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ2pELElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzVELElBQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQWpDZ0IsWUFBWTtRQURoQyxPQUFPO09BQ2EsWUFBWSxDQWtDaEM7SUFBRCxtQkFBQztDQWxDRCxBQWtDQyxDQWxDeUMsRUFBRSxDQUFDLFNBQVMsR0FrQ3JEO2tCQWxDb0IsWUFBWSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHsgY2NjbGFzcyB9ID0gY2MuX2RlY29yYXRvcjtcblxuLy8gRm9sbG93cyB0aGUgcGxheWVyIGhvcml6b250YWxseSB3aXRoIGEgZm9yd2FyZCBsb29rLWFoZWFkLlxuLy8gQXR0YWNoZWQgYXQgcnVudGltZSBieSBHYW1lTWdyOyBjb25maWd1cmUgdmlhIGluaXQoKS5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDYW1lcmFGb2xsb3cgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIHByaXZhdGUgdGFyZ2V0OiBjYy5Ob2RlID0gbnVsbDtcbiAgICBwcml2YXRlIG1pblggPSAwO1xuICAgIHByaXZhdGUgbWF4WCA9IDA7XG4gICAgcHJpdmF0ZSBsb29rQWhlYWQgPSAxNjA7XG4gICAgcHJpdmF0ZSBzbW9vdGggPSAxMDtcblxuICAgIGluaXQodGFyZ2V0OiBjYy5Ob2RlLCBtaW5YOiBudW1iZXIsIG1heFg6IG51bWJlcikge1xuICAgICAgICB0aGlzLnRhcmdldCA9IHRhcmdldDtcbiAgICAgICAgdGhpcy5taW5YID0gbWluWDtcbiAgICAgICAgdGhpcy5tYXhYID0gTWF0aC5tYXgobWluWCwgbWF4WCk7XG4gICAgICAgIHRoaXMubm9kZS54ID0gbWluWDtcbiAgICAgICAgdGhpcy5ub2RlLnkgPSAwO1xuICAgIH1cblxuICAgIHNldFRhcmdldCh0YXJnZXQ6IGNjLk5vZGUpIHtcbiAgICAgICAgdGhpcy50YXJnZXQgPSB0YXJnZXQ7XG4gICAgfVxuXG4gICAgc25hcCgpIHtcbiAgICAgICAgaWYgKCF0aGlzLnRhcmdldCkgcmV0dXJuO1xuICAgICAgICB0aGlzLm5vZGUueCA9IHRoaXMuY2xhbXBYKHRoaXMudGFyZ2V0LnggKyB0aGlzLmxvb2tBaGVhZCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjbGFtcFgoeDogbnVtYmVyKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIE1hdGgubWF4KHRoaXMubWluWCwgTWF0aC5taW4odGhpcy5tYXhYLCB4KSk7XG4gICAgfVxuXG4gICAgdXBkYXRlKGR0OiBudW1iZXIpIHtcbiAgICAgICAgaWYgKCF0aGlzLnRhcmdldCB8fCAhdGhpcy50YXJnZXQuaXNWYWxpZCkgcmV0dXJuO1xuICAgICAgICBjb25zdCB0YXJnZXRYID0gdGhpcy5jbGFtcFgodGhpcy50YXJnZXQueCArIHRoaXMubG9va0FoZWFkKTtcbiAgICAgICAgY29uc3QgdCA9IE1hdGgubWluKDEsIHRoaXMuc21vb3RoICogZHQpO1xuICAgICAgICB0aGlzLm5vZGUueCArPSAodGFyZ2V0WCAtIHRoaXMubm9kZS54KSAqIHQ7XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Sfx.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a1fddKPDD9HmrL1HaGWmp/l', 'Sfx');
// scripts/Sfx.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameData_1 = require("./GameData");
// Tiny audio helper. Clips live in assets/resources/audio/<name>.wav (or .mp3).
// All volumes are scaled by the user's settings (GameData.settings).
var Sfx = /** @class */ (function () {
    function Sfx() {
    }
    Sfx.preload = function () {
        var names = ["flip", "crystal", "death", "win", "click", "power", "teleport", "shieldbreak"];
        var _loop_1 = function (n) {
            if (Sfx.clips[n])
                return "continue";
            cc.resources.load("audio/" + n, cc.AudioClip, function (err, clip) {
                if (!err && clip)
                    Sfx.clips[n] = clip;
            });
        };
        for (var _i = 0, names_1 = names; _i < names_1.length; _i++) {
            var n = names_1[_i];
            _loop_1(n);
        }
    };
    Sfx.play = function (name, volume) {
        if (volume === void 0) { volume = 1; }
        var clip = Sfx.clips[name];
        var v = volume * GameData_1.default.settings.sfx;
        if (clip && v > 0)
            cc.audioEngine.play(clip, false, v);
    };
    // BGM is optional: drop a file at resources/audio/bgm.mp3 and this picks it up.
    Sfx.playBgm = function () {
        if (Sfx.bgmId >= 0) {
            Sfx.applyBgmVolume();
            return;
        }
        cc.resources.load("audio/bgm", cc.AudioClip, function (err, clip) {
            if (!err && clip && Sfx.bgmId < 0) {
                Sfx.bgmId = cc.audioEngine.play(clip, true, GameData_1.default.settings.bgm);
            }
        });
    };
    Sfx.applyBgmVolume = function () {
        if (Sfx.bgmId >= 0)
            cc.audioEngine.setVolume(Sfx.bgmId, GameData_1.default.settings.bgm);
    };
    Sfx.stopBgm = function () {
        if (Sfx.bgmId >= 0) {
            cc.audioEngine.stop(Sfx.bgmId);
            Sfx.bgmId = -1;
        }
    };
    Sfx.clips = {};
    Sfx.bgmId = -1;
    return Sfx;
}());
exports.default = Sfx;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcU2Z4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdUNBQWtDO0FBRWxDLGdGQUFnRjtBQUNoRixxRUFBcUU7QUFDckU7SUFBQTtJQTJDQSxDQUFDO0lBdkNVLFdBQU8sR0FBZDtRQUNJLElBQU0sS0FBSyxHQUFHLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLGFBQWEsQ0FBQyxDQUFDO2dDQUNwRixDQUFDO1lBQ1IsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztrQ0FBVztZQUMzQixFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsVUFBQyxHQUFHLEVBQUUsSUFBSTtnQkFDcEQsSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJO29CQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBVyxDQUFDO1lBQ2pELENBQUMsQ0FBQyxDQUFDOztRQUpQLEtBQWdCLFVBQUssRUFBTCxlQUFLLEVBQUwsbUJBQUssRUFBTCxJQUFLO1lBQWhCLElBQU0sQ0FBQyxjQUFBO29CQUFELENBQUM7U0FLWDtJQUNMLENBQUM7SUFFTSxRQUFJLEdBQVgsVUFBWSxJQUFZLEVBQUUsTUFBa0I7UUFBbEIsdUJBQUEsRUFBQSxVQUFrQjtRQUN4QyxJQUFNLElBQUksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzdCLElBQU0sQ0FBQyxHQUFHLE1BQU0sR0FBRyxrQkFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7UUFDekMsSUFBSSxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUM7WUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCxnRkFBZ0Y7SUFDekUsV0FBTyxHQUFkO1FBQ0ksSUFBSSxHQUFHLENBQUMsS0FBSyxJQUFJLENBQUMsRUFBRTtZQUNoQixHQUFHLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDckIsT0FBTztTQUNWO1FBQ0QsRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsVUFBQyxHQUFHLEVBQUUsSUFBSTtZQUNuRCxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTtnQkFDL0IsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFXLEVBQUUsSUFBSSxFQUFFLGtCQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzdFO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU0sa0JBQWMsR0FBckI7UUFDSSxJQUFJLEdBQUcsQ0FBQyxLQUFLLElBQUksQ0FBQztZQUFFLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsa0JBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbkYsQ0FBQztJQUVNLFdBQU8sR0FBZDtRQUNJLElBQUksR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLEVBQUU7WUFDaEIsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDbEI7SUFDTCxDQUFDO0lBekNjLFNBQUssR0FBcUMsRUFBRSxDQUFDO0lBQzdDLFNBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztJQXlDOUIsVUFBQztDQTNDRCxBQTJDQyxJQUFBO2tCQTNDb0IsR0FBRyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBHYW1lRGF0YSBmcm9tIFwiLi9HYW1lRGF0YVwiO1xuXG4vLyBUaW55IGF1ZGlvIGhlbHBlci4gQ2xpcHMgbGl2ZSBpbiBhc3NldHMvcmVzb3VyY2VzL2F1ZGlvLzxuYW1lPi53YXYgKG9yIC5tcDMpLlxuLy8gQWxsIHZvbHVtZXMgYXJlIHNjYWxlZCBieSB0aGUgdXNlcidzIHNldHRpbmdzIChHYW1lRGF0YS5zZXR0aW5ncykuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTZngge1xuICAgIHByaXZhdGUgc3RhdGljIGNsaXBzOiB7IFtuYW1lOiBzdHJpbmddOiBjYy5BdWRpb0NsaXAgfSA9IHt9O1xuICAgIHByaXZhdGUgc3RhdGljIGJnbUlkID0gLTE7XG5cbiAgICBzdGF0aWMgcHJlbG9hZCgpIHtcbiAgICAgICAgY29uc3QgbmFtZXMgPSBbXCJmbGlwXCIsIFwiY3J5c3RhbFwiLCBcImRlYXRoXCIsIFwid2luXCIsIFwiY2xpY2tcIiwgXCJwb3dlclwiLCBcInRlbGVwb3J0XCIsIFwic2hpZWxkYnJlYWtcIl07XG4gICAgICAgIGZvciAoY29uc3QgbiBvZiBuYW1lcykge1xuICAgICAgICAgICAgaWYgKFNmeC5jbGlwc1tuXSkgY29udGludWU7XG4gICAgICAgICAgICBjYy5yZXNvdXJjZXMubG9hZChcImF1ZGlvL1wiICsgbiwgY2MuQXVkaW9DbGlwLCAoZXJyLCBjbGlwKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFlcnIgJiYgY2xpcCkgU2Z4LmNsaXBzW25dID0gY2xpcCBhcyBhbnk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHN0YXRpYyBwbGF5KG5hbWU6IHN0cmluZywgdm9sdW1lOiBudW1iZXIgPSAxKSB7XG4gICAgICAgIGNvbnN0IGNsaXAgPSBTZnguY2xpcHNbbmFtZV07XG4gICAgICAgIGNvbnN0IHYgPSB2b2x1bWUgKiBHYW1lRGF0YS5zZXR0aW5ncy5zZng7XG4gICAgICAgIGlmIChjbGlwICYmIHYgPiAwKSBjYy5hdWRpb0VuZ2luZS5wbGF5KGNsaXAsIGZhbHNlLCB2KTtcbiAgICB9XG5cbiAgICAvLyBCR00gaXMgb3B0aW9uYWw6IGRyb3AgYSBmaWxlIGF0IHJlc291cmNlcy9hdWRpby9iZ20ubXAzIGFuZCB0aGlzIHBpY2tzIGl0IHVwLlxuICAgIHN0YXRpYyBwbGF5QmdtKCkge1xuICAgICAgICBpZiAoU2Z4LmJnbUlkID49IDApIHtcbiAgICAgICAgICAgIFNmeC5hcHBseUJnbVZvbHVtZSgpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNjLnJlc291cmNlcy5sb2FkKFwiYXVkaW8vYmdtXCIsIGNjLkF1ZGlvQ2xpcCwgKGVyciwgY2xpcCkgPT4ge1xuICAgICAgICAgICAgaWYgKCFlcnIgJiYgY2xpcCAmJiBTZnguYmdtSWQgPCAwKSB7XG4gICAgICAgICAgICAgICAgU2Z4LmJnbUlkID0gY2MuYXVkaW9FbmdpbmUucGxheShjbGlwIGFzIGFueSwgdHJ1ZSwgR2FtZURhdGEuc2V0dGluZ3MuYmdtKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgc3RhdGljIGFwcGx5QmdtVm9sdW1lKCkge1xuICAgICAgICBpZiAoU2Z4LmJnbUlkID49IDApIGNjLmF1ZGlvRW5naW5lLnNldFZvbHVtZShTZnguYmdtSWQsIEdhbWVEYXRhLnNldHRpbmdzLmJnbSk7XG4gICAgfVxuXG4gICAgc3RhdGljIHN0b3BCZ20oKSB7XG4gICAgICAgIGlmIChTZnguYmdtSWQgPj0gMCkge1xuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUuc3RvcChTZnguYmdtSWQpO1xuICAgICAgICAgICAgU2Z4LmJnbUlkID0gLTE7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd321bCHWN5HsYuFcKvZ02bl', 'Player');
// scripts/Player.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Sfx_1 = require("./Sfx");
var ccclass = cc._decorator.ccclass;
var GRAVITY = 2600;
var MAX_FALL = 1000;
var BODY_W = 30;
var BODY_H = 34;
// Auto-runner with flippable gravity. Pure kinematic AABB physics —
// no physics engine, so behavior is deterministic and easy to tune.
// Created and configured at runtime by GameMgr via init().
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.alive = true;
        _this.index = 0; // 0 = P1, 1 = P2
        _this.mgr = null;
        _this.level = null;
        _this.vy = 0;
        _this.gravityDir = -1; // -1: pulls toward floor, +1: toward ceiling
        _this.grounded = false;
        // power-up state
        _this.shield = false;
        _this.magnetT = 0;
        _this.invincibleT = 0;
        _this.shieldNode = null;
        _this.magnetAura = null;
        return _this;
    }
    Player.prototype.init = function (mgr, level, index, frames) {
        this.mgr = mgr;
        this.level = level;
        this.index = index;
        this.shieldNode = new cc.Node("shieldFx");
        var sp = this.shieldNode.addComponent(cc.Sprite);
        sp.spriteFrame = frames["shield"];
        sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.shieldNode.setContentSize(54, 54);
        this.shieldNode.active = false;
        this.node.addChild(this.shieldNode, 1);
        this.magnetAura = new cc.Node("magnetFx");
        var ms = this.magnetAura.addComponent(cc.Sprite);
        ms.spriteFrame = frames["glow"];
        ms.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.magnetAura.setContentSize(120, 120);
        this.magnetAura.color = cc.color(255, 230, 110);
        this.magnetAura.opacity = 150;
        this.magnetAura.active = false;
        this.node.addChild(this.magnetAura, -1);
        this.reset();
    };
    Player.prototype.reset = function () {
        this.node.stopAllActions();
        // P2 trails slightly behind so the cubes don't overlap
        this.node.setPosition(this.level.start.x - this.index * 60, this.level.start.y);
        this.vy = 0;
        this.gravityDir = -1;
        this.grounded = true;
        this.alive = true;
        this.shield = false;
        this.magnetT = 0;
        this.invincibleT = 0;
        this.shieldNode.active = false;
        this.magnetAura.active = false;
        this.node.active = true;
        this.node.opacity = 255;
        this.node.scaleX = 1;
        this.node.scaleY = 1;
        this.node.angle = 0;
    };
    // Co-op revive: drop in next to the surviving partner.
    Player.prototype.respawnAt = function (x, y, gravityDir) {
        this.node.stopAllActions();
        this.node.setPosition(x, y);
        this.vy = 0;
        this.gravityDir = gravityDir;
        this.grounded = false;
        this.alive = true;
        this.shield = false;
        this.magnetT = 0;
        this.shieldNode.active = false;
        this.magnetAura.active = false;
        this.node.active = true;
        this.node.opacity = 255;
        this.node.scaleX = 1;
        this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
        this.node.angle = 0;
        this.setInvincible(1.5);
    };
    Player.prototype.setInvincible = function (seconds) {
        this.invincibleT = seconds;
        this.node.stopAllActions();
        cc.tween(this.node)
            .repeat(Math.ceil(seconds / 0.3), cc.tween().to(0.15, { opacity: 90 }).to(0.15, { opacity: 255 }))
            .start();
    };
    Player.prototype.flip = function () {
        if (!this.alive || !this.grounded)
            return;
        this.gravityDir *= -1;
        this.grounded = false;
        this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
        Sfx_1.default.play("flip", 0.8);
    };
    Player.prototype.applyPower = function (type) {
        if (type === "shield") {
            this.shield = true;
            this.shieldNode.active = true;
        }
        else if (type === "magnet") {
            this.magnetT = 6;
        }
        else if (type === "slow") {
            this.mgr.applySlow(4, 0.55);
        }
        Sfx_1.default.play("power", 0.9);
    };
    Player.prototype.update = function (rawDt) {
        if (!this.alive || !this.mgr || !this.mgr.isRunning())
            return;
        var dt = Math.min(rawDt, 1 / 30) * this.mgr.timeScale;
        if (this.invincibleT > 0)
            this.invincibleT -= rawDt;
        if (this.magnetT > 0)
            this.magnetT -= rawDt;
        var n = this.node;
        n.x += this.level.speed * dt;
        this.vy += this.gravityDir * GRAVITY * dt;
        this.vy = Math.max(-MAX_FALL, Math.min(MAX_FALL, this.vy));
        n.y += this.vy * dt;
        this.grounded = false;
        for (var _i = 0, _a = this.level.solids; _i < _a.length; _i++) {
            var r = _a[_i];
            var px = (BODY_W + r.w) / 2 - Math.abs(n.x - r.x);
            if (px <= 0)
                continue;
            var py = (BODY_H + r.h) / 2 - Math.abs(n.y - r.y);
            if (py <= 0)
                continue;
            if (py <= px) {
                // vertical resolve (land or head-bump)
                var dir = n.y >= r.y ? 1 : -1;
                n.y += dir * py;
                this.vy = 0;
                if (dir === -this.gravityDir)
                    this.grounded = true;
            }
            else {
                // horizontal resolve — running into a wall face is lethal
                var dirx = n.x >= r.x ? 1 : -1;
                n.x += dirx * px;
                if (dirx < 0 && px > 6) {
                    this.hit("wall");
                    if (!this.alive)
                        return;
                }
            }
        }
        // teleporters (one-way, exits are always forward so no re-trigger)
        for (var _b = 0, _c = this.level.teleports; _b < _c.length; _b++) {
            var t = _c[_b];
            if (Math.abs(n.x - t.x) < 40 && Math.abs(n.y - t.y) < 40) {
                n.setPosition(t.tx, t.ty);
                this.vy = 0;
                this.gravityDir = t.ty >= 0 ? 1 : -1;
                this.grounded = false;
                this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
                Sfx_1.default.play("teleport", 0.9);
                break;
            }
        }
        // fell/flew out of the corridor through a gap (shield can't save this)
        if (Math.abs(n.y) > 520) {
            this.die();
            return;
        }
        // spikes (slightly forgiving hitbox)
        for (var _d = 0, _e = this.level.spikes; _d < _e.length; _d++) {
            var s = _e[_d];
            if (this.overlaps(s, -8)) {
                this.hit("spike");
                if (!this.alive)
                    return;
                break;
            }
        }
        // patrol drones
        for (var _f = 0, _g = this.level.enemies; _f < _g.length; _f++) {
            var e = _g[_f];
            if (Math.abs(n.x - e.node.x) < 32 && Math.abs(n.y - e.node.y) < 32) {
                this.hit("enemy");
                if (!this.alive)
                    return;
                break;
            }
        }
        // crystals — the magnet visibly drags them toward the player
        this.magnetAura.active = this.magnetT > 0;
        for (var _h = 0, _j = this.level.crystals; _h < _j.length; _h++) {
            var c = _j[_h];
            if (c.taken)
                continue;
            if (this.magnetT > 0) {
                var ddx = c.node.x - n.x;
                var ddy = c.node.y - n.y;
                var d = Math.sqrt(ddx * ddx + ddy * ddy);
                if (d > 1 && d < 230) {
                    var m = Math.min(1, (900 * dt) / d);
                    c.node.x -= ddx * m;
                    c.node.y -= ddy * m;
                }
            }
            if (Math.abs(c.node.x - n.x) < 38 && Math.abs(c.node.y - n.y) < 38) {
                c.taken = true;
                c.node.active = false;
                this.mgr.onCrystal();
            }
        }
        // powerups
        for (var _k = 0, _l = this.level.powerups; _k < _l.length; _k++) {
            var p = _l[_k];
            if (!p.taken && Math.abs(n.x - p.x) < 36 && Math.abs(n.y - p.y) < 36) {
                p.taken = true;
                p.node.active = false;
                this.applyPower(p.type);
            }
        }
        // goal
        if (this.overlaps(this.level.goal, 0)) {
            this.alive = false;
            this.mgr.onWin();
        }
    };
    Player.prototype.overlaps = function (r, shrink) {
        var n = this.node;
        return Math.abs(n.x - r.x) < (BODY_W + shrink + r.w) / 2 &&
            Math.abs(n.y - r.y) < (BODY_H + shrink + r.h) / 2;
    };
    // Lethal contact that a shield / invincibility may absorb.
    // Shield only saves spike/enemy hits — a wall face stops you physically,
    // so surviving it would leave the runner stuck (worse than death).
    Player.prototype.hit = function (cause) {
        if (this.invincibleT > 0)
            return;
        if (this.shield && cause !== "wall") {
            this.shield = false;
            this.shieldNode.active = false;
            Sfx_1.default.play("shieldbreak", 0.9);
            this.setInvincible(1.2);
            return;
        }
        this.die();
    };
    Player.prototype.die = function () {
        var _this = this;
        if (!this.alive)
            return;
        this.alive = false;
        this.node.stopAllActions();
        cc.tween(this.node)
            .parallel(cc.tween().to(0.35, { scale: 2.2, opacity: 0 }), cc.tween().by(0.35, { angle: 180 }))
            .call(function () { _this.node.active = false; })
            .start();
        this.mgr.onDeath(this);
    };
    Player.prototype.getGravityDir = function () {
        return this.gravityDir;
    };
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(cc.Component));
exports.default = Player;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcUGxheWVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLDZCQUF3QjtBQUdoQixJQUFBLE9BQU8sR0FBSyxFQUFFLENBQUMsVUFBVSxRQUFsQixDQUFtQjtBQUVsQyxJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUM7QUFDckIsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDO0FBQ3RCLElBQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNsQixJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFFbEIsb0VBQW9FO0FBQ3BFLG9FQUFvRTtBQUNwRSwyREFBMkQ7QUFFM0Q7SUFBb0MsMEJBQVk7SUFBaEQ7UUFBQSxxRUFxUUM7UUFwUUcsV0FBSyxHQUFHLElBQUksQ0FBQztRQUNiLFdBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7UUFFcEIsU0FBRyxHQUFZLElBQUksQ0FBQztRQUNwQixXQUFLLEdBQWMsSUFBSSxDQUFDO1FBQ3hCLFFBQUUsR0FBRyxDQUFDLENBQUM7UUFDUCxnQkFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsNkNBQTZDO1FBQzlELGNBQVEsR0FBRyxLQUFLLENBQUM7UUFFekIsaUJBQWlCO1FBQ1QsWUFBTSxHQUFHLEtBQUssQ0FBQztRQUNmLGFBQU8sR0FBRyxDQUFDLENBQUM7UUFDWixpQkFBVyxHQUFHLENBQUMsQ0FBQztRQUVoQixnQkFBVSxHQUFZLElBQUksQ0FBQztRQUMzQixnQkFBVSxHQUFZLElBQUksQ0FBQzs7SUFxUHZDLENBQUM7SUFuUEcscUJBQUksR0FBSixVQUFLLEdBQVksRUFBRSxLQUFnQixFQUFFLEtBQWEsRUFBRSxNQUF1QztRQUN2RixJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ25CLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBRW5CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzFDLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNuRCxFQUFFLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNsQyxFQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztRQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFdkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDMUMsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ25ELEVBQUUsQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2hDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFeEMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ2pCLENBQUM7SUFFRCxzQkFBSyxHQUFMO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMzQix1REFBdUQ7UUFDdkQsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2hGLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ1osSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztRQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUNwQixJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUNqQixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQUVELHVEQUF1RDtJQUN2RCwwQkFBUyxHQUFULFVBQVUsQ0FBUyxFQUFFLENBQVMsRUFBRSxVQUFrQjtRQUM5QyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM1QixJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNaLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1FBQzdCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3BCLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ3BCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVELDhCQUFhLEdBQWIsVUFBYyxPQUFlO1FBQ3pCLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDM0IsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQyxFQUM1QixFQUFFLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQzthQUNuRSxLQUFLLEVBQUUsQ0FBQztJQUNqQixDQUFDO0lBRUQscUJBQUksR0FBSjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxPQUFPO1FBQzFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEQsYUFBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVELDJCQUFVLEdBQVYsVUFBVyxJQUFZO1FBQ25CLElBQUksSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7U0FDakM7YUFBTSxJQUFJLElBQUksS0FBSyxRQUFRLEVBQUU7WUFDMUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7U0FDcEI7YUFBTSxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDeEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBQ0QsYUFBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQUVELHVCQUFNLEdBQU4sVUFBTyxLQUFhO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFO1lBQUUsT0FBTztRQUM5RCxJQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDeEQsSUFBSSxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUM7WUFBRSxJQUFJLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQztRQUNwRCxJQUFJLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQztZQUFFLElBQUksQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDO1FBRTVDLElBQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDcEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxHQUFHLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDMUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzNELENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUM7UUFFcEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsS0FBZ0IsVUFBaUIsRUFBakIsS0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBakIsY0FBaUIsRUFBakIsSUFBaUIsRUFBRTtZQUE5QixJQUFNLENBQUMsU0FBQTtZQUNSLElBQU0sRUFBRSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNwRCxJQUFJLEVBQUUsSUFBSSxDQUFDO2dCQUFFLFNBQVM7WUFDdEIsSUFBTSxFQUFFLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BELElBQUksRUFBRSxJQUFJLENBQUM7Z0JBQUUsU0FBUztZQUV0QixJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUU7Z0JBQ1YsdUNBQXVDO2dCQUN2QyxJQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ1osSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVTtvQkFBRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQzthQUN0RDtpQkFBTTtnQkFDSCwwREFBMEQ7Z0JBQzFELElBQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUNqQixJQUFJLElBQUksR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsRUFBRTtvQkFDcEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO3dCQUFFLE9BQU87aUJBQzNCO2FBQ0o7U0FDSjtRQUVELG1FQUFtRTtRQUNuRSxLQUFnQixVQUFvQixFQUFwQixLQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFwQixjQUFvQixFQUFwQixJQUFvQixFQUFFO1lBQWpDLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDdEQsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ1osSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoRCxhQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDMUIsTUFBTTthQUNUO1NBQ0o7UUFFRCx1RUFBdUU7UUFDdkUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUU7WUFDckIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ1gsT0FBTztTQUNWO1FBRUQscUNBQXFDO1FBQ3JDLEtBQWdCLFVBQWlCLEVBQWpCLEtBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQWpCLGNBQWlCLEVBQWpCLElBQWlCLEVBQUU7WUFBOUIsSUFBTSxDQUFDLFNBQUE7WUFDUixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2xCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztvQkFBRSxPQUFPO2dCQUN4QixNQUFNO2FBQ1Q7U0FDSjtRQUVELGdCQUFnQjtRQUNoQixLQUFnQixVQUFrQixFQUFsQixLQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFsQixjQUFrQixFQUFsQixJQUFrQixFQUFFO1lBQS9CLElBQU0sQ0FBQyxTQUFBO1lBQ1IsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUNoRSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUs7b0JBQUUsT0FBTztnQkFDeEIsTUFBTTthQUNUO1NBQ0o7UUFFRCw2REFBNkQ7UUFDN0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDMUMsS0FBZ0IsVUFBbUIsRUFBbkIsS0FBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBbkIsY0FBbUIsRUFBbkIsSUFBbUIsRUFBRTtZQUFoQyxJQUFNLENBQUMsU0FBQTtZQUNSLElBQUksQ0FBQyxDQUFDLEtBQUs7Z0JBQUUsU0FBUztZQUN0QixJQUFJLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFO2dCQUNsQixJQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixJQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixJQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO2dCQUMzQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRTtvQkFDbEIsSUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3RDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7b0JBQ3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCO2FBQ0o7WUFDRCxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUU7Z0JBQ2hFLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztnQkFDdEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUN4QjtTQUNKO1FBRUQsV0FBVztRQUNYLEtBQWdCLFVBQW1CLEVBQW5CLEtBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQW5CLGNBQW1CLEVBQW5CLElBQW1CLEVBQUU7WUFBaEMsSUFBTSxDQUFDLFNBQUE7WUFDUixJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDbEUsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2dCQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMzQjtTQUNKO1FBRUQsT0FBTztRQUNQLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRTtZQUNuQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNuQixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3BCO0lBQ0wsQ0FBQztJQUVPLHlCQUFRLEdBQWhCLFVBQWlCLENBQVUsRUFBRSxNQUFjO1FBQ3ZDLElBQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDcEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztZQUNqRCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFRCwyREFBMkQ7SUFDM0QseUVBQXlFO0lBQ3pFLG1FQUFtRTtJQUMzRCxvQkFBRyxHQUFYLFVBQVksS0FBYTtRQUNyQixJQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQztZQUFFLE9BQU87UUFDakMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUU7WUFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFDcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQy9CLGFBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzdCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDeEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ2YsQ0FBQztJQUVPLG9CQUFHLEdBQVg7UUFBQSxpQkFZQztRQVhHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztZQUFFLE9BQU87UUFDeEIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMzQixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDZCxRQUFRLENBQ0wsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUMvQyxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUN0QzthQUNBLElBQUksQ0FBQyxjQUFRLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN6QyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFRCw4QkFBYSxHQUFiO1FBQ0ksT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQzNCLENBQUM7SUFwUWdCLE1BQU07UUFEMUIsT0FBTztPQUNhLE1BQU0sQ0FxUTFCO0lBQUQsYUFBQztDQXJRRCxBQXFRQyxDQXJRbUMsRUFBRSxDQUFDLFNBQVMsR0FxUS9DO2tCQXJRb0IsTUFBTSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExldmVsRGF0YSwgUmVjdERlZiB9IGZyb20gXCIuL0xldmVsQnVpbGRlclwiO1xuaW1wb3J0IFNmeCBmcm9tIFwiLi9TZnhcIjtcbmltcG9ydCBHYW1lTWdyIGZyb20gXCIuL0dhbWVNZ3JcIjtcblxuY29uc3QgeyBjY2NsYXNzIH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5jb25zdCBHUkFWSVRZID0gMjYwMDtcbmNvbnN0IE1BWF9GQUxMID0gMTAwMDtcbmNvbnN0IEJPRFlfVyA9IDMwO1xuY29uc3QgQk9EWV9IID0gMzQ7XG5cbi8vIEF1dG8tcnVubmVyIHdpdGggZmxpcHBhYmxlIGdyYXZpdHkuIFB1cmUga2luZW1hdGljIEFBQkIgcGh5c2ljcyDigJRcbi8vIG5vIHBoeXNpY3MgZW5naW5lLCBzbyBiZWhhdmlvciBpcyBkZXRlcm1pbmlzdGljIGFuZCBlYXN5IHRvIHR1bmUuXG4vLyBDcmVhdGVkIGFuZCBjb25maWd1cmVkIGF0IHJ1bnRpbWUgYnkgR2FtZU1nciB2aWEgaW5pdCgpLlxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFBsYXllciBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG4gICAgYWxpdmUgPSB0cnVlO1xuICAgIGluZGV4ID0gMDsgLy8gMCA9IFAxLCAxID0gUDJcblxuICAgIHByaXZhdGUgbWdyOiBHYW1lTWdyID0gbnVsbDtcbiAgICBwcml2YXRlIGxldmVsOiBMZXZlbERhdGEgPSBudWxsO1xuICAgIHByaXZhdGUgdnkgPSAwO1xuICAgIHByaXZhdGUgZ3Jhdml0eURpciA9IC0xOyAvLyAtMTogcHVsbHMgdG93YXJkIGZsb29yLCArMTogdG93YXJkIGNlaWxpbmdcbiAgICBwcml2YXRlIGdyb3VuZGVkID0gZmFsc2U7XG5cbiAgICAvLyBwb3dlci11cCBzdGF0ZVxuICAgIHByaXZhdGUgc2hpZWxkID0gZmFsc2U7XG4gICAgcHJpdmF0ZSBtYWduZXRUID0gMDtcbiAgICBwcml2YXRlIGludmluY2libGVUID0gMDtcblxuICAgIHByaXZhdGUgc2hpZWxkTm9kZTogY2MuTm9kZSA9IG51bGw7XG4gICAgcHJpdmF0ZSBtYWduZXRBdXJhOiBjYy5Ob2RlID0gbnVsbDtcblxuICAgIGluaXQobWdyOiBHYW1lTWdyLCBsZXZlbDogTGV2ZWxEYXRhLCBpbmRleDogbnVtYmVyLCBmcmFtZXM6IHsgW2s6IHN0cmluZ106IGNjLlNwcml0ZUZyYW1lIH0pIHtcbiAgICAgICAgdGhpcy5tZ3IgPSBtZ3I7XG4gICAgICAgIHRoaXMubGV2ZWwgPSBsZXZlbDtcbiAgICAgICAgdGhpcy5pbmRleCA9IGluZGV4O1xuXG4gICAgICAgIHRoaXMuc2hpZWxkTm9kZSA9IG5ldyBjYy5Ob2RlKFwic2hpZWxkRnhcIik7XG4gICAgICAgIGNvbnN0IHNwID0gdGhpcy5zaGllbGROb2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICBzcC5zcHJpdGVGcmFtZSA9IGZyYW1lc1tcInNoaWVsZFwiXTtcbiAgICAgICAgc3Auc2l6ZU1vZGUgPSBjYy5TcHJpdGUuU2l6ZU1vZGUuQ1VTVE9NO1xuICAgICAgICB0aGlzLnNoaWVsZE5vZGUuc2V0Q29udGVudFNpemUoNTQsIDU0KTtcbiAgICAgICAgdGhpcy5zaGllbGROb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQodGhpcy5zaGllbGROb2RlLCAxKTtcblxuICAgICAgICB0aGlzLm1hZ25ldEF1cmEgPSBuZXcgY2MuTm9kZShcIm1hZ25ldEZ4XCIpO1xuICAgICAgICBjb25zdCBtcyA9IHRoaXMubWFnbmV0QXVyYS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgbXMuc3ByaXRlRnJhbWUgPSBmcmFtZXNbXCJnbG93XCJdO1xuICAgICAgICBtcy5zaXplTW9kZSA9IGNjLlNwcml0ZS5TaXplTW9kZS5DVVNUT007XG4gICAgICAgIHRoaXMubWFnbmV0QXVyYS5zZXRDb250ZW50U2l6ZSgxMjAsIDEyMCk7XG4gICAgICAgIHRoaXMubWFnbmV0QXVyYS5jb2xvciA9IGNjLmNvbG9yKDI1NSwgMjMwLCAxMTApO1xuICAgICAgICB0aGlzLm1hZ25ldEF1cmEub3BhY2l0eSA9IDE1MDtcbiAgICAgICAgdGhpcy5tYWduZXRBdXJhLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQodGhpcy5tYWduZXRBdXJhLCAtMSk7XG5cbiAgICAgICAgdGhpcy5yZXNldCgpO1xuICAgIH1cblxuICAgIHJlc2V0KCkge1xuICAgICAgICB0aGlzLm5vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgLy8gUDIgdHJhaWxzIHNsaWdodGx5IGJlaGluZCBzbyB0aGUgY3ViZXMgZG9uJ3Qgb3ZlcmxhcFxuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24odGhpcy5sZXZlbC5zdGFydC54IC0gdGhpcy5pbmRleCAqIDYwLCB0aGlzLmxldmVsLnN0YXJ0LnkpO1xuICAgICAgICB0aGlzLnZ5ID0gMDtcbiAgICAgICAgdGhpcy5ncmF2aXR5RGlyID0gLTE7XG4gICAgICAgIHRoaXMuZ3JvdW5kZWQgPSB0cnVlO1xuICAgICAgICB0aGlzLmFsaXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zaGllbGQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tYWduZXRUID0gMDtcbiAgICAgICAgdGhpcy5pbnZpbmNpYmxlVCA9IDA7XG4gICAgICAgIHRoaXMuc2hpZWxkTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tYWduZXRBdXJhLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAyNTU7XG4gICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAxO1xuICAgICAgICB0aGlzLm5vZGUuc2NhbGVZID0gMTtcbiAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gMDtcbiAgICB9XG5cbiAgICAvLyBDby1vcCByZXZpdmU6IGRyb3AgaW4gbmV4dCB0byB0aGUgc3Vydml2aW5nIHBhcnRuZXIuXG4gICAgcmVzcGF3bkF0KHg6IG51bWJlciwgeTogbnVtYmVyLCBncmF2aXR5RGlyOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5ub2RlLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih4LCB5KTtcbiAgICAgICAgdGhpcy52eSA9IDA7XG4gICAgICAgIHRoaXMuZ3Jhdml0eURpciA9IGdyYXZpdHlEaXI7XG4gICAgICAgIHRoaXMuZ3JvdW5kZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5hbGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMuc2hpZWxkID0gZmFsc2U7XG4gICAgICAgIHRoaXMubWFnbmV0VCA9IDA7XG4gICAgICAgIHRoaXMuc2hpZWxkTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tYWduZXRBdXJhLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAyNTU7XG4gICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAxO1xuICAgICAgICB0aGlzLm5vZGUuc2NhbGVZID0gdGhpcy5ncmF2aXR5RGlyID4gMCA/IC0xIDogMTtcbiAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gMDtcbiAgICAgICAgdGhpcy5zZXRJbnZpbmNpYmxlKDEuNSk7XG4gICAgfVxuXG4gICAgc2V0SW52aW5jaWJsZShzZWNvbmRzOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5pbnZpbmNpYmxlVCA9IHNlY29uZHM7XG4gICAgICAgIHRoaXMubm9kZS5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICBjYy50d2Vlbih0aGlzLm5vZGUpXG4gICAgICAgICAgICAucmVwZWF0KE1hdGguY2VpbChzZWNvbmRzIC8gMC4zKSxcbiAgICAgICAgICAgICAgICBjYy50d2VlbigpLnRvKDAuMTUsIHsgb3BhY2l0eTogOTAgfSkudG8oMC4xNSwgeyBvcGFjaXR5OiAyNTUgfSkpXG4gICAgICAgICAgICAuc3RhcnQoKTtcbiAgICB9XG5cbiAgICBmbGlwKCkge1xuICAgICAgICBpZiAoIXRoaXMuYWxpdmUgfHwgIXRoaXMuZ3JvdW5kZWQpIHJldHVybjtcbiAgICAgICAgdGhpcy5ncmF2aXR5RGlyICo9IC0xO1xuICAgICAgICB0aGlzLmdyb3VuZGVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMubm9kZS5zY2FsZVkgPSB0aGlzLmdyYXZpdHlEaXIgPiAwID8gLTEgOiAxO1xuICAgICAgICBTZngucGxheShcImZsaXBcIiwgMC44KTtcbiAgICB9XG5cbiAgICBhcHBseVBvd2VyKHR5cGU6IHN0cmluZykge1xuICAgICAgICBpZiAodHlwZSA9PT0gXCJzaGllbGRcIikge1xuICAgICAgICAgICAgdGhpcy5zaGllbGQgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5zaGllbGROb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJtYWduZXRcIikge1xuICAgICAgICAgICAgdGhpcy5tYWduZXRUID0gNjtcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlID09PSBcInNsb3dcIikge1xuICAgICAgICAgICAgdGhpcy5tZ3IuYXBwbHlTbG93KDQsIDAuNTUpO1xuICAgICAgICB9XG4gICAgICAgIFNmeC5wbGF5KFwicG93ZXJcIiwgMC45KTtcbiAgICB9XG5cbiAgICB1cGRhdGUocmF3RHQ6IG51bWJlcikge1xuICAgICAgICBpZiAoIXRoaXMuYWxpdmUgfHwgIXRoaXMubWdyIHx8ICF0aGlzLm1nci5pc1J1bm5pbmcoKSkgcmV0dXJuO1xuICAgICAgICBjb25zdCBkdCA9IE1hdGgubWluKHJhd0R0LCAxIC8gMzApICogdGhpcy5tZ3IudGltZVNjYWxlO1xuICAgICAgICBpZiAodGhpcy5pbnZpbmNpYmxlVCA+IDApIHRoaXMuaW52aW5jaWJsZVQgLT0gcmF3RHQ7XG4gICAgICAgIGlmICh0aGlzLm1hZ25ldFQgPiAwKSB0aGlzLm1hZ25ldFQgLT0gcmF3RHQ7XG5cbiAgICAgICAgY29uc3QgbiA9IHRoaXMubm9kZTtcbiAgICAgICAgbi54ICs9IHRoaXMubGV2ZWwuc3BlZWQgKiBkdDtcbiAgICAgICAgdGhpcy52eSArPSB0aGlzLmdyYXZpdHlEaXIgKiBHUkFWSVRZICogZHQ7XG4gICAgICAgIHRoaXMudnkgPSBNYXRoLm1heCgtTUFYX0ZBTEwsIE1hdGgubWluKE1BWF9GQUxMLCB0aGlzLnZ5KSk7XG4gICAgICAgIG4ueSArPSB0aGlzLnZ5ICogZHQ7XG5cbiAgICAgICAgdGhpcy5ncm91bmRlZCA9IGZhbHNlO1xuICAgICAgICBmb3IgKGNvbnN0IHIgb2YgdGhpcy5sZXZlbC5zb2xpZHMpIHtcbiAgICAgICAgICAgIGNvbnN0IHB4ID0gKEJPRFlfVyArIHIudykgLyAyIC0gTWF0aC5hYnMobi54IC0gci54KTtcbiAgICAgICAgICAgIGlmIChweCA8PSAwKSBjb250aW51ZTtcbiAgICAgICAgICAgIGNvbnN0IHB5ID0gKEJPRFlfSCArIHIuaCkgLyAyIC0gTWF0aC5hYnMobi55IC0gci55KTtcbiAgICAgICAgICAgIGlmIChweSA8PSAwKSBjb250aW51ZTtcblxuICAgICAgICAgICAgaWYgKHB5IDw9IHB4KSB7XG4gICAgICAgICAgICAgICAgLy8gdmVydGljYWwgcmVzb2x2ZSAobGFuZCBvciBoZWFkLWJ1bXApXG4gICAgICAgICAgICAgICAgY29uc3QgZGlyID0gbi55ID49IHIueSA/IDEgOiAtMTtcbiAgICAgICAgICAgICAgICBuLnkgKz0gZGlyICogcHk7XG4gICAgICAgICAgICAgICAgdGhpcy52eSA9IDA7XG4gICAgICAgICAgICAgICAgaWYgKGRpciA9PT0gLXRoaXMuZ3Jhdml0eURpcikgdGhpcy5ncm91bmRlZCA9IHRydWU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIGhvcml6b250YWwgcmVzb2x2ZSDigJQgcnVubmluZyBpbnRvIGEgd2FsbCBmYWNlIGlzIGxldGhhbFxuICAgICAgICAgICAgICAgIGNvbnN0IGRpcnggPSBuLnggPj0gci54ID8gMSA6IC0xO1xuICAgICAgICAgICAgICAgIG4ueCArPSBkaXJ4ICogcHg7XG4gICAgICAgICAgICAgICAgaWYgKGRpcnggPCAwICYmIHB4ID4gNikge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmhpdChcIndhbGxcIik7XG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5hbGl2ZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHRlbGVwb3J0ZXJzIChvbmUtd2F5LCBleGl0cyBhcmUgYWx3YXlzIGZvcndhcmQgc28gbm8gcmUtdHJpZ2dlcilcbiAgICAgICAgZm9yIChjb25zdCB0IG9mIHRoaXMubGV2ZWwudGVsZXBvcnRzKSB7XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMobi54IC0gdC54KSA8IDQwICYmIE1hdGguYWJzKG4ueSAtIHQueSkgPCA0MCkge1xuICAgICAgICAgICAgICAgIG4uc2V0UG9zaXRpb24odC50eCwgdC50eSk7XG4gICAgICAgICAgICAgICAgdGhpcy52eSA9IDA7XG4gICAgICAgICAgICAgICAgdGhpcy5ncmF2aXR5RGlyID0gdC50eSA+PSAwID8gMSA6IC0xO1xuICAgICAgICAgICAgICAgIHRoaXMuZ3JvdW5kZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuc2NhbGVZID0gdGhpcy5ncmF2aXR5RGlyID4gMCA/IC0xIDogMTtcbiAgICAgICAgICAgICAgICBTZngucGxheShcInRlbGVwb3J0XCIsIDAuOSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBmZWxsL2ZsZXcgb3V0IG9mIHRoZSBjb3JyaWRvciB0aHJvdWdoIGEgZ2FwIChzaGllbGQgY2FuJ3Qgc2F2ZSB0aGlzKVxuICAgICAgICBpZiAoTWF0aC5hYnMobi55KSA+IDUyMCkge1xuICAgICAgICAgICAgdGhpcy5kaWUoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHNwaWtlcyAoc2xpZ2h0bHkgZm9yZ2l2aW5nIGhpdGJveClcbiAgICAgICAgZm9yIChjb25zdCBzIG9mIHRoaXMubGV2ZWwuc3Bpa2VzKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5vdmVybGFwcyhzLCAtOCkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmhpdChcInNwaWtlXCIpO1xuICAgICAgICAgICAgICAgIGlmICghdGhpcy5hbGl2ZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gcGF0cm9sIGRyb25lc1xuICAgICAgICBmb3IgKGNvbnN0IGUgb2YgdGhpcy5sZXZlbC5lbmVtaWVzKSB7XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMobi54IC0gZS5ub2RlLngpIDwgMzIgJiYgTWF0aC5hYnMobi55IC0gZS5ub2RlLnkpIDwgMzIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmhpdChcImVuZW15XCIpO1xuICAgICAgICAgICAgICAgIGlmICghdGhpcy5hbGl2ZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gY3J5c3RhbHMg4oCUIHRoZSBtYWduZXQgdmlzaWJseSBkcmFncyB0aGVtIHRvd2FyZCB0aGUgcGxheWVyXG4gICAgICAgIHRoaXMubWFnbmV0QXVyYS5hY3RpdmUgPSB0aGlzLm1hZ25ldFQgPiAwO1xuICAgICAgICBmb3IgKGNvbnN0IGMgb2YgdGhpcy5sZXZlbC5jcnlzdGFscykge1xuICAgICAgICAgICAgaWYgKGMudGFrZW4pIGNvbnRpbnVlO1xuICAgICAgICAgICAgaWYgKHRoaXMubWFnbmV0VCA+IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkZHggPSBjLm5vZGUueCAtIG4ueDtcbiAgICAgICAgICAgICAgICBjb25zdCBkZHkgPSBjLm5vZGUueSAtIG4ueTtcbiAgICAgICAgICAgICAgICBjb25zdCBkID0gTWF0aC5zcXJ0KGRkeCAqIGRkeCArIGRkeSAqIGRkeSk7XG4gICAgICAgICAgICAgICAgaWYgKGQgPiAxICYmIGQgPCAyMzApIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbSA9IE1hdGgubWluKDEsICg5MDAgKiBkdCkgLyBkKTtcbiAgICAgICAgICAgICAgICAgICAgYy5ub2RlLnggLT0gZGR4ICogbTtcbiAgICAgICAgICAgICAgICAgICAgYy5ub2RlLnkgLT0gZGR5ICogbTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMoYy5ub2RlLnggLSBuLngpIDwgMzggJiYgTWF0aC5hYnMoYy5ub2RlLnkgLSBuLnkpIDwgMzgpIHtcbiAgICAgICAgICAgICAgICBjLnRha2VuID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBjLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5tZ3Iub25DcnlzdGFsKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBwb3dlcnVwc1xuICAgICAgICBmb3IgKGNvbnN0IHAgb2YgdGhpcy5sZXZlbC5wb3dlcnVwcykge1xuICAgICAgICAgICAgaWYgKCFwLnRha2VuICYmIE1hdGguYWJzKG4ueCAtIHAueCkgPCAzNiAmJiBNYXRoLmFicyhuLnkgLSBwLnkpIDwgMzYpIHtcbiAgICAgICAgICAgICAgICBwLnRha2VuID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBwLm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5hcHBseVBvd2VyKHAudHlwZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBnb2FsXG4gICAgICAgIGlmICh0aGlzLm92ZXJsYXBzKHRoaXMubGV2ZWwuZ29hbCwgMCkpIHtcbiAgICAgICAgICAgIHRoaXMuYWxpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMubWdyLm9uV2luKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIG92ZXJsYXBzKHI6IFJlY3REZWYsIHNocmluazogbnVtYmVyKTogYm9vbGVhbiB7XG4gICAgICAgIGNvbnN0IG4gPSB0aGlzLm5vZGU7XG4gICAgICAgIHJldHVybiBNYXRoLmFicyhuLnggLSByLngpIDwgKEJPRFlfVyArIHNocmluayArIHIudykgLyAyICYmXG4gICAgICAgICAgICAgICBNYXRoLmFicyhuLnkgLSByLnkpIDwgKEJPRFlfSCArIHNocmluayArIHIuaCkgLyAyO1xuICAgIH1cblxuICAgIC8vIExldGhhbCBjb250YWN0IHRoYXQgYSBzaGllbGQgLyBpbnZpbmNpYmlsaXR5IG1heSBhYnNvcmIuXG4gICAgLy8gU2hpZWxkIG9ubHkgc2F2ZXMgc3Bpa2UvZW5lbXkgaGl0cyDigJQgYSB3YWxsIGZhY2Ugc3RvcHMgeW91IHBoeXNpY2FsbHksXG4gICAgLy8gc28gc3Vydml2aW5nIGl0IHdvdWxkIGxlYXZlIHRoZSBydW5uZXIgc3R1Y2sgKHdvcnNlIHRoYW4gZGVhdGgpLlxuICAgIHByaXZhdGUgaGl0KGNhdXNlOiBzdHJpbmcpIHtcbiAgICAgICAgaWYgKHRoaXMuaW52aW5jaWJsZVQgPiAwKSByZXR1cm47XG4gICAgICAgIGlmICh0aGlzLnNoaWVsZCAmJiBjYXVzZSAhPT0gXCJ3YWxsXCIpIHtcbiAgICAgICAgICAgIHRoaXMuc2hpZWxkID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLnNoaWVsZE5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICBTZngucGxheShcInNoaWVsZGJyZWFrXCIsIDAuOSk7XG4gICAgICAgICAgICB0aGlzLnNldEludmluY2libGUoMS4yKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmRpZSgpO1xuICAgIH1cblxuICAgIHByaXZhdGUgZGllKCkge1xuICAgICAgICBpZiAoIXRoaXMuYWxpdmUpIHJldHVybjtcbiAgICAgICAgdGhpcy5hbGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgY2MudHdlZW4odGhpcy5ub2RlKVxuICAgICAgICAgICAgLnBhcmFsbGVsKFxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKCkudG8oMC4zNSwgeyBzY2FsZTogMi4yLCBvcGFjaXR5OiAwIH0pLFxuICAgICAgICAgICAgICAgIGNjLnR3ZWVuKCkuYnkoMC4zNSwgeyBhbmdsZTogMTgwIH0pXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuY2FsbCgoKSA9PiB7IHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTsgfSlcbiAgICAgICAgICAgIC5zdGFydCgpO1xuICAgICAgICB0aGlzLm1nci5vbkRlYXRoKHRoaXMpO1xuICAgIH1cblxuICAgIGdldEdyYXZpdHlEaXIoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ3Jhdml0eURpcjtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------
