"use strict";
cc._RF.push(module, 'd321bCHWN5HsYuFcKvZ02bl', 'Player');
// scripts/Player.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Sfx_1 = require("./Sfx");
var ccclass = cc._decorator.ccclass;
var GRAVITY = 2600;
var MAX_FALL = 1000;
var BODY_W = 30;
var BODY_H = 34;
// Auto-runner with flippable gravity. Pure kinematic AABB physics —
// no physics engine, so behavior is deterministic and easy to tune.
// Created and configured at runtime by GameMgr via init().
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.alive = true;
        _this.index = 0; // 0 = P1, 1 = P2
        _this.mgr = null;
        _this.level = null;
        _this.vy = 0;
        _this.gravityDir = -1; // -1: pulls toward floor, +1: toward ceiling
        _this.grounded = false;
        // power-up state
        _this.shield = false;
        _this.magnetT = 0;
        _this.invincibleT = 0;
        _this.shieldNode = null;
        _this.magnetAura = null;
        return _this;
    }
    Player.prototype.init = function (mgr, level, index, frames) {
        this.mgr = mgr;
        this.level = level;
        this.index = index;
        this.shieldNode = new cc.Node("shieldFx");
        var sp = this.shieldNode.addComponent(cc.Sprite);
        sp.spriteFrame = frames["shield"];
        sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.shieldNode.setContentSize(54, 54);
        this.shieldNode.active = false;
        this.node.addChild(this.shieldNode, 1);
        this.magnetAura = new cc.Node("magnetFx");
        var ms = this.magnetAura.addComponent(cc.Sprite);
        ms.spriteFrame = frames["glow"];
        ms.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.magnetAura.setContentSize(120, 120);
        this.magnetAura.color = cc.color(255, 230, 110);
        this.magnetAura.opacity = 150;
        this.magnetAura.active = false;
        this.node.addChild(this.magnetAura, -1);
        this.reset();
    };
    Player.prototype.reset = function () {
        this.node.stopAllActions();
        // P2 trails slightly behind so the cubes don't overlap
        this.node.setPosition(this.level.start.x - this.index * 60, this.level.start.y);
        this.vy = 0;
        this.gravityDir = -1;
        this.grounded = true;
        this.alive = true;
        this.shield = false;
        this.magnetT = 0;
        this.invincibleT = 0;
        this.shieldNode.active = false;
        this.magnetAura.active = false;
        this.node.active = true;
        this.node.opacity = 255;
        this.node.scaleX = 1;
        this.node.scaleY = 1;
        this.node.angle = 0;
    };
    // Co-op revive: drop in next to the surviving partner.
    Player.prototype.respawnAt = function (x, y, gravityDir) {
        this.node.stopAllActions();
        this.node.setPosition(x, y);
        this.vy = 0;
        this.gravityDir = gravityDir;
        this.grounded = false;
        this.alive = true;
        this.shield = false;
        this.magnetT = 0;
        this.shieldNode.active = false;
        this.magnetAura.active = false;
        this.node.active = true;
        this.node.opacity = 255;
        this.node.scaleX = 1;
        this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
        this.node.angle = 0;
        this.setInvincible(1.5);
    };
    Player.prototype.setInvincible = function (seconds) {
        this.invincibleT = seconds;
        this.node.stopAllActions();
        cc.tween(this.node)
            .repeat(Math.ceil(seconds / 0.3), cc.tween().to(0.15, { opacity: 90 }).to(0.15, { opacity: 255 }))
            .start();
    };
    Player.prototype.flip = function () {
        if (!this.alive || !this.grounded)
            return;
        this.gravityDir *= -1;
        this.grounded = false;
        this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
        Sfx_1.default.play("flip", 0.8);
    };
    Player.prototype.applyPower = function (type) {
        if (type === "shield") {
            this.shield = true;
            this.shieldNode.active = true;
        }
        else if (type === "magnet") {
            this.magnetT = 6;
        }
        else if (type === "slow") {
            this.mgr.applySlow(4, 0.55);
        }
        Sfx_1.default.play("power", 0.9);
    };
    Player.prototype.update = function (rawDt) {
        if (!this.alive || !this.mgr || !this.mgr.isRunning())
            return;
        var dt = Math.min(rawDt, 1 / 30) * this.mgr.timeScale;
        if (this.invincibleT > 0)
            this.invincibleT -= rawDt;
        if (this.magnetT > 0)
            this.magnetT -= rawDt;
        var n = this.node;
        n.x += this.level.speed * dt;
        this.vy += this.gravityDir * GRAVITY * dt;
        this.vy = Math.max(-MAX_FALL, Math.min(MAX_FALL, this.vy));
        n.y += this.vy * dt;
        this.grounded = false;
        for (var _i = 0, _a = this.level.solids; _i < _a.length; _i++) {
            var r = _a[_i];
            var px = (BODY_W + r.w) / 2 - Math.abs(n.x - r.x);
            if (px <= 0)
                continue;
            var py = (BODY_H + r.h) / 2 - Math.abs(n.y - r.y);
            if (py <= 0)
                continue;
            if (py <= px) {
                // vertical resolve (land or head-bump)
                var dir = n.y >= r.y ? 1 : -1;
                n.y += dir * py;
                this.vy = 0;
                if (dir === -this.gravityDir)
                    this.grounded = true;
            }
            else {
                // horizontal resolve — running into a wall face is lethal
                var dirx = n.x >= r.x ? 1 : -1;
                n.x += dirx * px;
                if (dirx < 0 && px > 6) {
                    this.hit("wall");
                    if (!this.alive)
                        return;
                }
            }
        }
        // teleporters (one-way, exits are always forward so no re-trigger)
        for (var _b = 0, _c = this.level.teleports; _b < _c.length; _b++) {
            var t = _c[_b];
            if (Math.abs(n.x - t.x) < 40 && Math.abs(n.y - t.y) < 40) {
                n.setPosition(t.tx, t.ty);
                this.vy = 0;
                this.gravityDir = t.ty >= 0 ? 1 : -1;
                this.grounded = false;
                this.node.scaleY = this.gravityDir > 0 ? -1 : 1;
                Sfx_1.default.play("teleport", 0.9);
                break;
            }
        }
        // fell/flew out of the corridor through a gap (shield can't save this)
        if (Math.abs(n.y) > 520) {
            this.die();
            return;
        }
        // spikes (slightly forgiving hitbox)
        for (var _d = 0, _e = this.level.spikes; _d < _e.length; _d++) {
            var s = _e[_d];
            if (this.overlaps(s, -8)) {
                this.hit("spike");
                if (!this.alive)
                    return;
                break;
            }
        }
        // patrol drones
        for (var _f = 0, _g = this.level.enemies; _f < _g.length; _f++) {
            var e = _g[_f];
            if (Math.abs(n.x - e.node.x) < 32 && Math.abs(n.y - e.node.y) < 32) {
                this.hit("enemy");
                if (!this.alive)
                    return;
                break;
            }
        }
        // crystals — the magnet visibly drags them toward the player
        this.magnetAura.active = this.magnetT > 0;
        for (var _h = 0, _j = this.level.crystals; _h < _j.length; _h++) {
            var c = _j[_h];
            if (c.taken)
                continue;
            if (this.magnetT > 0) {
                var ddx = c.node.x - n.x;
                var ddy = c.node.y - n.y;
                var d = Math.sqrt(ddx * ddx + ddy * ddy);
                if (d > 1 && d < 230) {
                    var m = Math.min(1, (900 * dt) / d);
                    c.node.x -= ddx * m;
                    c.node.y -= ddy * m;
                }
            }
            if (Math.abs(c.node.x - n.x) < 38 && Math.abs(c.node.y - n.y) < 38) {
                c.taken = true;
                c.node.active = false;
                this.mgr.onCrystal();
            }
        }
        // powerups
        for (var _k = 0, _l = this.level.powerups; _k < _l.length; _k++) {
            var p = _l[_k];
            if (!p.taken && Math.abs(n.x - p.x) < 36 && Math.abs(n.y - p.y) < 36) {
                p.taken = true;
                p.node.active = false;
                this.applyPower(p.type);
            }
        }
        // goal
        if (this.overlaps(this.level.goal, 0)) {
            this.alive = false;
            this.mgr.onWin();
        }
    };
    Player.prototype.overlaps = function (r, shrink) {
        var n = this.node;
        return Math.abs(n.x - r.x) < (BODY_W + shrink + r.w) / 2 &&
            Math.abs(n.y - r.y) < (BODY_H + shrink + r.h) / 2;
    };
    // Lethal contact that a shield / invincibility may absorb.
    // Shield only saves spike/enemy hits — a wall face stops you physically,
    // so surviving it would leave the runner stuck (worse than death).
    Player.prototype.hit = function (cause) {
        if (this.invincibleT > 0)
            return;
        if (this.shield && cause !== "wall") {
            this.shield = false;
            this.shieldNode.active = false;
            Sfx_1.default.play("shieldbreak", 0.9);
            this.setInvincible(1.2);
            return;
        }
        this.die();
    };
    Player.prototype.die = function () {
        var _this = this;
        if (!this.alive)
            return;
        this.alive = false;
        this.node.stopAllActions();
        cc.tween(this.node)
            .parallel(cc.tween().to(0.35, { scale: 2.2, opacity: 0 }), cc.tween().by(0.35, { angle: 180 }))
            .call(function () { _this.node.active = false; })
            .start();
        this.mgr.onDeath(this);
    };
    Player.prototype.getGravityDir = function () {
        return this.gravityDir;
    };
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(cc.Component));
exports.default = Player;

cc._RF.pop();