"use strict";
cc._RF.push(module, 'a1fddKPDD9HmrL1HaGWmp/l', 'Sfx');
// scripts/Sfx.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameData_1 = require("./GameData");
// Tiny audio helper. Clips live in assets/resources/audio/<name>.wav (or .mp3).
// All volumes are scaled by the user's settings (GameData.settings).
var Sfx = /** @class */ (function () {
    function Sfx() {
    }
    Sfx.preload = function () {
        var names = ["flip", "crystal", "death", "win", "click", "power", "teleport", "shieldbreak"];
        var _loop_1 = function (n) {
            if (Sfx.clips[n])
                return "continue";
            cc.resources.load("audio/" + n, cc.AudioClip, function (err, clip) {
                if (!err && clip)
                    Sfx.clips[n] = clip;
            });
        };
        for (var _i = 0, names_1 = names; _i < names_1.length; _i++) {
            var n = names_1[_i];
            _loop_1(n);
        }
    };
    Sfx.play = function (name, volume) {
        if (volume === void 0) { volume = 1; }
        var clip = Sfx.clips[name];
        var v = volume * GameData_1.default.settings.sfx;
        if (clip && v > 0)
            cc.audioEngine.play(clip, false, v);
    };
    // BGM is optional: drop a file at resources/audio/bgm.mp3 and this picks it up.
    Sfx.playBgm = function () {
        if (Sfx.bgmId >= 0) {
            Sfx.applyBgmVolume();
            return;
        }
        cc.resources.load("audio/bgm", cc.AudioClip, function (err, clip) {
            if (!err && clip && Sfx.bgmId < 0) {
                Sfx.bgmId = cc.audioEngine.play(clip, true, GameData_1.default.settings.bgm);
            }
        });
    };
    Sfx.applyBgmVolume = function () {
        if (Sfx.bgmId >= 0)
            cc.audioEngine.setVolume(Sfx.bgmId, GameData_1.default.settings.bgm);
    };
    Sfx.stopBgm = function () {
        if (Sfx.bgmId >= 0) {
            cc.audioEngine.stop(Sfx.bgmId);
            Sfx.bgmId = -1;
        }
    };
    Sfx.clips = {};
    Sfx.bgmId = -1;
    return Sfx;
}());
exports.default = Sfx;

cc._RF.pop();