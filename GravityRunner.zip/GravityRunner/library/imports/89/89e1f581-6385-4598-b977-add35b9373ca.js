"use strict";
cc._RF.push(module, '89e1fWBY4VFmLl3rdNbk3PK', 'GameData');
// scripts/GameData.ts

"use strict";
// Global game state shared across scenes (plain module, not a component).
Object.defineProperty(exports, "__esModule", { value: true });
var GameData = /** @class */ (function () {
    function GameData() {
    }
    GameData.getUnlocked = function () {
        var raw = cc.sys.localStorage.getItem(GameData.KEY);
        var v = parseInt(raw || "1", 10);
        if (isNaN(v) || v < 1)
            return 1;
        return Math.min(v, GameData.MAX_LEVEL);
    };
    GameData.unlockNext = function (clearedLevel) {
        var next = Math.min(clearedLevel + 1, GameData.MAX_LEVEL);
        if (next > GameData.getUnlocked()) {
            cc.sys.localStorage.setItem(GameData.KEY, String(next));
        }
    };
    GameData.loadSettings = function () {
        var def = { sfx: 1, bgm: 0.6, speed: 1, scheme: 0, brightness: 1 };
        try {
            var raw = cc.sys.localStorage.getItem(GameData.SETTINGS_KEY);
            if (raw) {
                var s = JSON.parse(raw);
                for (var k in def) {
                    if (typeof s[k] === "number")
                        def[k] = s[k];
                }
            }
        }
        catch (e) { /* corrupted settings -> defaults */ }
        return def;
    };
    GameData.saveSettings = function () {
        cc.sys.localStorage.setItem(GameData.SETTINGS_KEY, JSON.stringify(GameData.settings));
    };
    GameData.MAX_LEVEL = 3;
    // Which level the Game scene should load.
    GameData.currentLevel = 1;
    // 1 = solo, 2 = local co-op (P1=W, P2=UP/SPACE).
    GameData.players = 1;
    GameData.settings = GameData.loadSettings();
    GameData.KEY = "gfr_unlocked";
    GameData.SETTINGS_KEY = "gfr_settings";
    return GameData;
}());
exports.default = GameData;

cc._RF.pop();