"use strict";
cc._RF.push(module, '36f6bzcenBCwpmegGFN63R7', 'MenuCtrl');
// scripts/MenuCtrl.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GameData_1 = require("./GameData");
var LevelBuilder_1 = require("./LevelBuilder");
var Sfx_1 = require("./Sfx");
var ccclass = cc._decorator.ccclass;
// Main menu — built entirely in code (the .fire scene only has Canvas + Camera).
// Mode select (1P / 2P), level buttons, and a settings overlay
// (sfx/bgm volume, game speed, color scheme, brightness).
var MenuCtrl = /** @class */ (function (_super) {
    __extends(MenuCtrl, _super);
    function MenuCtrl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.frames = {};
        _this.bgNode = null;
        _this.modeButtons = [];
        _this.hintLabel = null;
        _this.settingsPanel = null;
        return _this;
    }
    MenuCtrl.prototype.onLoad = function () {
        var _this = this;
        Sfx_1.default.preload();
        Sfx_1.default.playBgm();
        cc.resources.loadDir("textures", cc.SpriteFrame, function (err, assets) {
            if (err) {
                cc.error("texture load failed", err);
                return;
            }
            for (var _i = 0, assets_1 = assets; _i < assets_1.length; _i++) {
                var a = assets_1[_i];
                _this.frames[a.name] = a;
            }
            _this.buildUi();
        });
        cc.director.preloadScene("Game");
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    };
    MenuCtrl.prototype.onDestroy = function () {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    };
    MenuCtrl.prototype.sprite = function (parent, frame, x, y, w, h, color) {
        var n = new cc.Node(frame);
        var sp = n.addComponent(cc.Sprite);
        sp.spriteFrame = this.frames[frame];
        sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        n.setContentSize(w, h);
        n.setPosition(x, y);
        if (color)
            n.color = color;
        parent.addChild(n);
        return n;
    };
    MenuCtrl.prototype.label = function (parent, text, x, y, size, color, anchorX) {
        if (anchorX === void 0) { anchorX = 0.5; }
        var n = new cc.Node("label");
        n.setPosition(x, y);
        n.anchorX = anchorX;
        n.color = color;
        var lb = n.addComponent(cc.Label);
        lb.string = text;
        lb.fontSize = size;
        lb.lineHeight = size + 6;
        parent.addChild(n);
        return n;
    };
    MenuCtrl.prototype.applyBgTint = function () {
        if (!this.bgNode)
            return;
        var b = GameData_1.default.settings.brightness;
        var t = LevelBuilder_1.default.scheme().bgTint;
        this.bgNode.color = cc.color(Math.round(t.r * b), Math.round(t.g * b), Math.round(t.b * b));
    };
    MenuCtrl.prototype.buildUi = function () {
        var _this = this;
        var cyan = cc.color(127, 247, 255);
        var orange = cc.color(255, 181, 74);
        var white = cc.color(235, 240, 255);
        var dim = cc.color(110, 120, 150);
        this.bgNode = this.sprite(this.node, "bg", 0, 0, 970, 650);
        this.applyBgTint();
        // title
        var title = this.label(this.node, "GRAVITY FLIP RUNNER", 0, 230, 56, cyan);
        cc.tween(title)
            .to(1.4, { opacity: 170 }, { easing: "sineInOut" })
            .to(1.4, { opacity: 255 }, { easing: "sineInOut" })
            .repeatForever()
            .start();
        this.label(this.node, "— ESCAPE ASTRA-9 —", 0, 178, 18, orange);
        // decorations
        var deco = this.sprite(this.node, "player", -340, 60, 48, 48);
        cc.tween(deco)
            .to(1.2, { y: 85 }, { easing: "sineInOut" })
            .to(1.2, { y: 60 }, { easing: "sineInOut" })
            .repeatForever()
            .start();
        var deco2 = this.sprite(this.node, "player2", -340, -40, 40, 40);
        deco2.scaleY = -1;
        cc.tween(deco2)
            .to(1.5, { y: -65 }, { easing: "sineInOut" })
            .to(1.5, { y: -40 }, { easing: "sineInOut" })
            .repeatForever()
            .start();
        var c1 = this.sprite(this.node, "crystal", 340, 20, 30, 30);
        cc.tween(c1).by(2.4, { angle: 360 }).repeatForever().start();
        // mode select: 1P / 2P
        this.modeButtons = [];
        var _loop_1 = function (m) {
            var x = m === 1 ? -75 : 75;
            var btn = this_1.sprite(this_1.node, "white", x, 118, 130, 44, cc.color(24, 34, 76));
            this_1.label(btn, m === 1 ? "1 PLAYER" : "2 PLAYERS", 0, 0, 18, white);
            btn.on(cc.Node.EventType.TOUCH_END, function () {
                Sfx_1.default.play("click", 0.8);
                GameData_1.default.players = m;
                _this.refreshModeButtons();
            });
            this_1.modeButtons.push(btn);
        };
        var this_1 = this;
        for (var m = 1; m <= 2; m++) {
            _loop_1(m);
        }
        this.refreshModeButtons();
        // level buttons
        var unlocked = GameData_1.default.getUnlocked();
        var _loop_2 = function (i) {
            var open = i <= unlocked;
            var y = 50 - i * 72;
            var btn = this_2.sprite(this_2.node, "white", 0, y, 260, 56, open ? cc.color(24, 34, 76) : cc.color(22, 24, 34));
            this_2.sprite(this_2.node, "white", 0, y - 26, 260, 3, open ? cyan : dim);
            this_2.label(btn, open ? "LEVEL " + i : "LEVEL " + i + "  [LOCKED]", 0, 0, 24, open ? white : dim);
            if (open) {
                btn.on(cc.Node.EventType.TOUCH_END, function () {
                    Sfx_1.default.play("click", 0.8);
                    GameData_1.default.currentLevel = i;
                    cc.director.loadScene("Game");
                });
            }
        };
        var this_2 = this;
        for (var i = 1; i <= GameData_1.default.MAX_LEVEL; i++) {
            _loop_2(i);
        }
        // settings button
        var sBtn = this.sprite(this.node, "white", 0, -226, 200, 44, cc.color(40, 30, 70));
        this.label(sBtn, "SETTINGS", 0, 0, 20, orange);
        sBtn.on(cc.Node.EventType.TOUCH_END, function () {
            Sfx_1.default.play("click", 0.8);
            _this.toggleSettings();
        });
        this.hintLabel = this.label(this.node, "SPACE / W / UP : FLIP      R : RESTART      ESC : PAUSE      [SPACE = QUICK START]", 0, -286, 15, dim);
    };
    MenuCtrl.prototype.refreshModeButtons = function () {
        var sel = cc.color(53, 100, 150);
        var norm = cc.color(24, 34, 76);
        for (var m = 0; m < 2; m++) {
            this.modeButtons[m].color = GameData_1.default.players === m + 1 ? sel : norm;
        }
        if (this.hintLabel) {
            var lb = this.hintLabel.getComponent(cc.Label);
            lb.string = GameData_1.default.players === 2
                ? "P1 : W = FLIP      P2 : UP / SPACE = FLIP      R : RESTART      ESC : PAUSE"
                : "SPACE / W / UP : FLIP      R : RESTART      ESC : PAUSE      [SPACE = QUICK START]";
        }
    };
    // ---------- settings panel ----------
    MenuCtrl.prototype.toggleSettings = function () {
        if (this.settingsPanel) {
            this.settingsPanel.destroy();
            this.settingsPanel = null;
            return;
        }
        this.buildSettingsPanel();
    };
    MenuCtrl.prototype.buildSettingsPanel = function () {
        var _this = this;
        var white = cc.color(235, 240, 255);
        var cyan = cc.color(127, 247, 255);
        var orange = cc.color(255, 181, 74);
        var panel = this.sprite(this.node, "white", 0, 0, 560, 460, cc.color(10, 12, 26));
        panel.opacity = 245;
        panel.zIndex = 50;
        this.settingsPanel = panel;
        // swallow clicks behind the panel
        panel.on(cc.Node.EventType.TOUCH_START, function (e) { e.stopPropagation(); });
        this.label(panel, "SETTINGS", 0, 190, 30, orange);
        this.label(panel, "click a row to change", 0, 158, 14, cc.color(110, 120, 150));
        var s = GameData_1.default.settings;
        var pct = function (v) { return Math.round(v * 100) + "%"; };
        var rows = [
            {
                name: "SFX VOLUME",
                value: function () { return pct(s.sfx); },
                next: function () { s.sfx = s.sfx >= 1 ? 0 : Math.min(1, s.sfx + 0.25); Sfx_1.default.play("crystal", 0.8); }
            },
            {
                name: "MUSIC VOLUME",
                value: function () { return pct(s.bgm); },
                next: function () { s.bgm = s.bgm >= 1 ? 0 : Math.min(1, s.bgm + 0.2); Sfx_1.default.applyBgmVolume(); }
            },
            {
                name: "GAME SPEED",
                value: function () { return pct(s.speed); },
                next: function () { s.speed = s.speed >= 1.2 ? 0.8 : Math.round((s.speed + 0.2) * 10) / 10; }
            },
            {
                name: "COLOR SCHEME",
                value: function () { return LevelBuilder_1.SCHEMES[s.scheme].name; },
                next: function () { s.scheme = (s.scheme + 1) % LevelBuilder_1.SCHEMES.length; _this.applyBgTint(); }
            },
            {
                name: "BRIGHTNESS",
                value: function () { return pct(s.brightness); },
                next: function () { s.brightness = s.brightness <= 0.6 ? 1 : Math.round((s.brightness - 0.2) * 10) / 10; _this.applyBgTint(); }
            }
        ];
        var _loop_3 = function (i) {
            var row = rows[i];
            var y = 100 - i * 56;
            var rowNode = this_3.sprite(panel, "white", 0, y, 480, 44, cc.color(24, 34, 76));
            this_3.label(rowNode, row.name, -220, 0, 18, white, 0);
            var valNode = this_3.label(rowNode, row.value(), 220, 0, 18, cyan, 1);
            rowNode.on(cc.Node.EventType.TOUCH_END, function () {
                row.next();
                GameData_1.default.saveSettings();
                (valNode.getComponent(cc.Label)).string = row.value();
            });
        };
        var this_3 = this;
        for (var i = 0; i < rows.length; i++) {
            _loop_3(i);
        }
        var closeBtn = this.sprite(panel, "white", 0, -190, 160, 40, cc.color(70, 30, 50));
        this.label(closeBtn, "CLOSE", 0, 0, 18, white);
        closeBtn.on(cc.Node.EventType.TOUCH_END, function () {
            Sfx_1.default.play("click", 0.8);
            _this.toggleSettings();
        });
    };
    MenuCtrl.prototype.onKeyDown = function (e) {
        if (e.keyCode === cc.macro.KEY.space && !this.settingsPanel) {
            GameData_1.default.currentLevel = 1;
            cc.director.loadScene("Game");
        }
        if (e.keyCode === cc.macro.KEY.escape && this.settingsPanel) {
            this.toggleSettings();
        }
    };
    MenuCtrl = __decorate([
        ccclass
    ], MenuCtrl);
    return MenuCtrl;
}(cc.Component));
exports.default = MenuCtrl;

cc._RF.pop();