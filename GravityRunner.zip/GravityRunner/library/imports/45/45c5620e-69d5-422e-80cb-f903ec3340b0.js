"use strict";
cc._RF.push(module, '45c56IOadVCLoDL+QPsM0Cw', 'CameraFollow');
// scripts/CameraFollow.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var ccclass = cc._decorator.ccclass;
// Follows the player horizontally with a forward look-ahead.
// Attached at runtime by GameMgr; configure via init().
var CameraFollow = /** @class */ (function (_super) {
    __extends(CameraFollow, _super);
    function CameraFollow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.target = null;
        _this.minX = 0;
        _this.maxX = 0;
        _this.lookAhead = 160;
        _this.smooth = 10;
        return _this;
    }
    CameraFollow.prototype.init = function (target, minX, maxX) {
        this.target = target;
        this.minX = minX;
        this.maxX = Math.max(minX, maxX);
        this.node.x = minX;
        this.node.y = 0;
    };
    CameraFollow.prototype.setTarget = function (target) {
        this.target = target;
    };
    CameraFollow.prototype.snap = function () {
        if (!this.target)
            return;
        this.node.x = this.clampX(this.target.x + this.lookAhead);
    };
    CameraFollow.prototype.clampX = function (x) {
        return Math.max(this.minX, Math.min(this.maxX, x));
    };
    CameraFollow.prototype.update = function (dt) {
        if (!this.target || !this.target.isValid)
            return;
        var targetX = this.clampX(this.target.x + this.lookAhead);
        var t = Math.min(1, this.smooth * dt);
        this.node.x += (targetX - this.node.x) * t;
    };
    CameraFollow = __decorate([
        ccclass
    ], CameraFollow);
    return CameraFollow;
}(cc.Component));
exports.default = CameraFollow;

cc._RF.pop();