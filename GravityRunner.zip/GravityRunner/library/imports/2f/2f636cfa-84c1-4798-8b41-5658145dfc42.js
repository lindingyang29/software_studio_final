"use strict";
cc._RF.push(module, '2f636z6hMFHmItBVlgUXfxC', 'GameMgr');
// scripts/GameMgr.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var GameData_1 = require("./GameData");
var LevelBuilder_1 = require("./LevelBuilder");
var Player_1 = require("./Player");
var CameraFollow_1 = require("./CameraFollow");
var Sfx_1 = require("./Sfx");
var ccclass = cc._decorator.ccclass;
// Owns the Game scene: loads assets + level JSON, builds the world through
// LevelBuilder, spawns 1-2 Players, and runs the ready/run/dead/win state machine.
// Everything (world, HUD) is created in code — the .fire scene stays minimal.
//
// Co-op rules (GameData.players === 2): P1 = W key, P2 = UP/SPACE.
// If one player dies while the partner survives, they revive next to the
// partner after 3s. If everyone is dead, the level restarts.
var GameMgr = /** @class */ (function (_super) {
    __extends(GameMgr, _super);
    function GameMgr() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // global slow-motion factor (slow power-up); Player multiplies dt by this
        _this.timeScale = 1;
        _this.cameraNode = null;
        _this.world = null;
        _this.hud = null;
        _this.players = [];
        _this.level = null;
        _this.frames = {};
        _this.state = "loading";
        _this.time = 0;
        _this.deaths = 0;
        _this.crystalsTaken = 0;
        _this.slowT = 0;
        _this.enemyT = 0;
        _this.rotCurrent = 0;
        _this.rotTarget = 0;
        _this.nameLabel = null;
        _this.crystalLabel = null;
        _this.deathLabel = null;
        _this.timeLabel = null;
        _this.msgLabel = null;
        _this.subLabel = null;
        _this.slowOverlay = null;
        return _this;
    }
    GameMgr.prototype.isRunning = function () {
        return this.state === "run";
    };
    GameMgr.prototype.onLoad = function () {
        var _this = this;
        Sfx_1.default.preload();
        Sfx_1.default.playBgm();
        this.cameraNode = this.node.getChildByName("Main Camera");
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouch, this);
        cc.resources.loadDir("textures", cc.SpriteFrame, function (err, assets) {
            if (err) {
                cc.error("texture load failed", err);
                return;
            }
            for (var _i = 0, assets_1 = assets; _i < assets_1.length; _i++) {
                var a = assets_1[_i];
                _this.frames[a.name] = a;
            }
            _this.onTexturesReady();
        });
    };
    GameMgr.prototype.onDestroy = function () {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    };
    GameMgr.prototype.onTexturesReady = function () {
        var _this = this;
        // background rides along as a child of the camera (auto screen-aligned,
        // even when the camera rotates in rotation zones)
        var bg = new cc.Node("BG");
        var bgSp = bg.addComponent(cc.Sprite);
        bgSp.spriteFrame = this.frames["bg"];
        bgSp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        bg.setContentSize(1400, 1400); // oversized: stays covering while rotated
        var b = GameData_1.default.settings.brightness;
        var tint = LevelBuilder_1.default.scheme().bgTint;
        bg.color = cc.color(Math.round(tint.r * b), Math.round(tint.g * b), Math.round(tint.b * b));
        this.cameraNode.addChild(bg, -10);
        this.world = new cc.Node("World");
        this.node.addChild(this.world);
        this.buildHud();
        cc.resources.load("levels/level" + GameData_1.default.currentLevel, cc.JsonAsset, function (err, asset) {
            if (err) {
                _this.setMsg("LEVEL " + GameData_1.default.currentLevel + " LOAD ERROR", "");
                cc.error(err);
                return;
            }
            _this.startLevel(asset.json);
        });
    };
    GameMgr.prototype.startLevel = function (data) {
        this.level = LevelBuilder_1.default.build(this.world, data, this.frames);
        var count = GameData_1.default.players === 2 ? 2 : 1;
        this.players = [];
        for (var i = 0; i < count; i++) {
            var pNode = new cc.Node("Player" + (i + 1));
            var sp = pNode.addComponent(cc.Sprite);
            sp.spriteFrame = this.frames[i === 0 ? "player" : "player2"];
            sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            pNode.setContentSize(36, 36);
            this.world.addChild(pNode, 5);
            var p = pNode.addComponent(Player_1.default);
            p.init(this, this.level, i, this.frames);
            this.players.push(p);
        }
        var follow = this.cameraNode.addComponent(CameraFollow_1.default);
        follow.init(this.players[0].node, 0, this.level.length - 480);
        follow.snap();
        this.time = 0;
        this.deaths = 0;
        this.crystalsTaken = 0;
        this.timeScale = 1;
        this.enemyT = 0;
        this.applyRotationForX(this.level.start.x, true);
        this.nameLabel.string = "LEVEL " + GameData_1.default.currentLevel + " — " + this.level.name
            + (count === 2 ? "   [2P]" : "");
        this.refreshHud();
        this.state = "ready";
        this.setMsg("PRESS SPACE TO RUN", count === 2
            ? "P1: W = FLIP      P2: UP / SPACE = FLIP      R = RESTART"
            : "SPACE / W / UP = FLIP GRAVITY    R = RESTART    ESC = PAUSE");
    };
    // ---------- HUD ----------
    GameMgr.prototype.makeLabel = function (parent, x, y, size, color, anchorX) {
        if (anchorX === void 0) { anchorX = 0.5; }
        var n = new cc.Node("label");
        n.setPosition(x, y);
        n.anchorX = anchorX;
        n.color = color;
        var lb = n.addComponent(cc.Label);
        lb.fontSize = size;
        lb.lineHeight = size + 6;
        lb.string = "";
        parent.addChild(n);
        return lb;
    };
    GameMgr.prototype.buildHud = function () {
        // HUD is a sibling of the world; update() keeps it glued to the camera
        // (position AND angle, so it stays upright in rotation zones).
        this.hud = new cc.Node("HUD");
        this.node.addChild(this.hud, 100);
        var cyan = cc.color(127, 247, 255);
        var pink = cc.color(255, 122, 200);
        var orange = cc.color(255, 181, 74);
        var white = cc.color(235, 240, 255);
        this.slowOverlay = new cc.Node("slowFx");
        var so = this.slowOverlay.addComponent(cc.Sprite);
        so.spriteFrame = this.frames["white"];
        so.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        this.slowOverlay.setContentSize(1400, 1400);
        this.slowOverlay.color = cc.color(120, 150, 255);
        this.slowOverlay.opacity = 0;
        this.hud.addChild(this.slowOverlay, -1);
        this.nameLabel = this.makeLabel(this.hud, -450, 296, 20, cyan, 0);
        this.crystalLabel = this.makeLabel(this.hud, -450, 268, 20, white, 0);
        this.deathLabel = this.makeLabel(this.hud, -450, 240, 20, pink, 0);
        this.timeLabel = this.makeLabel(this.hud, 450, 296, 20, orange, 1);
        this.msgLabel = this.makeLabel(this.hud, 0, 40, 44, white);
        this.subLabel = this.makeLabel(this.hud, 0, -10, 18, cyan);
    };
    GameMgr.prototype.refreshHud = function () {
        this.crystalLabel.string = "CRYSTALS  " + this.crystalsTaken + " / " + this.level.totalCrystals;
        this.deathLabel.string = "DEATHS  " + this.deaths;
        this.timeLabel.string = this.formatTime(this.time);
    };
    GameMgr.prototype.formatTime = function (t) {
        var m = Math.floor(t / 60);
        var s = t - m * 60;
        return (m < 10 ? "0" + m : "" + m) + ":" + (s < 10 ? "0" + s.toFixed(1) : s.toFixed(1));
    };
    GameMgr.prototype.setMsg = function (main, sub) {
        this.msgLabel.string = main;
        this.subLabel.string = sub;
    };
    // ---------- input ----------
    GameMgr.prototype.onKeyDown = function (e) {
        switch (e.keyCode) {
            case cc.macro.KEY.space:
            case cc.macro.KEY.up:
                this.onAction(1);
                break;
            case cc.macro.KEY.w:
                this.onAction(0);
                break;
            case cc.macro.KEY.r:
                this.fullRestart();
                break;
            case cc.macro.KEY.escape:
                this.togglePause();
                break;
        }
    };
    GameMgr.prototype.onTouch = function (e) {
        // 2P touch: left half of the screen = P1, right half = P2
        var half = cc.winSize.width / 2;
        this.onAction(e.getLocationX() < half ? 0 : 1);
    };
    // who: 0 = P1 input, 1 = P2 input (in solo mode every input drives P1)
    GameMgr.prototype.onAction = function (who) {
        switch (this.state) {
            case "ready":
                this.state = "run";
                this.setMsg("", "");
                break;
            case "run": {
                var idx = GameData_1.default.players === 2 ? who : 0;
                var p = this.players[idx];
                if (p && p.alive)
                    p.flip();
                break;
            }
            case "paused":
                this.togglePause();
                break;
            case "win":
                this.proceedAfterWin();
                break;
        }
    };
    GameMgr.prototype.togglePause = function () {
        if (this.state === "run") {
            this.state = "paused";
            this.setMsg("PAUSED", "SPACE = RESUME    R = RESTART");
        }
        else if (this.state === "paused") {
            this.state = "run";
            this.setMsg("", "");
        }
        else if (this.state === "win") {
            cc.director.loadScene("Menu");
        }
    };
    GameMgr.prototype.fullRestart = function () {
        if (this.state === "loading" || this.players.length === 0)
            return;
        this.unscheduleAllCallbacks();
        this.respawnAll();
        this.state = "ready";
        this.setMsg("PRESS SPACE TO RUN", "");
    };
    GameMgr.prototype.respawnAll = function () {
        for (var _i = 0, _a = this.players; _i < _a.length; _i++) {
            var p = _a[_i];
            p.reset();
        }
        for (var _b = 0, _c = this.level.crystals; _b < _c.length; _b++) {
            var c = _c[_b];
            c.taken = false;
            c.node.active = true;
            c.node.setPosition(c.x, c.y); // magnet may have dragged it around
        }
        for (var _d = 0, _e = this.level.powerups; _d < _e.length; _d++) {
            var pu = _e[_d];
            pu.taken = false;
            pu.node.active = true;
        }
        this.crystalsTaken = 0;
        this.time = 0;
        this.timeScale = 1;
        this.slowT = 0;
        this.slowOverlay.opacity = 0;
        this.enemyT = 0;
        var follow = this.cameraNode.getComponent(CameraFollow_1.default);
        if (follow) {
            follow.setTarget(this.players[0].node);
            follow.snap();
        }
        this.applyRotationForX(this.level.start.x, true);
        this.refreshHud();
    };
    // ---------- rotation zones ----------
    GameMgr.prototype.applyRotationForX = function (x, instant) {
        var target = 0;
        for (var _i = 0, _a = this.level.rotations; _i < _a.length; _i++) {
            var r = _a[_i];
            if (x >= r.x)
                target = r.angle;
        }
        if (target !== this.rotTarget) {
            this.rotTarget = target;
            if (!instant)
                Sfx_1.default.play("teleport", 0.4);
        }
        if (instant) {
            this.rotCurrent = target;
            this.applyWorldRotation();
        }
    };
    // Rotate the WORLD node (not the camera — cc.Camera in 2.4 ignores its
    // node's rotation) around the camera's focus point. Obstacles, players and
    // apparent gravity all rotate on screen, while physics stay 1D because
    // Player works in the world node's local coordinates.
    GameMgr.prototype.applyWorldRotation = function () {
        var th = this.rotCurrent * Math.PI / 180;
        var px = this.cameraNode.x; // camera y is always 0
        this.world.angle = this.rotCurrent;
        this.world.x = px - px * Math.cos(th);
        this.world.y = -px * Math.sin(th);
    };
    // ---------- power-up support ----------
    GameMgr.prototype.applySlow = function (seconds, scale) {
        this.slowT = seconds;
        this.timeScale = scale;
        this.slowOverlay.opacity = 50;
    };
    // ---------- callbacks from Player ----------
    GameMgr.prototype.onCrystal = function () {
        this.crystalsTaken++;
        Sfx_1.default.play("crystal", 0.7);
        this.refreshHud();
    };
    GameMgr.prototype.onDeath = function (dead) {
        var _this = this;
        if (this.state !== "run")
            return;
        this.deaths++;
        Sfx_1.default.play("death", 0.8);
        this.refreshHud();
        var survivor = this.anyAlive();
        if (survivor) {
            // partner carries on; camera follows them, dead player revives in 3s
            var follow = this.cameraNode.getComponent(CameraFollow_1.default);
            if (follow)
                follow.setTarget(survivor.node);
            this.scheduleOnce(function () {
                var s = _this.anyAlive();
                if (_this.state === "run" && s) {
                    dead.respawnAt(s.node.x - 50, s.node.y, s.getGravityDir());
                }
            }, 3);
            return;
        }
        // everyone is down — quick auto-retry keeps the rhythm going
        this.state = "dead";
        this.unscheduleAllCallbacks();
        this.scheduleOnce(function () {
            _this.respawnAll();
            _this.state = "run";
        }, 0.8);
    };
    GameMgr.prototype.anyAlive = function () {
        for (var _i = 0, _a = this.players; _i < _a.length; _i++) {
            var p = _a[_i];
            if (p.alive)
                return p;
        }
        return null;
    };
    GameMgr.prototype.onWin = function () {
        if (this.state !== "run")
            return;
        this.state = "win";
        this.unscheduleAllCallbacks();
        Sfx_1.default.play("win", 0.9);
        GameData_1.default.unlockNext(GameData_1.default.currentLevel);
        var last = GameData_1.default.currentLevel >= GameData_1.default.MAX_LEVEL;
        this.setMsg(last ? "YOU ESCAPED ASTRA-9!" : "LEVEL CLEAR!", "CRYSTALS " + this.crystalsTaken + "/" + this.level.totalCrystals
            + "    TIME " + this.formatTime(this.time)
            + "    DEATHS " + this.deaths
            + (last ? "    SPACE = MENU" : "    SPACE = NEXT    ESC = MENU"));
    };
    GameMgr.prototype.proceedAfterWin = function () {
        if (GameData_1.default.currentLevel < GameData_1.default.MAX_LEVEL) {
            GameData_1.default.currentLevel++;
            cc.director.loadScene("Game");
        }
        else {
            cc.director.loadScene("Menu");
        }
    };
    // ---------- per-frame ----------
    GameMgr.prototype.update = function (dt) {
        // keep HUD glued to the camera viewport
        if (this.hud && this.cameraNode) {
            this.hud.x = this.cameraNode.x;
            this.hud.y = this.cameraNode.y;
        }
        // animate field rotation at a constant rate, and re-anchor every frame
        // because the pivot (camera focus) keeps moving
        if (this.rotCurrent !== this.rotTarget) {
            var step = 110 * dt;
            var diff = this.rotTarget - this.rotCurrent;
            if (Math.abs(diff) <= step)
                this.rotCurrent = this.rotTarget;
            else
                this.rotCurrent += diff > 0 ? step : -step;
        }
        if (this.world)
            this.applyWorldRotation();
        if (this.state !== "run")
            return;
        this.time += dt;
        this.timeLabel.string = this.formatTime(this.time);
        // slow-motion timer
        if (this.slowT > 0) {
            this.slowT -= dt;
            if (this.slowT <= 0) {
                this.timeScale = 1;
                this.slowOverlay.opacity = 0;
            }
        }
        // patrol drones oscillate on a fixed deterministic clock
        this.enemyT += dt * this.timeScale;
        for (var _i = 0, _a = this.level.enemies; _i < _a.length; _i++) {
            var e = _a[_i];
            var off = Math.sin((this.enemyT + e.phase) * Math.PI * 2 / e.period) * e.range;
            if (e.axis === "x")
                e.node.x = e.x0 + off;
            else
                e.node.y = e.y0 + off;
        }
        // rotation zones track the leading living player
        var lead = this.anyAlive();
        if (lead)
            this.applyRotationForX(lead.node.x, false);
    };
    GameMgr = __decorate([
        ccclass
    ], GameMgr);
    return GameMgr;
}(cc.Component));
exports.default = GameMgr;

cc._RF.pop();