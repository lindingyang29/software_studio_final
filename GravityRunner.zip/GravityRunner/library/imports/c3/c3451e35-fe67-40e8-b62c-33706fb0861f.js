"use strict";
cc._RF.push(module, 'c345141/mdA6LYsM3BvsIYf', 'LevelBuilder');
// scripts/LevelBuilder.ts

"use strict";
// Builds a level from a JSON file in resources/levels/.
// All collision is plain AABB data (center x/y + w/h); visuals are tinted sprites.
//
// Corridor layout (world coordinates, y=0 is the corridor center):
//   ceiling surface  y = +250
//   floor surface    y = -250
// Solid bands are THICK px deep behind each surface.
//
// Supported JSON fields (see levels/level1.json for an example):
//   segments  [{x, w, side:"floor"|"ceiling"}]      solid floor/ceiling bands
//   platforms [{x, y, w, h}]                        free-floating solids
//   spikes    [{x, side}]                           lethal triangles on a surface
//   crystals  [{x, y}]                              collectibles
//   powerups  [{x, y, type:"shield"|"slow"|"magnet"}]
//   teleports [{x, y, tx, ty}]                      one-way A->B (tx MUST be > x+50)
//   enemies   [{x, y, axis:"x"|"y", range, period, phase?}]   patrol drones
//   rotations [{x, angle}]                          visual field rotation from x on
//   goal      {x}                                   portal column
//   speed, length, start {x, side}, name
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCHEMES = exports.THICK = exports.CEIL_Y = exports.FLOOR_Y = void 0;
var GameData_1 = require("./GameData");
exports.FLOOR_Y = -250;
exports.CEIL_Y = 250;
exports.THICK = 70;
// Color schemes selectable in settings. Index = GameData.settings.scheme.
exports.SCHEMES = [
    {
        name: "NEON",
        floorEdge: cc.color(53, 240, 255),
        ceilEdge: cc.color(255, 122, 200),
        platform: cc.color(20, 26, 58),
        goal: cc.color(255, 181, 74),
        crystal: cc.color(127, 247, 255),
        bgTint: cc.color(255, 255, 255)
    },
    {
        name: "SUNSET",
        floorEdge: cc.color(255, 181, 74),
        ceilEdge: cc.color(255, 90, 90),
        platform: cc.color(46, 22, 38),
        goal: cc.color(255, 240, 150),
        crystal: cc.color(255, 214, 140),
        bgTint: cc.color(255, 196, 170)
    },
    {
        name: "MATRIX",
        floorEdge: cc.color(77, 255, 124),
        ceilEdge: cc.color(196, 255, 80),
        platform: cc.color(12, 34, 20),
        goal: cc.color(190, 255, 130),
        crystal: cc.color(170, 255, 190),
        bgTint: cc.color(180, 255, 200)
    }
];
var POWER_COLORS = {
    shield: cc.color(120, 220, 255),
    slow: cc.color(170, 140, 255),
    magnet: cc.color(255, 230, 110)
};
var LevelBuilder = /** @class */ (function () {
    function LevelBuilder() {
    }
    LevelBuilder.scheme = function () {
        var i = GameData_1.default.settings.scheme;
        return exports.SCHEMES[i >= 0 && i < exports.SCHEMES.length ? i : 0];
    };
    LevelBuilder.build = function (world, data, frames) {
        var pal = LevelBuilder.scheme();
        var solids = [];
        var spikes = [];
        var crystals = [];
        var powerups = [];
        var teleports = [];
        var enemies = [];
        var rotations = [];
        var sprite = function (frame, x, y, w, h, color, z) {
            var n = new cc.Node(frame);
            var sp = n.addComponent(cc.Sprite);
            sp.spriteFrame = frames[frame];
            sp.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            n.setContentSize(w, h);
            n.setPosition(x, y);
            if (color)
                n.color = color;
            if (z !== undefined)
                n.zIndex = z;
            world.addChild(n);
            return n;
        };
        var addGlow = function (parent, size, color, opacity) {
            var glow = new cc.Node("glow");
            var gs = glow.addComponent(cc.Sprite);
            gs.spriteFrame = frames["glow"];
            gs.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            glow.setContentSize(size, size);
            glow.color = color;
            glow.opacity = opacity;
            parent.addChild(glow, -1);
            return glow;
        };
        // --- floor / ceiling segments ---
        for (var _i = 0, _a = (data.segments || []); _i < _a.length; _i++) {
            var seg = _a[_i];
            var isFloor = seg.side === "floor";
            var cy = isFloor ? exports.FLOOR_Y - exports.THICK / 2 : exports.CEIL_Y + exports.THICK / 2;
            var cx = seg.x + seg.w / 2;
            solids.push({ x: cx, y: cy, w: seg.w, h: exports.THICK });
            sprite("white", cx, cy, seg.w, exports.THICK, pal.platform);
            var edgeY = isFloor ? exports.FLOOR_Y - 2 : exports.CEIL_Y + 2;
            sprite("white", cx, edgeY, seg.w, 4, isFloor ? pal.floorEdge : pal.ceilEdge, 1);
        }
        // --- free-floating platforms ---
        for (var _b = 0, _c = (data.platforms || []); _b < _c.length; _b++) {
            var p = _c[_b];
            solids.push({ x: p.x, y: p.y, w: p.w, h: p.h });
            sprite("white", p.x, p.y, p.w, p.h, pal.platform);
            sprite("white", p.x, p.y + p.h / 2 - 2, p.w, 4, pal.floorEdge, 1);
            sprite("white", p.x, p.y - p.h / 2 + 2, p.w, 4, pal.ceilEdge, 1);
        }
        // --- spikes ---
        for (var _d = 0, _e = (data.spikes || []); _d < _e.length; _d++) {
            var s = _e[_d];
            var onFloor = s.side === "floor";
            var baseY = onFloor ? exports.FLOOR_Y : exports.CEIL_Y;
            var n = sprite("spike", s.x, baseY + (onFloor ? 19 : -19), 48, 40, undefined, 2);
            if (!onFloor)
                n.scaleY = -1;
            spikes.push({ x: s.x, y: baseY + (onFloor ? 13 : -13), w: 22, h: 24 });
        }
        // --- crystals ---
        for (var _f = 0, _g = (data.crystals || []); _f < _g.length; _f++) {
            var c = _g[_f];
            var n = sprite("crystal", c.x, c.y, 28, 28, pal.crystal, 2);
            addGlow(n, 64, pal.crystal, 120);
            cc.tween(n).by(2.4, { angle: 360 }).repeatForever().start();
            crystals.push({ x: c.x, y: c.y, taken: false, node: n });
        }
        // --- powerups ---
        for (var _h = 0, _j = (data.powerups || []); _h < _j.length; _h++) {
            var p = _j[_h];
            var col = POWER_COLORS[p.type] || cc.Color.WHITE;
            var n = sprite(p.type, p.x, p.y, 34, 34, undefined, 2);
            addGlow(n, 80, col, 140);
            cc.tween(n)
                .to(0.8, { y: p.y + 8 }, { easing: "sineInOut" })
                .to(0.8, { y: p.y - 8 }, { easing: "sineInOut" })
                .repeatForever()
                .start();
            powerups.push({ x: p.x, y: p.y, type: p.type, taken: false, node: n });
        }
        // --- teleports (one-way entry -> exit) ---
        for (var _k = 0, _l = (data.teleports || []); _k < _l.length; _k++) {
            var t = _l[_k];
            var entry = sprite("tport", t.x, t.y, 52, 52, cc.color(190, 120, 255), 2);
            addGlow(entry, 90, cc.color(190, 120, 255), 150);
            cc.tween(entry).by(1.6, { angle: -360 }).repeatForever().start();
            var exit = sprite("tport", t.tx, t.ty, 52, 52, cc.color(120, 255, 210), 2);
            exit.opacity = 170;
            addGlow(exit, 70, cc.color(120, 255, 210), 100);
            cc.tween(exit).by(2.2, { angle: 360 }).repeatForever().start();
            teleports.push({ x: t.x, y: t.y, tx: t.tx, ty: t.ty });
        }
        // --- patrol drones ---
        for (var _m = 0, _o = (data.enemies || []); _m < _o.length; _m++) {
            var e = _o[_m];
            var n = sprite("drone", e.x, e.y, 36, 36, undefined, 3);
            addGlow(n, 70, cc.color(255, 90, 90), 130);
            cc.tween(n).by(1.2, { angle: 360 }).repeatForever().start();
            enemies.push({
                node: n,
                x0: e.x,
                y0: e.y,
                axis: e.axis === "x" ? "x" : "y",
                range: e.range || 120,
                period: e.period || 2,
                phase: e.phase || 0
            });
        }
        // --- visual rotation zones ---
        for (var _p = 0, _q = (data.rotations || []); _p < _q.length; _p++) {
            var r = _q[_p];
            rotations.push({ x: r.x, angle: r.angle || 0 });
            // subtle marker so players see something changed here
            var marker = sprite("white", r.x, 0, 6, 2 * exports.CEIL_Y, pal.goal, 0);
            marker.opacity = 40;
        }
        rotations.sort(function (a, b) { return a.x - b.x; });
        // --- goal portal: a glowing column spanning the corridor ---
        var goalX = data.goal.x;
        var goal = { x: goalX, y: 0, w: 56, h: 2 * exports.CEIL_Y };
        var beam = sprite("white", goalX, 0, 24, 2 * exports.CEIL_Y, pal.goal, 1);
        beam.opacity = 90;
        var ring = sprite("portal", goalX, 0, 96, 160, undefined, 2);
        cc.tween(ring)
            .to(0.8, { scale: 1.12 })
            .to(0.8, { scale: 1.0 })
            .repeatForever()
            .start();
        cc.tween(beam)
            .to(0.6, { opacity: 150 })
            .to(0.6, { opacity: 60 })
            .repeatForever()
            .start();
        var startSide = (data.start && data.start.side) === "ceiling" ? 1 : -1;
        var startY = startSide === -1 ? exports.FLOOR_Y + 18 : exports.CEIL_Y - 18;
        return {
            name: data.name || "LEVEL",
            speed: (data.speed || 300) * GameData_1.default.settings.speed,
            length: data.length,
            start: { x: (data.start && data.start.x) || 0, y: startY },
            solids: solids,
            spikes: spikes,
            crystals: crystals,
            powerups: powerups,
            teleports: teleports,
            enemies: enemies,
            rotations: rotations,
            goal: goal,
            totalCrystals: crystals.length
        };
    };
    return LevelBuilder;
}());
exports.default = LevelBuilder;

cc._RF.pop();